package com.Nextstars.ModPlugin.menu;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import com.Nextstars.ModPlugin.util.StaffInventoryHolder;
import org.bukkit.inventory.meta.SkullMeta;
import java.util.ArrayList;
import java.util.List;
public class PlayerInfoMenu {
    public static final String PLAYER_INFO_MENU_KEY = "player-info";
    private final ModPlugin plugin;
    public PlayerInfoMenu(ModPlugin plugin) {
        this.plugin = plugin;
    }
    public String getTitle() {
        return plugin.getConfigManager().getMenuTitle(PLAYER_INFO_MENU_KEY);
    }
    public void open(Player staff, Player target) {
        int size = plugin.getConfigManager().getMenuSize(PLAYER_INFO_MENU_KEY);
        Inventory inventory = Bukkit.createInventory(new StaffInventoryHolder(PLAYER_INFO_MENU_KEY), size, getTitle());
        fillBorders(inventory, size);
        int headSlot = plugin.getConfigManager().getIntSetting(PLAYER_INFO_MENU_KEY, "head-slot", 4);
        inventory.setItem(headSlot, buildInfoHead(target));
        int confirmSlot = plugin.getConfigManager().getIntSetting(PLAYER_INFO_MENU_KEY, "confirm-slot", 13);
        inventory.setItem(confirmSlot, buildKickButton());
        int backSlot = plugin.getConfigManager().getIntSetting(PLAYER_INFO_MENU_KEY, "back-slot", 18);
        inventory.setItem(backSlot, buildBackButton());
        staff.openInventory(inventory);
        plugin.getConfigManager().playSound(staff, "menu-open");
    }
    private ItemStack buildInfoHead(Player target) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        meta.setOwningPlayer(target);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&c&l" + target.getName()));
        int warns = plugin.getWarnManager().getWarnCount(target.getUniqueId());
        int maxWarns = plugin.getConfigManager().getMaxWarns();
        double maxHealth = target.getAttribute(Attribute.GENERIC_MAX_HEALTH).getValue();
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', "&7Name: &f" + target.getName()));
        lore.add(ChatColor.translateAlternateColorCodes('&', "&7❤ Health: &f" + (int) target.getHealth() + "/" + (int) maxHealth));
        lore.add(ChatColor.translateAlternateColorCodes('&', "&7🍖 Hunger: &f" + target.getFoodLevel() + "/20"));
        lore.add(ChatColor.translateAlternateColorCodes('&', "&7Game Mode: &f" + target.getGameMode().name()));
        lore.add(ChatColor.translateAlternateColorCodes('&', "&7Warns: &c" + warns + "&7/&c" + maxWarns));
        lore.add(ChatColor.translateAlternateColorCodes('&', "&7Frozen: " + (plugin.getFreezeManager().isFrozen(target) ? "&ctrue" : "&afalse")));
        lore.add(ChatColor.translateAlternateColorCodes('&', "&7Muted: " + (plugin.getMuteManager().isMuted(target) ? "&ctrue" : "&afalse")));
        meta.setLore(lore);
        skull.setItemMeta(meta);
        return skull;
    }
    private ItemStack buildKickButton() {
        ItemStack item = new ItemStack(Material.OAK_SIGN);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&c&lKick Player"));
        meta.setLore(List.of(
                ChatColor.translateAlternateColorCodes('&', "&7Click to open the sign input."),
                ChatColor.translateAlternateColorCodes('&', "&8» &eClick to proceed.")
        ));
        item.setItemMeta(meta);
        return item;
    }
    private ItemStack buildBackButton() {
        ItemStack item = new ItemStack(Material.ARROW);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&7« &fBack"));
        item.setItemMeta(meta);
        return item;
    }
    private void fillBorders(Inventory inventory, int size) {
        Material border = plugin.getConfigManager().getBorderMaterial(PLAYER_INFO_MENU_KEY);
        ItemStack pane = new ItemStack(border);
        ItemMeta meta = pane.getItemMeta();
        meta.setDisplayName(" ");
        pane.setItemMeta(meta);
        int rows = size / 9;
        for (int slot = 0; slot < size; slot++) {
            int row = slot / 9;
            int col = slot % 9;
            if (row == 0 || row == rows - 1 || col == 0 || col == 8) {
                inventory.setItem(slot, pane.clone());
            }
        }
    }
}
