package com.Nextstars.ModPlugin.menu;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import com.Nextstars.ModPlugin.util.StaffInventoryHolder;
import java.util.List;
public class StaffMenu {
    public static final String STAFF_MENU_TITLE_KEY = "staff-panel";
    private final ModPlugin plugin;
    public StaffMenu(ModPlugin plugin) {
        this.plugin = plugin;
    }
    public String getTitle() {
        return plugin.getConfigManager().getMenuTitle(STAFF_MENU_TITLE_KEY);
    }
    public void open(Player player) {
        int size = plugin.getConfigManager().getMenuSize(STAFF_MENU_TITLE_KEY);
        Inventory inventory = Bukkit.createInventory(new StaffInventoryHolder(STAFF_MENU_TITLE_KEY), size, getTitle());
        fillBorders(inventory, size);
        for (String itemKey : plugin.getConfigManager().getMenuItemKeys(STAFF_MENU_TITLE_KEY)) {
            int slot = plugin.getConfigManager().getItemSlot(STAFF_MENU_TITLE_KEY, itemKey);
            switch (itemKey.toLowerCase()) {
                case "vanish" -> inventory.setItem(slot, buildVanishItemPublic(player));
                case "fly" -> inventory.setItem(slot, buildFlyItemPublic(player));
                default -> inventory.setItem(slot, plugin.getConfigManager().buildItem(STAFF_MENU_TITLE_KEY, itemKey));
            }
        }
        player.openInventory(inventory);
        plugin.getConfigManager().playSound(player, "menu-open");
    }
    public ItemStack buildVanishItemPublic(Player player) {
        boolean vanished = plugin.getVanishManager().isVanished(player);
        ItemStack item = plugin.getConfigManager().buildItemWithExtraLore(
                STAFF_MENU_TITLE_KEY, "vanish",
                List.of("&7Status: " + (vanished ? "&aON" : "&cOFF"))
        );
        String base = "menus." + STAFF_MENU_TITLE_KEY + ".items.vanish";
        String nameOn = plugin.getConfigManager().getString(base + ".name-on", "");
        String nameOff = plugin.getConfigManager().getString(base + ".name-off", "");
        if (vanished && !nameOn.isEmpty()) {
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', nameOn));
            item.setItemMeta(meta);
        } else if (!vanished && !nameOff.isEmpty()) {
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', nameOff));
            item.setItemMeta(meta);
        }
        return item;
    }
    public ItemStack buildFlyItemPublic(Player player) {
        boolean enabled = plugin.getFlyManager().isFlyEnabled(player);
        ItemStack item = plugin.getConfigManager().buildItemWithExtraLore(
                STAFF_MENU_TITLE_KEY, "fly",
                List.of("&7Status: " + (enabled ? "&aON" : "&cOFF"))
        );
        String base = "menus." + STAFF_MENU_TITLE_KEY + ".items.fly";
        String nameOn = plugin.getConfigManager().getString(base + ".name-on", "");
        String nameOff = plugin.getConfigManager().getString(base + ".name-off", "");
        if (enabled && !nameOn.isEmpty()) {
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', nameOn));
            item.setItemMeta(meta);
        } else if (!enabled && !nameOff.isEmpty()) {
            ItemMeta meta = item.getItemMeta();
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', nameOff));
            item.setItemMeta(meta);
        }
        return item;
    }
    private void fillBorders(Inventory inventory, int size) {
        Material border = plugin.getConfigManager().getBorderMaterial(STAFF_MENU_TITLE_KEY);
        ItemStack pane = new ItemStack(border);
        ItemMeta meta = pane.getItemMeta();
        meta.setDisplayName(" ");
        pane.setItemMeta(meta);
        int rows = size / 9;
        for (int slot = 0; slot < size; slot++) {
            int row = slot / 9;
            int col = slot % 9;
            if (row == 0 || row == rows - 1 || col == 0 || col == 8) {
                inventory.setItem(slot, pane.clone());
            }
        }
    }
}
