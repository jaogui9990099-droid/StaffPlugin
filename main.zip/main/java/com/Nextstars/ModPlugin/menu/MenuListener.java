package com.Nextstars.ModPlugin.menu;
import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.action.StaffAction;
import com.Nextstars.ModPlugin.grim.GrimMenu;
import com.Nextstars.ModPlugin.util.GuiProtection;
import com.Nextstars.ModPlugin.util.TimeParser;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import com.Nextstars.ModPlugin.util.StaffInventoryHolder;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
public class MenuListener implements Listener {
    private final ModPlugin plugin;
    private final Set<UUID> switching = new HashSet<>();
    private final Map<UUID, StaffAction> pendingActions = new HashMap<>();
    private final Map<UUID, String> pendingTargets = new HashMap<>();
    public MenuListener(ModPlugin plugin) {
        this.plugin = plugin;
    }
    private boolean isOurMenuHolder(Object holder) {
        if (!(holder instanceof StaffInventoryHolder h)) return false;
        String id = h.getId();
        return id.equals(StaffMenu.STAFF_MENU_TITLE_KEY)
            || id.equals(PlayerListMenu.PLAYER_LIST_MENU_KEY)
            || id.equals(PlayerInfoMenu.PLAYER_INFO_MENU_KEY);
    }
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (isOurMenuHolder(event.getInventory().getHolder())) event.setCancelled(true);
    }
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        Object holder = event.getInventory().getHolder();
        if (!isOurMenuHolder(holder)) return;
        GuiProtection.cancelAll(event);
        if (GuiProtection.isPlayerInventoryClick(event)) return;
        String id = ((StaffInventoryHolder) holder).getId();
        if (id.equals(StaffMenu.STAFF_MENU_TITLE_KEY)) {
            handleStaffMenuClick(player, event.getCurrentItem(), event);
        } else if (id.equals(PlayerListMenu.PLAYER_LIST_MENU_KEY)) {
            handlePlayerListClick(player, event.getCurrentItem(), event.getSlot());
        } else if (id.equals(PlayerInfoMenu.PLAYER_INFO_MENU_KEY)) {
            handlePlayerInfoClick(player, event.getCurrentItem());
        }
    }
    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player player)) return;
        Object holder = event.getInventory().getHolder();
        if (!isOurMenuHolder(holder)) return;
        if (switching.remove(player.getUniqueId())) return;
        pendingActions.remove(player.getUniqueId());
        pendingTargets.remove(player.getUniqueId());
        plugin.getConfigManager().playSound(player, "menu-close");
        player.sendMessage(plugin.getMessageManager().getStaff("closed-staff-menu"));
    }
    private void handleStaffMenuClick(Player player, ItemStack item, InventoryClickEvent event) {
        if (item == null || item.getType() == Material.AIR) return;
        Material mat = item.getType();
        String borderName = plugin.getConfigManager().getBorderMaterial(StaffMenu.STAFF_MENU_TITLE_KEY).name();
        if (mat.name().equals(borderName)) return;
        int clickedSlot = event.getSlot();
        String itemKey = plugin.getConfigManager().getItemKeyBySlot(StaffMenu.STAFF_MENU_TITLE_KEY, clickedSlot);
        if (itemKey == null) return;
        String perm = plugin.getConfigManager().getItemPermission(StaffMenu.STAFF_MENU_TITLE_KEY, itemKey);
        if (perm != null && !perm.isBlank() && !player.hasPermission(perm)) {
            player.sendMessage(plugin.getMessageManager().getStaff("no-permission"));
            return;
        }
        String actionId = plugin.getConfigManager().getItemAction(StaffMenu.STAFF_MENU_TITLE_KEY, itemKey).toLowerCase();
        switch (actionId) {
            case "vanish" -> {
                handleVanish(player, event);
                return;
            }
            case "fly" -> {
                boolean enabled = plugin.getFlyManager().toggle(player);
                player.sendMessage(plugin.getMessageManager().getStaff(enabled ? "fly-on" : "fly-off"));
                plugin.getConfigManager().playSound(player, "fly");
                int slot = plugin.getConfigManager().getItemSlot(StaffMenu.STAFF_MENU_TITLE_KEY, "fly");
                event.getInventory().setItem(slot, new StaffMenu(plugin).buildFlyItemPublic(player));
                return;
            }
            case "grim-monitor", "grim" -> {
                switching.add(player.getUniqueId());
                player.closeInventory();
                new GrimMenu(plugin).open(player);
                return;
            }
            case "sus", "suspicious" -> {
                if (plugin.getSusGUI() == null) {
                    player.sendMessage(plugin.getMessageManager().getStaff("grim-not-available"));
                    return;
                }
                switching.add(player.getUniqueId());
                player.closeInventory();
                plugin.getSusGUI().openGUI(player);
                return;
            }
        }
        StaffAction action = switch (actionId) {
            case "freeze" -> StaffAction.FREEZE;
            case "kick" -> StaffAction.KICK;
            case "mute" -> StaffAction.MUTE;
            case "teleport", "tp" -> StaffAction.TELEPORT;
            case "ban" -> StaffAction.BAN;
            case "clear-inventory", "clear" -> StaffAction.CLEAR_INVENTORY;
            case "warn" -> StaffAction.WARN;
            case "invsee" -> StaffAction.INVSEE;
            default -> null;
        };
        if (action == null) return;
        switching.add(player.getUniqueId());
        pendingActions.put(player.getUniqueId(), action);
        new PlayerListMenu(plugin).open(player, action);
    }
    private void handlePlayerListClick(Player player, ItemStack item, int slot) {
        if (item == null) return;
        int backSlot = plugin.getConfigManager().getIntSetting(PlayerListMenu.PLAYER_LIST_MENU_KEY, "back-slot", PlayerListMenu.BACK_SLOT_DEFAULT);
        if (slot == backSlot) {
            switching.add(player.getUniqueId());
            pendingActions.remove(player.getUniqueId());
            new StaffMenu(plugin).open(player);
            return;
        }
        if (item.getType() != Material.PLAYER_HEAD) return;
        SkullMeta meta = (SkullMeta) item.getItemMeta();
        if (meta == null || meta.getOwningPlayer() == null) return;
        String targetName = meta.getOwningPlayer().getName();
        Player target = Bukkit.getPlayerExact(targetName);
        if (target == null || !target.isOnline()) return;
        StaffAction action = pendingActions.get(player.getUniqueId());
        if (action == null) return;
        if (action == StaffAction.KICK) {
            switching.add(player.getUniqueId());
            pendingTargets.put(player.getUniqueId(), targetName);
            new PlayerInfoMenu(plugin).open(player, target);
            return;
        }
        if (action == StaffAction.MUTE) {
            switching.add(player.getUniqueId());
            pendingTargets.put(player.getUniqueId(), targetName);
            if (plugin.getMuteManager().isMuted(target)) {
                player.closeInventory();
                plugin.getMuteManager().unmute(target.getUniqueId());
                plugin.getMessageManager().sendActionBar(target, "player-unmuted");
                player.sendMessage(plugin.getMessageManager().getStaff("unmuted-player", "%player%", targetName));
                plugin.getConfigManager().playSound(player, "mute");
            } else {
                player.closeInventory();
                requestMuteInput(player, target);
            }
            return;
        }
        if (action == StaffAction.BAN) {
            switching.add(player.getUniqueId());
            pendingTargets.put(player.getUniqueId(), targetName);
            player.closeInventory();
            requestBanInput(player, target);
            return;
        }
        if (action == StaffAction.WARN) {
            switching.add(player.getUniqueId());
            pendingTargets.put(player.getUniqueId(), targetName);
            player.closeInventory();
            requestWarnInput(player, target);
            return;
        }
        if (action == StaffAction.INVSEE) {
            switching.add(player.getUniqueId());
            boolean allowEdit = plugin.getConfigManager().getBoolean("invsee.allow-edit", false);
            String rawTitle = plugin.getConfigManager().getString("invsee.gui.title", "&8InvSee: &b%player%");
            String title = org.bukkit.ChatColor.translateAlternateColorCodes('&', rawTitle.replace("%player%", target.getName()));
            var holder = new StaffInventoryHolder("invsee");
            org.bukkit.inventory.Inventory inv = Bukkit.createInventory(holder, 54, title);
            String fillerMatName = plugin.getConfigManager().getString("invsee.gui.filler.material", "BLACK_STAINED_GLASS_PANE");
            org.bukkit.Material fillerMat = org.bukkit.Material.matchMaterial(fillerMatName);
            if (fillerMat == null) fillerMat = org.bukkit.Material.BLACK_STAINED_GLASS_PANE;
            String fillerName = plugin.getConfigManager().getString("invsee.gui.filler.name", " ");
            org.bukkit.inventory.ItemStack filler = new org.bukkit.inventory.ItemStack(fillerMat);
            org.bukkit.inventory.meta.ItemMeta fillerMeta = filler.getItemMeta();
            if (fillerMeta != null) {
                fillerMeta.setDisplayName(org.bukkit.ChatColor.translateAlternateColorCodes('&', fillerName));
                filler.setItemMeta(fillerMeta);
            }
            for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);
            org.bukkit.inventory.ItemStack[] contents = target.getInventory().getContents();
            for (int i = 0; i < 36 && i < contents.length; i++) {
                inv.setItem(i, contents[i]);
            }
            int helmetSlot = plugin.getConfigManager().getInt("invsee.gui.slots.helmet", 47);
            int chestSlot  = plugin.getConfigManager().getInt("invsee.gui.slots.chestplate", 48);
            int legsSlot   = plugin.getConfigManager().getInt("invsee.gui.slots.leggings", 49);
            int bootsSlot  = plugin.getConfigManager().getInt("invsee.gui.slots.boots", 50);
            int offhandSlot= plugin.getConfigManager().getInt("invsee.gui.slots.offhand", 52);
            inv.setItem(helmetSlot, target.getInventory().getHelmet());
            inv.setItem(chestSlot,  target.getInventory().getChestplate());
            inv.setItem(legsSlot,   target.getInventory().getLeggings());
            inv.setItem(bootsSlot,  target.getInventory().getBoots());
            inv.setItem(offhandSlot, target.getInventory().getItemInOffHand());
            plugin.getInvseeManager().start(player, target, allowEdit, inv);
            player.closeInventory();
            Bukkit.getScheduler().runTask(plugin, () -> {
                if (!player.isOnline() || !target.isOnline()) return;
                player.openInventory(inv);
            });
            player.sendMessage(plugin.getMessageManager().getStaff("invsee-open", "%player%", target.getName()));
            plugin.getConfigManager().playSound(player, "invsee");
            return;
        }
        executeAction(player, target, action, slot);
    }
    private void handlePlayerInfoClick(Player player, ItemStack item) {
        if (item == null) return;
        if (item.getType() == Material.ARROW) {
            switching.add(player.getUniqueId());
            new PlayerListMenu(plugin).open(player, StaffAction.KICK);
            return;
        }
        if (item.getType() == Material.OAK_SIGN) {
            String targetName = pendingTargets.get(player.getUniqueId());
            if (targetName == null) return;
            Player target = Bukkit.getPlayerExact(targetName);
            if (target == null || !target.isOnline()) return;
            player.closeInventory();
            requestKickInput(player, target);
        }
    }
    private void handleVanish(Player player, InventoryClickEvent event) {
        if (plugin.getVanishManager().isVanished(player)) {
            plugin.getVanishManager().unvanish(player);
            player.sendMessage(plugin.getMessageManager().getStaff("vanish-off"));
        } else {
            plugin.getVanishManager().vanish(player);
            player.sendMessage(plugin.getMessageManager().getStaff("vanish-on"));
        }
        plugin.getConfigManager().playSound(player, "vanish");
        int vanishSlot = plugin.getConfigManager().getItemSlot(StaffMenu.STAFF_MENU_TITLE_KEY, "vanish");
        event.getInventory().setItem(vanishSlot, new StaffMenu(plugin).buildVanishItemPublic(player));
    }
    private void requestKickInput(Player player, Player target) {
        plugin.getChatInputManager().requestReason(player, reason -> {
            if (target.isOnline()) {
                String screen = plugin.getMessageManager().getRaw("kick-screen", "%reason%", reason);
                target.kickPlayer(screen);
                player.sendMessage(plugin.getMessageManager().getStaff("kicked-player", "%player%", target.getName(), "%reason%", reason));
                plugin.getConfigManager().playSound(player, "kick");
            }
        });
    }
    private void requestMuteInput(Player player, Player target) {
        plugin.getChatInputManager().requestTimedReason(player, input -> {
            String[] parts = input.split(" ", 2);
            long durationMs = TimeParser.parse(parts[0]);
            String reason = parts.length > 1 ? parts[1] : "No reason";
            if (durationMs == 0) {
                reason = input;
                durationMs = -1;
            }
            final long finalDuration = durationMs;
            final String finalReason = reason;
            if (target.isOnline()) {
                plugin.getMuteManager().mute(target, finalReason, finalDuration);
                plugin.getMessageManager().sendActionBar(target, "player-muted", "%reason%", finalReason);
                player.sendMessage(plugin.getMessageManager().getStaff("muted-player",
                        "%player%", target.getName(),
                        "%duration%", TimeParser.formatDuration(finalDuration),
                        "%reason%", finalReason));
                plugin.getConfigManager().playSound(player, "mute");
            }
        });
    }
    private void requestBanInput(Player player, Player target) {
        plugin.getChatInputManager().requestTimedReason(player, input -> {
            String[] parts = input.split(" ", 2);
            long durationMs = TimeParser.parse(parts[0]);
            String reason = parts.length > 1 ? parts[1] : "No reason";
            if (durationMs == 0) {
                reason = input;
                durationMs = -1;
            }
            final long finalDuration = durationMs;
            final String finalReason = reason;
            plugin.getBanManager().ban(target.getUniqueId(), target.getName(), finalReason, finalDuration, player.getName());
            String screen = plugin.getMessageManager().getRaw("ban-screen",
                    "%reason%", finalReason,
                    "%duration%", TimeParser.formatDuration(finalDuration));
            if (target.isOnline()) target.kickPlayer(screen);
            player.sendMessage(plugin.getMessageManager().getStaff("banned-player",
                    "%player%", target.getName(),
                    "%duration%", TimeParser.formatDuration(finalDuration),
                    "%reason%", finalReason));
            plugin.getConfigManager().playSound(player, "ban");
        });
    }
    private void requestWarnInput(Player player, Player target) {
        plugin.getChatInputManager().requestReason(player, reason -> {
            plugin.getWarnManager().addWarn(target.getUniqueId(), reason);
            int warns = plugin.getWarnManager().getWarnCount(target.getUniqueId());
            int max = plugin.getConfigManager().getMaxWarns();
            player.sendMessage(plugin.getMessageManager().getStaff("warned-player",
                    "%player%", target.getName(),
                    "%warns%", String.valueOf(warns),
                    "%max%", String.valueOf(max)));
            plugin.getConfigManager().playSound(player, "warn");
        });
    }
    private void executeAction(Player staff, Player target, StaffAction action, int slot) {
        switch (action) {
            case FREEZE -> {
                if (plugin.getFreezeManager().isFrozen(target)) {
                    plugin.getFreezeManager().unfreeze(target);
                    plugin.getMessageManager().sendActionBar(target, "player-unfrozen");
                    staff.sendMessage(plugin.getMessageManager().getStaff("unfroze-player", "%player%", target.getName()));
                } else {
                    plugin.getFreezeManager().freeze(target);
                    plugin.getMessageManager().sendActionBar(target, "player-now-frozen");
                    staff.sendMessage(plugin.getMessageManager().getStaff("froze-player", "%player%", target.getName()));
                }
                plugin.getConfigManager().playSound(staff, "freeze");
                staff.getOpenInventory().getTopInventory().setItem(slot, new PlayerListMenu(plugin).buildPlayerHead(target, action));
            }
            case TELEPORT -> {
                staff.teleport(target.getLocation());
                staff.sendMessage(plugin.getMessageManager().getStaff("teleported-to-player", "%player%", target.getName()));
                plugin.getConfigManager().playSound(staff, "teleport");
            }
            case CLEAR_INVENTORY -> {
                target.getInventory().clear();
                plugin.getMessageManager().sendActionBar(target, "player-inventory-cleared");
                staff.sendMessage(plugin.getMessageManager().getStaff("cleared-inventory", "%player%", target.getName()));
                plugin.getConfigManager().playSound(staff, "clear");
                staff.getOpenInventory().getTopInventory().setItem(slot, new PlayerListMenu(plugin).buildPlayerHead(target, action));
            }
        }
    }
}
