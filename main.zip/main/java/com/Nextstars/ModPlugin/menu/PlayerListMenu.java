package com.Nextstars.ModPlugin.menu;
import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.action.StaffAction;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import com.Nextstars.ModPlugin.util.StaffInventoryHolder;
import java.util.ArrayList;
import java.util.List;
public class PlayerListMenu {
    public static final String PLAYER_LIST_MENU_KEY = "player-list";
    public static final int PLAYER_SLOTS = 45;
    public static final int BACK_SLOT_DEFAULT = 49;
    private final ModPlugin plugin;
    public PlayerListMenu(ModPlugin plugin) {
        this.plugin = plugin;
    }
    public String getTitle() {
        return plugin.getConfigManager().getMenuTitle(PLAYER_LIST_MENU_KEY);
    }
    public void open(Player player, StaffAction action) {
        int size = plugin.getConfigManager().getMenuSize(PLAYER_LIST_MENU_KEY);
        Inventory inventory = Bukkit.createInventory(new StaffInventoryHolder(PLAYER_LIST_MENU_KEY), size, getTitle());
        int slot = 0;
        for (Player target : Bukkit.getOnlinePlayers()) {
            if (slot >= PLAYER_SLOTS) break;
            inventory.setItem(slot++, buildPlayerHead(target, action));
        }
        fillNavRow(inventory, size);
        player.openInventory(inventory);
        plugin.getConfigManager().playSound(player, "menu-open");
    }
    private void fillNavRow(Inventory inventory, int size) {
        int navStart = size - 9;
        Material border = plugin.getConfigManager().getBorderMaterial(PLAYER_LIST_MENU_KEY);
        int backSlot = plugin.getConfigManager().getIntSetting(PLAYER_LIST_MENU_KEY, "back-slot", BACK_SLOT_DEFAULT);
        for (int i = navStart; i < size; i++) {
            if (i == backSlot) {
                inventory.setItem(i, buildBackButton());
            } else {
                ItemStack pane = new ItemStack(border);
                ItemMeta m = pane.getItemMeta();
                m.setDisplayName(" ");
                pane.setItemMeta(m);
                inventory.setItem(i, pane);
            }
        }
    }
    private ItemStack buildBackButton() {
        ItemStack item = new ItemStack(Material.ARROW);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&7« &fBack"));
        item.setItemMeta(meta);
        return item;
    }
    public ItemStack buildPlayerHead(Player target, StaffAction action) {
        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        meta.setOwningPlayer(target);
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', "&c" + target.getName()));
        boolean frozen = plugin.getFreezeManager().isFrozen(target);
        boolean muted = plugin.getMuteManager().isMuted(target);
        boolean banned = plugin.getBanManager().isBanned(target.getUniqueId());
        List<String> lore = new ArrayList<>();
        lore.add(ChatColor.translateAlternateColorCodes('&', "&7Nick: &c" + target.getName()));
        lore.add(ChatColor.translateAlternateColorCodes('&', "&7❤ Life: " + (int) target.getHealth() + " | &7🍖 Hunger: " + target.getFoodLevel()));
        lore.add(ChatColor.translateAlternateColorCodes('&', "&7Is-frozen: " + (frozen ? "&ctrue" : "&afalse")));
        lore.add(ChatColor.translateAlternateColorCodes('&', "&7Is-muted: " + (muted ? "&ctrue" : "&afalse")));
        lore.add(ChatColor.translateAlternateColorCodes('&', "&7Is-banned: " + (banned ? "&ctrue" : "&afalse")));
        lore.add("");
        lore.add(ChatColor.translateAlternateColorCodes('&', "&8» &eClick to " + getActionLabel(action) + "."));
        meta.setLore(lore);
        skull.setItemMeta(meta);
        return skull;
    }
    private String getActionLabel(StaffAction action) {
        return switch (action) {
            case FREEZE -> "toggle freeze";
            case KICK -> "view info & kick";
            case MUTE -> "mute/unmute";
            case TELEPORT -> "teleport";
            case BAN -> "ban";
            case CLEAR_INVENTORY -> "clear inventory";
            case WARN -> "warn";
            case INVSEE -> "open inventory";
            default -> "select";
        };
    }
}
