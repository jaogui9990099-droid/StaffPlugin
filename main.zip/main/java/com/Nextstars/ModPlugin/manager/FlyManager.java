package com.Nextstars.ModPlugin.manager;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;
public class FlyManager {
    public boolean isFlyEnabled(Player player) {
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) return true;
        return player.getAllowFlight();
    }
    public boolean toggle(Player player) {
        boolean enabled;
        if (player.getGameMode() == GameMode.CREATIVE || player.getGameMode() == GameMode.SPECTATOR) {
            enabled = !player.isFlying();
            player.setFlying(enabled);
            return enabled;
        }
        enabled = !player.getAllowFlight();
        player.setAllowFlight(enabled);
        player.setFlying(enabled);
        return enabled;
    }
}
