package com.Nextstars.ModPlugin.manager;
import com.Nextstars.ModPlugin.ModPlugin;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import java.io.File;
public class MessageManager {
    private static final String STAFF_PREFIX = ChatColor.translateAlternateColorCodes('&', "&l&aSTAFF &r&7| ");
    private static final String PLAYER_PREFIX = ChatColor.translateAlternateColorCodes('&', "&e&lWarning: ");
    private final ModPlugin plugin;
    private FileConfiguration messages;
    public MessageManager(ModPlugin plugin) {
        this.plugin = plugin;
        load();
    }
    private void load() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) plugin.saveResource("messages.yml", false);
        messages = YamlConfiguration.loadConfiguration(file);
    }
    public void reload() {
        load();
    }
    public String getStaff(String key) {
        String raw = messages.getString("messages." + key, "&cMissing: " + key);
        return STAFF_PREFIX + ChatColor.translateAlternateColorCodes('&', raw);
    }
    public String getStaff(String key, String... replacements) {
        String msg = getStaff(key);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            msg = msg.replace(replacements[i], replacements[i + 1]);
        }
        return msg;
    }
    public void sendActionBar(Player player, String key) {
        String raw = messages.getString("messages." + key, key);
        String msg = ChatColor.translateAlternateColorCodes('&', raw);
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(msg));
    }
    public void sendActionBar(Player player, String key, String... replacements) {
        String raw = messages.getString("messages." + key, key);
        String msg = ChatColor.translateAlternateColorCodes('&', raw);
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            msg = msg.replace(replacements[i], replacements[i + 1]);
        }
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(msg));
    }
    public void sendRawActionBar(Player player, String message) {
        String msg = ChatColor.translateAlternateColorCodes('&', message);
        player.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(msg));
    }
    public String getRaw(String key) {
        String raw = messages.getString("messages." + key);
        if (raw == null) raw = messages.getString(key, key);
        return ChatColor.translateAlternateColorCodes('&', raw);
    }
    public String getRaw(String key, String... replacements) {
        String msg = getRaw(key);
        msg = applyReplacements(msg, replacements);
        return msg;
    }

    public String getDiscord(String key) {
        String raw = messages.getString("discord." + key, "&cMissing: discord." + key);
        return ChatColor.translateAlternateColorCodes('&', raw);
    }

    public String getDiscord(String key, String... replacements) {
        String msg = getDiscord(key);
        msg = applyReplacements(msg, replacements);
        return msg;
    }

    private String applyReplacements(String msg, String... replacements) {
        if (replacements == null) return msg;
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            String k = replacements[i] == null ? "" : replacements[i];
            String v = replacements[i + 1] == null ? "" : replacements[i + 1];

            if (!k.isEmpty()) {
                msg = msg.replace(k, v);
                String kLower = k.toLowerCase();
                msg = msg.replace(kLower, v);
                msg = msg.replace(k.toUpperCase(), v);
                msg = msg.replace(k.replace("_", " "), v);
                msg = msg.replace(k.replace("_", " ").toLowerCase(), v);
                msg = msg.replace(k.replace("_", " ").toUpperCase(), v);
            }

            if ("%ban_id%".equalsIgnoreCase(k)) {
                msg = msg.replace("%banid%", v).replace("%BANID%", v);
                msg = msg.replace("%ban id%", v).replace("%BAN ID%", v);
            }
            if ("%Number%".equalsIgnoreCase(k)) {
                msg = msg.replace("%NUMBER%", v);
            }
        }
        return msg;
    }
    public String get(String key) { return getStaff(key); }
    public String get(String key, String placeholder, String value) { return getStaff(key, placeholder, value); }
}
