package com.Nextstars.ModPlugin.manager;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
public class BadWordManager {
    private final ModPlugin plugin;
    private List<String> badWords = new ArrayList<>();
    public BadWordManager(ModPlugin plugin) {
        this.plugin = plugin;
        load();
    }
    public void load() {
        File file = new File(plugin.getDataFolder(), "badwords.yml");
        if (!file.exists()) plugin.saveResource("badwords.yml", false);
        FileConfiguration data = YamlConfiguration.loadConfiguration(file);
        badWords = data.getStringList("words");
    }
    public List<String> getBadWords() {
        return badWords;
    }
}
