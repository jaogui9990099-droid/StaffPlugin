package com.Nextstars.ModPlugin.manager;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
public class VanishManager {
    private final ModPlugin plugin;
    private final Set<UUID> vanishedPlayers = new HashSet<>();
    public VanishManager(ModPlugin plugin) {
        this.plugin = plugin;
    }
    public void vanish(Player player) {
        vanishedPlayers.add(player.getUniqueId());
        for (Player online : Bukkit.getOnlinePlayers()) {
            if (!online.hasPermission("modplugin.staff")) {
                online.hidePlayer(plugin, player);
            }
        }
        player.setPlayerListName(null);
    }
    public void unvanish(Player player) {
        vanishedPlayers.remove(player.getUniqueId());
        for (Player online : Bukkit.getOnlinePlayers()) {
            online.showPlayer(plugin, player);
        }
        player.setPlayerListName(player.getName());
    }
    public boolean isVanished(Player player) {
        return vanishedPlayers.contains(player.getUniqueId());
    }
    public void applyToNewJoiner(Player newPlayer) {
        for (UUID uuid : vanishedPlayers) {
            Player vanished = Bukkit.getPlayer(uuid);
            if (vanished != null && vanished.isOnline()) {
                if (!newPlayer.hasPermission("modplugin.staff")) {
                    newPlayer.hidePlayer(plugin, vanished);
                }
            }
        }
    }
}
