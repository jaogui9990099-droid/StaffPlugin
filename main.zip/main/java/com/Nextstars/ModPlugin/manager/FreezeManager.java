package com.Nextstars.ModPlugin.manager;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
public class FreezeManager {
    private final ModPlugin plugin;
    private final Set<UUID> frozenPlayers = new HashSet<>();
    private final File file;
    private FileConfiguration data;
    public FreezeManager(ModPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "frozen.yml");
        load();
    }
    private void load() {
        data = YamlConfiguration.loadConfiguration(file);
        List<String> list = data.getStringList("frozen");
        for (String entry : list) {
            frozenPlayers.add(UUID.fromString(entry));
        }
    }
    private void save() {
        List<String> list = new ArrayList<>();
        for (UUID uuid : frozenPlayers) {
            list.add(uuid.toString());
        }
        data.set("frozen", list);
        try {
            data.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void freeze(Player player) {
        frozenPlayers.add(player.getUniqueId());
        save();
    }
    public void unfreeze(Player player) {
        frozenPlayers.remove(player.getUniqueId());
        save();
    }
    public boolean isFrozen(Player player) {
        return frozenPlayers.contains(player.getUniqueId());
    }
}
