package com.Nextstars.ModPlugin.manager;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
public class SpamManager {
    private final Map<UUID, String> lastMessages = new HashMap<>();
    private final Map<UUID, Integer> repeatCounts = new HashMap<>();
    public int registerMessage(UUID uuid, String message) {
        String last = lastMessages.get(uuid);
        if (message.equalsIgnoreCase(last)) {
            int count = repeatCounts.getOrDefault(uuid, 0) + 1;
            repeatCounts.put(uuid, count);
            return count;
        } else {
            lastMessages.put(uuid, message);
            repeatCounts.put(uuid, 0);
            return 0;
        }
    }
    public void reset(UUID uuid) {
        lastMessages.remove(uuid);
        repeatCounts.remove(uuid);
    }
}
