package com.Nextstars.ModPlugin.manager;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Sign;
import org.bukkit.block.sign.Side;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.SignChangeEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.function.Consumer;

public class ChatInputManager implements Listener {

    private final ModPlugin plugin;
    private final Map<UUID, PendingInput> pending = new HashMap<>();

    public ChatInputManager(ModPlugin plugin) {
        this.plugin = plugin;
    }

    public void requestReason(Player player, Consumer<String> callback) {
        request(player, new String[]{"^^^^^^", "enter a", "reason here", ""}, callback);
    }

    public void requestTimedReason(Player player, Consumer<String> callback) {
        request(player, new String[]{"^^^^^^", "enter time", "+ reason", "here"}, callback);
    }

    public void request(Player player, String[] promptLines, Consumer<String> callback) {
        cancel(player.getUniqueId());
        Block block = findSignBlock(player);
        if (block == null) {
            player.sendMessage(plugin.getMessageManager().getStaff("sign-input-unavailable"));
            return;
        }

        String[] lines = sanitizePrompt(promptLines);
        BlockState originalState = block.getState();
        block.setType(Material.OAK_SIGN, false);

        Sign sign = (Sign) block.getState();
        for (int i = 0; i < 4; i++) {
            sign.setLine(i, lines[i]);
        }
        sign.setEditable(true);
        sign.setWaxed(false);
        sign.setAllowedEditorUniqueId(player.getUniqueId());
        sign.update(true, false);

        BukkitTask timeoutTask = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            PendingInput active = pending.get(player.getUniqueId());
            if (active != null) {
                cancel(player.getUniqueId());
            }
        }, 20L * 45L);

        pending.put(player.getUniqueId(), new PendingInput(block.getLocation(), originalState, lines, callback, timeoutTask));
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (!player.isOnline()) {
                cancel(player.getUniqueId());
                return;
            }
            player.sendSignChange(block.getLocation(), lines);
            player.openSign((Sign) block.getState(), Side.FRONT);
        });
    }

    public boolean hasPending(UUID uuid) {
        return pending.containsKey(uuid);
    }

    public void handle(UUID uuid, String input) {
        PendingInput request = pending.remove(uuid);
        if (request == null) return;
        if (request.timeoutTask() != null) {
            request.timeoutTask().cancel();
        }
        restore(request);
        Bukkit.getScheduler().runTask(plugin, () -> request.callback().accept(input));
    }

    public void cancel(UUID uuid) {
        PendingInput request = pending.remove(uuid);
        if (request == null) return;
        if (request.timeoutTask() != null) {
            request.timeoutTask().cancel();
        }
        restore(request);
    }

    @EventHandler
    public void onSignChange(SignChangeEvent event) {
        PendingInput request = pending.get(event.getPlayer().getUniqueId());
        if (request == null) return;
        if (!event.getBlock().getLocation().equals(request.location())) return;
        event.setCancelled(true);
        String value = joinInput(request.promptLines(), event.getLines());
        if (value.isBlank()) {
            Bukkit.getScheduler().runTask(plugin, () -> {
                Player player = event.getPlayer();
                if (player.isOnline()) {
                    player.sendMessage(plugin.getMessageManager().getStaff("sign-input-empty"));
                    request(player, request.promptLines(), request.callback());
                }
            });
            pending.remove(event.getPlayer().getUniqueId());
            if (request.timeoutTask() != null) {
                request.timeoutTask().cancel();
            }
            restore(request);
            return;
        }
        handle(event.getPlayer().getUniqueId(), value);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        cancel(event.getPlayer().getUniqueId());
    }

    private void restore(PendingInput request) {
        request.originalState().update(true, false);
    }

    private Block findSignBlock(Player player) {
        int[][] offsets = {
                {0, 2, 0},
                {1, 2, 0},
                {-1, 2, 0},
                {0, 2, 1},
                {0, 2, -1},
                {0, 3, 0},
                {1, 3, 0},
                {-1, 3, 0}
        };
        for (int[] offset : offsets) {
            Block block = player.getLocation().getBlock().getRelative(offset[0], offset[1], offset[2]);
            if (block.getType().isAir()) {
                return block;
            }
        }
        return null;
    }

    private String[] sanitizePrompt(String[] promptLines) {
        String[] output = new String[4];
        for (int i = 0; i < 4; i++) {
            String line = i < promptLines.length && promptLines[i] != null ? promptLines[i].trim() : "";
            output[i] = line.length() > 15 ? line.substring(0, 15) : line;
        }
        return output;
    }

    private String joinInput(String[] promptLines, String[] submittedLines) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < submittedLines.length; i++) {
            String line = submittedLines[i] == null ? "" : submittedLines[i].trim();
            if (line.isEmpty()) continue;
            if (i < promptLines.length && line.equalsIgnoreCase(promptLines[i])) continue;
            if (builder.length() > 0) {
                builder.append(' ');
            }
            builder.append(line);
        }
        return builder.toString().trim();
    }

    private record PendingInput(Location location, BlockState originalState, String[] promptLines,
                                Consumer<String> callback, BukkitTask timeoutTask) {
    }
}
