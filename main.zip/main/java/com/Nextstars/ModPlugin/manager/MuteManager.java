package com.Nextstars.ModPlugin.manager;
import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.util.TimeParser;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import java.io.File;
import java.io.IOException;
import java.util.UUID;
public class MuteManager {
    private final ModPlugin plugin;
    private final File file;
    private FileConfiguration data;
    public MuteManager(ModPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "muted.yml");
        load();
        startHotbarTask();
    }
    private void load() {
        data = YamlConfiguration.loadConfiguration(file);
    }
    private void save() {
        try { data.save(file); } catch (IOException e) { e.printStackTrace(); }
    }
    public void mute(Player player, String reason, long durationMs) {
        String path = "muted." + player.getUniqueId();
        long expires = durationMs < 0 ? -1 : System.currentTimeMillis() + durationMs;
        data.set(path + ".reason", reason);
        data.set(path + ".expires", expires);
        data.set(path + ".duration", TimeParser.formatDuration(durationMs));
        save();
    }
    public void unmute(UUID uuid) {
        data.set("muted." + uuid, null);
        save();
    }
    public boolean isMuted(Player player) {
        return isMuted(player.getUniqueId());
    }
    public boolean isMuted(UUID uuid) {
        String path = "muted." + uuid;
        if (!data.contains(path)) return false;
        long expires = data.getLong(path + ".expires", -1);
        if (expires == -1) return true;
        if (System.currentTimeMillis() > expires) {
            data.set(path, null);
            save();
            return false;
        }
        return true;
    }
    public String getReason(UUID uuid) {
        return data.getString("muted." + uuid + ".reason", "No reason");
    }
    public String getTimeLeft(UUID uuid) {
        long expires = data.getLong("muted." + uuid + ".expires", -1);
        if (expires < 0) return "Permanent";
        long remaining = expires - System.currentTimeMillis();
        return remaining <= 0 ? "Expired" : TimeParser.format(remaining);
    }
    private void startHotbarTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (!isMuted(player)) continue;
                    plugin.getMessageManager().sendActionBar(player, "actionbar-muted",
                            "%time_left%", getTimeLeft(player.getUniqueId()),
                            "%reason%", getReason(player.getUniqueId()));
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }
}
