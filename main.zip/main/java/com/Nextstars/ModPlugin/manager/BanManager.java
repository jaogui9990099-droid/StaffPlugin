package com.Nextstars.ModPlugin.manager;

import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.appeal.AppealRecord;
import com.Nextstars.ModPlugin.util.TimeParser;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import java.util.UUID;
public class BanManager {
    private final ModPlugin plugin;
    private final File file;
    private FileConfiguration data;
    public BanManager(ModPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "bans.yml");
        load();
    }
    private void load() {
        data = YamlConfiguration.loadConfiguration(file);
    }
    private void save() {
        try { data.save(file); } catch (IOException e) { e.printStackTrace(); }
    }
    public String ban(UUID uuid, String playerName, String reason, long durationMs, String bannedBy) {
        String banId = generateBanId();
        return banWithId(uuid, playerName, reason, durationMs, bannedBy, banId, true);
    }

    public String banWithId(UUID uuid, String playerName, String reason, long durationMs, String bannedBy, String banId, boolean createAppealRecord) {
        String path = "bans." + uuid;
        long now = System.currentTimeMillis();
        long expires = durationMs < 0 ? -1 : now + durationMs;
        data.set(path + ".name", playerName);
        data.set(path + ".reason", reason);
        data.set(path + ".expires", expires);
        data.set(path + ".duration", TimeParser.formatDuration(durationMs));
        data.set(path + ".banned-by", bannedBy);
        data.set(path + ".banned-at", now);
        data.set(path + ".ban-id", banId);
        save();

        if (createAppealRecord && plugin.getAppealManager() != null) {
            long keepMs = 30L * 24L * 60L * 60L * 1000L;
            long recordExpires = now + keepMs;
            AppealRecord r = new AppealRecord(
                    banId,
                    uuid,
                    playerName,
                    now,
                    recordExpires,
                    reason,
                    "",
                    0,
                    "",
                    null,
                    "",
                    ""
            );
            plugin.getAppealManager().save(r);
        }

        return banId;
    }

    public String getBanId(UUID uuid) {
        String path = "bans." + uuid + ".ban-id";
        String id = data.getString(path, "");
        if (id == null || id.isBlank()) {
            id = generateBanId();
            data.set(path, id);
            save();
        }
        return id;
    }

    private String generateBanId() {
        return java.util.UUID.randomUUID().toString().replace("-", "").substring(0, 16).toUpperCase();
    }

    public BanEntry getByBanId(String banId) {
        if (banId == null) return null;
        String id = banId.trim();
        var sec = data.getConfigurationSection("bans");
        if (sec == null) return null;
        for (String key : sec.getKeys(false)) {
            String base = "bans." + key;
            String stored = data.getString(base + ".ban-id", "");
            if (stored == null || stored.isBlank()) {
                String generated = generateBanId();
                data.set(base + ".ban-id", generated);
                save();
                stored = generated;
            }
            if (stored.equalsIgnoreCase(id)) {
                java.util.UUID uuid;
                try {
                    uuid = java.util.UUID.fromString(key);
                } catch (Exception e) {
                    continue;
                }
                String name = data.getString(base + ".name", "Unknown");
                String reason = data.getString(base + ".reason", "No reason provided");
                String bannedBy = data.getString(base + ".banned-by", "Unknown");
                long bannedAt = data.getLong(base + ".banned-at", 0L);
                long expires = data.getLong(base + ".expires", -1L);
                return new BanEntry(uuid, name, stored, reason, bannedBy, bannedAt, expires);
            }
        }
        return null;
    }

    public static class BanEntry {
        private final java.util.UUID uuid;
        private final String name;
        private final String banId;
        private final String reason;
        private final String bannedBy;
        private final long bannedAt;
        private final long expires;

        public BanEntry(java.util.UUID uuid, String name, String banId, String reason, String bannedBy, long bannedAt, long expires) {
            this.uuid = uuid;
            this.name = name;
            this.banId = banId;
            this.reason = reason;
            this.bannedBy = bannedBy;
            this.bannedAt = bannedAt;
            this.expires = expires;
        }

        public java.util.UUID getUuid() { return uuid; }
        public String getName() { return name; }
        public String getBanId() { return banId; }
        public String getReason() { return reason; }
        public String getBannedBy() { return bannedBy; }
        public long getBannedAt() { return bannedAt; }
        public long getExpires() { return expires; }
    }

    public void invalidateBanIdIfMatch(java.util.UUID uuid, String banId) {
        if (uuid == null || banId == null) return;
        String path = "bans." + uuid + ".ban-id";
        String stored = data.getString(path, "");
        if (stored != null && stored.equalsIgnoreCase(banId)) {
            data.set(path, "");
            save();
        }
    }

    public void unban(UUID uuid) {
        data.set("bans." + uuid, null);
        save();
        if (plugin.getAutoBanManager() != null) {
            plugin.getAutoBanManager().resetPlayer(uuid);
        }
    }
    public boolean isBanned(UUID uuid) {
        String path = "bans." + uuid;
        if (!data.contains(path)) return false;
        long expires = data.getLong(path + ".expires", -1);
        if (expires == -1) return true;
        if (System.currentTimeMillis() > expires) {
            data.set(path, null);
            save();
            return false;
        }
        return true;
    }
    public String getReason(UUID uuid) {
        return data.getString("bans." + uuid + ".reason", "No reason provided");
    }
    public String getDuration(UUID uuid) {
        long expires = data.getLong("bans." + uuid + ".expires", -1);
        if (expires < 0) return "Permanent";
        long remaining = expires - System.currentTimeMillis();
        return remaining <= 0 ? "Expired" : TimeParser.format(remaining);
    }
}
