package com.Nextstars.ModPlugin.manager;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
public class MuteReasonManager {
    private final ModPlugin plugin;
    private FileConfiguration data;
    public MuteReasonManager(ModPlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void reload() {
        load();
    }
    private void load() {
        File file = new File(plugin.getDataFolder(), "mutereasons.yml");
        if (!file.exists()) plugin.saveResource("mutereasons.yml", false);
        data = YamlConfiguration.loadConfiguration(file);
    }
    public List<String> getTabSuggestions() {
        List<String> result = new ArrayList<>();
        ConfigurationSection section = data.getConfigurationSection("reasons");
        if (section == null) return result;
        for (String key : section.getKeys(false)) {
            String display = section.getString(key + ".display", key);
            String time = section.getString(key + ".time", "1h");
            result.add(time + " " + display);
        }
        return result;
    }
    public String getTimeForKey(String key) {
        return data.getString("reasons." + key + ".time", "1h");
    }
}
