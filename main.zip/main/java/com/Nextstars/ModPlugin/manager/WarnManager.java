package com.Nextstars.ModPlugin.manager;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
public class WarnManager {
    private final ModPlugin plugin;
    private final File file;
    private FileConfiguration data;
    public WarnManager(ModPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "warns.yml");
        load();
    }
    private void load() {
        data = YamlConfiguration.loadConfiguration(file);
    }
    private void save() {
        try {
            data.save(file);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void addWarn(UUID uuid, String reason) {
        String path = "warns." + uuid.toString();
        List<String> warns = data.getStringList(path);
        warns.add(reason);
        data.set(path, warns);
        save();
        int count = warns.size();
        int max = plugin.getConfigManager().getMaxWarns();
        Player target = Bukkit.getPlayer(uuid);
        if (target == null || !target.isOnline()) return;
        if (count >= max) {
            handleAutoBan(target, count, max);
        } else if (plugin.getConfigManager().isKickOnWarn()) {
            handleWarnKick(target, reason, count, max);
        }
    }
    private void handleWarnKick(Player target, String reason, int warns, int max) {
        String screen = plugin.getMessageManager().getRaw("warn-kick-screen",
                "%reason%", reason,
                "%warns%", String.valueOf(warns),
                "%max%", String.valueOf(max));
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (target.isOnline()) target.kickPlayer(screen);
        });
    }
    private void handleAutoBan(Player target, int warns, int max) {
        String reason = plugin.getConfigManager().getWarnAutoBanReason();
        String screen = plugin.getMessageManager().getRaw("warn-ban-screen",
                "%warns%", String.valueOf(warns),
                "%max%", String.valueOf(max));
        Bukkit.getScheduler().runTask(plugin, () -> {
            if (target.isOnline()) {
                plugin.getBanManager().ban(target.getUniqueId(), target.getName(), reason, -1, "AutoMod");
                target.kickPlayer(screen);
                clearWarns(target.getUniqueId());
                if (plugin.getConfigManager().isBroadcastAutoBan()) {
                    String broadcast = plugin.getMessageManager().getRaw("warn-autoban-broadcast",
                            "%player%", target.getName(),
                            "%max%", String.valueOf(max));
                    Bukkit.broadcastMessage(broadcast);
                }
            }
        });
    }
    public int getWarnCount(UUID uuid) {
        return data.getStringList("warns." + uuid.toString()).size();
    }
    public List<String> getWarns(UUID uuid) {
        return new ArrayList<>(data.getStringList("warns." + uuid.toString()));
    }
    public void clearWarns(UUID uuid) {
        data.set("warns." + uuid.toString(), null);
        save();
    }
}
