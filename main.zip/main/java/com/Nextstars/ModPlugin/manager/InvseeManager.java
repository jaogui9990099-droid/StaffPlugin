package com.Nextstars.ModPlugin.manager;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class InvseeManager {

    public record Session(UUID viewer, UUID target, boolean allowEdit, Inventory inventory) {}

    private final ModPlugin plugin;
    private final Map<UUID, Session> byViewer = new HashMap<>();
    private final Map<UUID, UUID> targetToViewer = new HashMap<>();
    private final Set<UUID> editing = new HashSet<>();
    private final Map<UUID, BukkitTask> pendingSync = new HashMap<>();

    public InvseeManager(ModPlugin plugin) {
        this.plugin = plugin;
    }

    public void start(Player viewer, Player target, boolean allowEdit, Inventory inventory) {
        end(viewer);
        UUID vid = viewer.getUniqueId();
        UUID tid = target.getUniqueId();
        Session session = new Session(vid, tid, allowEdit, inventory);
        byViewer.put(vid, session);
        targetToViewer.put(tid, vid);
    }

    public void end(Player viewer) {
        UUID vid = viewer.getUniqueId();
        Session old = byViewer.remove(vid);
        if (old != null) targetToViewer.remove(old.target());
        editing.remove(vid);
        BukkitTask t = pendingSync.remove(vid);
        if (t != null) t.cancel();
    }

    public void endByTarget(UUID targetId) {
        UUID vid = targetToViewer.remove(targetId);
        if (vid == null) return;
        byViewer.remove(vid);
        editing.remove(vid);
        BukkitTask t = pendingSync.remove(vid);
        if (t != null) t.cancel();
        Player viewer = Bukkit.getPlayer(vid);
        if (viewer != null && viewer.isOnline()) viewer.closeInventory();
    }

    public Session get(Player viewer) {
        return byViewer.get(viewer.getUniqueId());
    }

    public Session getByTarget(UUID targetId) {
        UUID vid = targetToViewer.get(targetId);
        if (vid == null) return null;
        return byViewer.get(vid);
    }

    public boolean isViewing(Player viewer) {
        return byViewer.containsKey(viewer.getUniqueId());
    }

    public boolean isBeingViewed(UUID targetId) {
        return targetToViewer.containsKey(targetId);
    }

    public void markEditing(UUID viewerId) {
        editing.add(viewerId);
    }

    public void markDoneEditing(UUID viewerId) {
        editing.remove(viewerId);
    }

    public boolean isEditing(UUID viewerId) {
        return editing.contains(viewerId);
    }

    public void syncTargetToGui(Session session, Player target) {
        if (session == null || session.inventory() == null) return;
        if (isEditing(session.viewer())) return;
        Inventory inv = session.inventory();

        ItemStack[] contents = target.getInventory().getContents();
        for (int i = 0; i < 36 && i < contents.length; i++) {
            inv.setItem(i, contents[i] != null ? contents[i].clone() : null);
        }

        int helmetSlot  = plugin.getConfigManager().getInt("invsee.gui.slots.helmet",     47);
        int chestSlot   = plugin.getConfigManager().getInt("invsee.gui.slots.chestplate", 48);
        int legsSlot    = plugin.getConfigManager().getInt("invsee.gui.slots.leggings",   49);
        int bootsSlot   = plugin.getConfigManager().getInt("invsee.gui.slots.boots",      50);
        int offhandSlot = plugin.getConfigManager().getInt("invsee.gui.slots.offhand",    52);

        ItemStack helmet  = target.getInventory().getHelmet();
        ItemStack chest   = target.getInventory().getChestplate();
        ItemStack legs    = target.getInventory().getLeggings();
        ItemStack boots   = target.getInventory().getBoots();
        ItemStack offhand = target.getInventory().getItemInOffHand();

        inv.setItem(helmetSlot,  helmet  != null ? helmet.clone()  : null);
        inv.setItem(chestSlot,   chest   != null ? chest.clone()   : null);
        inv.setItem(legsSlot,    legs    != null ? legs.clone()    : null);
        inv.setItem(bootsSlot,   boots   != null ? boots.clone()   : null);
        inv.setItem(offhandSlot, offhand != null ? offhand.clone() : null);
    }

    public void syncGuiToTarget(Session session, Player target) {
        if (session == null || session.inventory() == null) return;
        Inventory inv = session.inventory();

        ItemStack[] newContents = new ItemStack[36];
        for (int i = 0; i < 36; i++) {
            ItemStack item = inv.getItem(i);
            newContents[i] = item != null ? item.clone() : null;
        }
        target.getInventory().setContents(newContents);

        int helmetSlot  = plugin.getConfigManager().getInt("invsee.gui.slots.helmet",     47);
        int chestSlot   = plugin.getConfigManager().getInt("invsee.gui.slots.chestplate", 48);
        int legsSlot    = plugin.getConfigManager().getInt("invsee.gui.slots.leggings",   49);
        int bootsSlot   = plugin.getConfigManager().getInt("invsee.gui.slots.boots",      50);
        int offhandSlot = plugin.getConfigManager().getInt("invsee.gui.slots.offhand",    52);

        target.getInventory().setHelmet(inv.getItem(helmetSlot));
        target.getInventory().setChestplate(inv.getItem(chestSlot));
        target.getInventory().setLeggings(inv.getItem(legsSlot));
        target.getInventory().setBoots(inv.getItem(bootsSlot));
        target.getInventory().setItemInOffHand(inv.getItem(offhandSlot));
        target.updateInventory();
    }

    public void scheduleTargetToGui(UUID viewerId, Session session, Player target) {
        BukkitTask old = pendingSync.remove(viewerId);
        if (old != null) old.cancel();
        BukkitTask t = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            pendingSync.remove(viewerId);
            markDoneEditing(viewerId);
            syncTargetToGui(session, target);
        }, 3L);
        pendingSync.put(viewerId, t);
    }
}
