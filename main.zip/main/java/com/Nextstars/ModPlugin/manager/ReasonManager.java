package com.Nextstars.ModPlugin.manager;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

public class ReasonManager {

    public enum Type {
        BAN("bans"),
        WARN("warns"),
        KICK("kicks"),
        MUTE("mutes");

        private final String path;

        Type(String path) {
            this.path = path;
        }

        public String path() {
            return path;
        }
    }

    private final ModPlugin plugin;
    private FileConfiguration data;

    public ReasonManager(ModPlugin plugin) {
        this.plugin = plugin;
        load();
    }

    public void reload() {
        load();
    }

    private void load() {
        File file = new File(plugin.getDataFolder(), "reason.yml");
        if (!file.exists()) plugin.saveResource("reason.yml", false);
        data = YamlConfiguration.loadConfiguration(file);
    }

    public String resolveReason(Type type, String input) {
        if (input == null) return "";
        String trimmed = input.trim();
        if (trimmed.isEmpty()) return trimmed;

        ConfigurationSection root = data.getConfigurationSection(type.path());
        if (root == null) return trimmed;

        String key = trimmed.toLowerCase(Locale.ROOT);
        if (root.isConfigurationSection(key)) {
            return root.getString(key + ".Reason", trimmed);
        }

        for (String k : root.getKeys(false)) {
            String name = root.getString(k + ".Name", "");
            if (!name.isEmpty() && name.equalsIgnoreCase(trimmed)) {
                return root.getString(k + ".Reason", trimmed);
            }
        }
        return trimmed;
    }

    public List<String> getKeys(Type type) {
        ConfigurationSection root = data.getConfigurationSection(type.path());
        if (root == null) return Collections.emptyList();
        return new ArrayList<>(root.getKeys(false));
    }
}
