package com.Nextstars.ModPlugin.manager;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.configuration.ConfigurationSection;
import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
public class ConfigManager {
    private final ModPlugin plugin;
    private FileConfiguration config;
    private FileConfiguration menu;
    public ConfigManager(ModPlugin plugin) {
        this.plugin = plugin;
        load();
    }
    public void load() {
        File file = new File(plugin.getDataFolder(), "config.yml");
        if (!file.exists()) plugin.saveResource("config.yml", false);

        plugin.reloadConfig();
        config = plugin.getConfig();

        File menuFile = new File(plugin.getDataFolder(), "menu.yml");
        if (!menuFile.exists()) plugin.saveResource("menu.yml", false);
        menu = YamlConfiguration.loadConfiguration(menuFile);
    }
    public void playSound(Player player, String soundKey) {
        FileConfiguration src = (menu != null && menu.contains("sounds." + soundKey)) ? menu : config;
        if (!src.getBoolean("sounds.enabled", true)) return;
        String id = src.getString("sounds." + soundKey + ".id");
        if (id == null) return;
        try {
            Sound sound = Sound.valueOf(id);
            float volume = (float) src.getDouble("sounds." + soundKey + ".volume", 1.0);
            float pitch  = (float) src.getDouble("sounds." + soundKey + ".pitch",  1.0);
            player.playSound(player.getLocation(), sound, volume, pitch);
        } catch (IllegalArgumentException ignored) {}
    }
    public String getMenuTitle(String menuKey) {
        return ChatColor.translateAlternateColorCodes('&', menu.getString("menus." + menuKey + ".title", config.getString("menus." + menuKey + ".title", "&8Menu")));
    }
    public int getMenuSize(String menuKey) {
        return menu.getInt("menus." + menuKey + ".rows", config.getInt("menus." + menuKey + ".rows", 3)) * 9;
    }
    public Material getBorderMaterial(String menuKey) {
        try {
            return Material.valueOf(menu.getString("menus." + menuKey + ".border-material", config.getString("menus." + menuKey + ".border-material", "BLACK_STAINED_GLASS_PANE")));
        } catch (IllegalArgumentException e) {
            return Material.BLACK_STAINED_GLASS_PANE;
        }
    }
    public int getItemSlot(String menuKey, String itemKey) {
        return menu.getInt("menus." + menuKey + ".items." + itemKey + ".slot", config.getInt("menus." + menuKey + ".items." + itemKey + ".slot", 0));
    }
    public String getItemPermission(String menuKey, String itemKey) {
        return menu.getString("menus." + menuKey + ".items." + itemKey + ".permission", config.getString("menus." + menuKey + ".items." + itemKey + ".permission", ""));
    }
    public String getItemAction(String menuKey, String itemKey) {
        return menu.getString("menus." + menuKey + ".items." + itemKey + ".action", config.getString("menus." + menuKey + ".items." + itemKey + ".action", itemKey));
    }
    public Set<String> getMenuItemKeys(String menuKey) {
        ConfigurationSection sec = menu.getConfigurationSection("menus." + menuKey + ".items");
        if (sec == null) sec = config.getConfigurationSection("menus." + menuKey + ".items");
        if (sec == null) return Collections.emptySet();
        return sec.getKeys(false);
    }
    public String getItemKeyBySlot(String menuKey, int slot) {
        ConfigurationSection sec = menu.getConfigurationSection("menus." + menuKey + ".items");
        if (sec == null) sec = config.getConfigurationSection("menus." + menuKey + ".items");
        if (sec == null) return null;
        for (String key : sec.getKeys(false)) {
            if (getItemSlot(menuKey, key) == slot) return key;
        }
        return null;
    }
    public String getString(String path, String def) {
        if (menu != null && menu.contains(path)) return menu.getString(path, def);
        return config.getString(path, def);
    }
    public int getInt(String path, int def) {
        if (menu != null && menu.contains(path)) return menu.getInt(path, def);
        return config.getInt(path, def);
    }
    public boolean getBoolean(String path, boolean def) {
        if (menu != null && menu.contains(path)) return menu.getBoolean(path, def);
        return config.getBoolean(path, def);
    }
    public int getIntSetting(String menuKey, String settingKey, int def) {
        return config.getInt("menus." + menuKey + "." + settingKey, def);
    }
    public ItemStack buildItem(String menuKey, String itemKey) {
        String path = "menus." + menuKey + ".items." + itemKey;
        Material material;
        try {
            material = Material.valueOf(menu.getString(path + ".material", config.getString(path + ".material", "STONE")));
        } catch (IllegalArgumentException e) {
            material = Material.STONE;
        }
        String name = menu.getString(path + ".name", config.getString(path + ".name", "&f" + itemKey));
        List<String> loreRaw = menu.contains(path + ".lore") ? menu.getStringList(path + ".lore") : config.getStringList(path + ".lore");
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
        List<String> lore = new ArrayList<>();
        for (String line : loreRaw) {
            lore.add(ChatColor.translateAlternateColorCodes('&', line));
        }
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }
    public ItemStack buildItemWithExtraLore(String menuKey, String itemKey, List<String> extraLines) {
        ItemStack item = buildItem(menuKey, itemKey);
        ItemMeta meta = item.getItemMeta();
        List<String> lore = meta.hasLore() ? new ArrayList<>(meta.getLore()) : new ArrayList<>();
        for (String line : extraLines) {
            lore.add(ChatColor.translateAlternateColorCodes('&', line));
        }
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }
    public int getMaxWarns() {
        return config.getInt("warns.max-warns", 3);
    }
    public boolean isKickOnWarn() {
        return config.getBoolean("warns.kick-on-warn", true);
    }
    public String getWarnAutoBanReason() {
        return config.getString("warns.auto-ban-reason", "Reached maximum warnings");
    }
    public String getDiscordWebhookUrl() {
        return config.getString("discord.webhook-url", "");
    }
    public long getDiscordReportCooldownMs() {
        return config.getLong("discord.report-cooldown-seconds", 30) * 1000L;
    }
    public boolean isBroadcastAutoBan() {
        return config.getBoolean("warns.broadcast-autoban", true);
    }
    public boolean isSpamEnabled() {
        return config.getBoolean("spam.enabled", true);
    }
    public int getSpamMaxRepeats() {
        return config.getInt("spam.max-repeats", 10);
    }
    public String getSpamAutoMuteDuration() {
        return config.getString("spam.auto-mute-duration", "30m");
    }
    public String getSpamAutoMuteReason() {
        return config.getString("spam.auto-mute-reason", "Automatic mute - spam");
    }
    public boolean isProfanityEnabled() {
        return config.getBoolean("profanity.enabled", true);
    }
    public boolean isProfanityAutoBan() {
        return config.getBoolean("profanity.auto-ban", true);
    }
    public String getProfanityBanDuration() {
        return config.getString("profanity.ban-duration", "permanent");
    }
    public String getProfanityBanReason() {
        return config.getString("profanity.ban-reason", "Severe language violation");
    }
    public String getChatInputCancelWord() {
        return config.getString("chat-input.cancel-word", "cancel");
    }
    public int getGrimFlagThreshold() {
        return config.getInt("grim.flag-threshold", 350);
    }
    public int getGrimKillFarmThreshold() {
        return config.getInt("grim.kill-farm-threshold", 5);
    }
    public long getGrimKillFarmTimeWindowMs() {
        return config.getLong("grim.kill-farm-time-window-seconds", 120) * 1000L;
    }
}
