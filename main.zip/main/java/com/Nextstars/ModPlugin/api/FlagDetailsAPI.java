package com.Nextstars.ModPlugin.api;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public interface FlagDetailsAPI {

    int getTotalFlags(UUID uuid);

    int getFlagsForCheck(UUID uuid, String checkName);

    long getLastFlagTime(UUID uuid);

    long getLastFlagTime(UUID uuid, String checkName);

    Map<String, Integer> getFlagsByCheck(UUID uuid);

    List<FlagEntry> getRecentFlags(UUID uuid, int limit);

    Set<UUID> getTrackedPlayers();
}
