package com.Nextstars.ModPlugin.api;

public class FlagEntry {

    private final String checkName;
    private final String verbose;
    private final long timestamp;

    public FlagEntry(String checkName, String verbose, long timestamp) {
        this.checkName = checkName;
        this.verbose = verbose;
        this.timestamp = timestamp;
    }

    public String getCheckName() { return checkName; }
    public String getVerbose()   { return verbose; }
    public long getTimestamp()   { return timestamp; }
}
