package com.Nextstars.ModPlugin.api;

import ac.grim.grimac.api.events.FlagEvent;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class FlagDetailsAPIImpl implements FlagDetailsAPI, Listener {

    private static final int RECENT_BUFFER_MAX = 200;

    private final ModPlugin plugin;

    private final Map<UUID, Integer> totalFlags        = new ConcurrentHashMap<>();
    private final Map<UUID, Map<String, Integer>> byCheck = new ConcurrentHashMap<>();
    private final Map<UUID, Long> lastFlagTime         = new ConcurrentHashMap<>();
    private final Map<UUID, Map<String, Long>> lastCheckTime = new ConcurrentHashMap<>();
    private final Map<UUID, Deque<FlagEntry>> recentFlags = new ConcurrentHashMap<>();

    public FlagDetailsAPIImpl(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
    public void onFlag(FlagEvent event) {
        UUID uuid      = event.getUser().getUniqueId();
        String check   = event.getCheck().getCheckName();
        String verbose = event.getVerbose() != null ? event.getVerbose() : "";
        long now       = System.currentTimeMillis();

        if (isClaimedFalse(verbose)) return;

        totalFlags.merge(uuid, 1, Integer::sum);

        byCheck.computeIfAbsent(uuid, u -> new ConcurrentHashMap<>())
               .merge(check, 1, Integer::sum);

        lastFlagTime.put(uuid, now);

        lastCheckTime.computeIfAbsent(uuid, u -> new ConcurrentHashMap<>())
                     .put(check, now);

        Deque<FlagEntry> buf = recentFlags.computeIfAbsent(uuid, u -> new ArrayDeque<>());
        synchronized (buf) {
            buf.addFirst(new FlagEntry(check, verbose, now));
            while (buf.size() > RECENT_BUFFER_MAX) buf.removeLast();
        }

        plugin.getFlagTimeTracker().recordFlag(check, uuid);

        if (plugin.getPlayerFlagMonitor() != null) {
            plugin.getPlayerFlagMonitor().onFlag(uuid, check);
        }

        if (plugin.getAutoBanManager() != null) {
            Player p = Bukkit.getPlayer(uuid);
            if (p != null) {
                plugin.getAutoBanManager().handleFlag(p, check, verbose, totalFlags.getOrDefault(uuid, 0));
            }
        }
    }

    private boolean isClaimedFalse(String verbose) {
        if (verbose == null) return false;
        String v = verbose.toLowerCase(java.util.Locale.ROOT);
        return v.contains("claimed false") || v.contains("claimed: false") || v.contains("- claimed false");
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        removePlayer(event.getPlayer().getUniqueId());
    }

    public void removePlayer(UUID uuid) {
        totalFlags.remove(uuid);
        byCheck.remove(uuid);
        lastFlagTime.remove(uuid);
        lastCheckTime.remove(uuid);
        recentFlags.remove(uuid);
        if (plugin.getAutoBanManager() != null) {
            plugin.getAutoBanManager().resetPlayer(uuid);
        }
        if (plugin.getPlayerFlagMonitor() != null) {
            plugin.getPlayerFlagMonitor().resetPlayer(uuid);
        }
    }

    public void clear() {
        totalFlags.clear();
        byCheck.clear();
        lastFlagTime.clear();
        lastCheckTime.clear();
        recentFlags.clear();
    }

    @Override
    public int getTotalFlags(UUID uuid) {
        return totalFlags.getOrDefault(uuid, 0);
    }

    @Override
    public int getFlagsForCheck(UUID uuid, String checkName) {
        Map<String, Integer> m = byCheck.get(uuid);
        return m != null ? m.getOrDefault(checkName, 0) : 0;
    }

    @Override
    public long getLastFlagTime(UUID uuid) {
        return lastFlagTime.getOrDefault(uuid, 0L);
    }

    @Override
    public long getLastFlagTime(UUID uuid, String checkName) {
        Map<String, Long> m = lastCheckTime.get(uuid);
        return m != null ? m.getOrDefault(checkName, 0L) : 0L;
    }

    @Override
    public Map<String, Integer> getFlagsByCheck(UUID uuid) {
        Map<String, Integer> m = byCheck.get(uuid);
        return m != null ? Collections.unmodifiableMap(m) : Collections.emptyMap();
    }

    @Override
    public List<FlagEntry> getRecentFlags(UUID uuid, int limit) {
        Deque<FlagEntry> buf = recentFlags.get(uuid);
        if (buf == null) return Collections.emptyList();
        synchronized (buf) {
            List<FlagEntry> result = new ArrayList<>();
            int count = 0;
            for (FlagEntry e : buf) {
                if (count++ >= limit) break;
                result.add(e);
            }
            return Collections.unmodifiableList(result);
        }
    }

    @Override
    public Set<UUID> getTrackedPlayers() {
        return Collections.unmodifiableSet(totalFlags.keySet());
    }

    public String getMostCommonViolation(UUID uuid) {
        Map<String, Integer> m = byCheck.get(uuid);
        if (m == null || m.isEmpty()) return "None";
        return m.entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .map(Map.Entry::getKey)
                .orElse("None");
    }
}
