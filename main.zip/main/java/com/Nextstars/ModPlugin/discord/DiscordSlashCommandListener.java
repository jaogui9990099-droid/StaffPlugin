package com.Nextstars.ModPlugin.discord;

import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.util.NickUtil;
import com.Nextstars.ModPlugin.util.InventoryImageUtil;
import com.Nextstars.ModPlugin.util.TimeParser;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.events.interaction.command.SlashCommandInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.OptionMapping;
import net.dv8tion.jda.api.utils.FileUpload;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.io.File;
import java.util.UUID;

public class DiscordSlashCommandListener extends ListenerAdapter {

    private final ModPlugin plugin;

    public DiscordSlashCommandListener(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public void onSlashCommandInteraction(SlashCommandInteractionEvent event) {
        String name = event.getName();
        if (!name.equalsIgnoreCase("banminecraft")
                && !name.equalsIgnoreCase("warnminecraft")
                && !name.equalsIgnoreCase("kickminecraft")
                && !name.equalsIgnoreCase("invseeminecraft")) {
            return;
        }

        if (event.getMember() == null || !event.getMember().hasPermission(Permission.ADMINISTRATOR)) {
            event.reply("Missing Discord permission: ADMINISTRATOR").setEphemeral(true).queue();
            return;
        }

        OptionMapping nickOpt = event.getOption("nick");
        String nick = nickOpt == null ? "" : nickOpt.getAsString().trim();
        if (nick.isEmpty()) {
            event.reply("Missing nick.").setEphemeral(true).queue();
            return;
        }
        if (!NickUtil.isValidNick(nick)) {
            event.reply("Invalid nick format.").setEphemeral(true).queue();
            return;
        }

		if (name.equalsIgnoreCase("banminecraft")) {
			String durationStr = event.getOption("duration") == null ? "-1" : event.getOption("duration").getAsString();
			String reason = event.getOption("reason") == null ? "Banned by Discord staff" : event.getOption("reason").getAsString();
			reason = reason.replace("\n", " ").replace("\r", " ").trim();
			event.deferReply(true).queue();
			String cmd = "ban " + nick + " " + durationStr + " " + reason;
			Bukkit.getScheduler().runTask(plugin, () -> {
				boolean ok = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
				event.getHook().editOriginal(ok ? ("Executed: /" + cmd) : ("Failed to execute: /" + cmd)).queue();
			});
			return;
		}

		if (name.equalsIgnoreCase("warnminecraft")) {
			String reason = event.getOption("reason") == null ? "Warned by Discord staff" : event.getOption("reason").getAsString();
			reason = reason.replace("\n", " ").replace("\r", " ").trim();
			event.deferReply(true).queue();
			String cmd = "warn " + nick + " " + reason;
			Bukkit.getScheduler().runTask(plugin, () -> {
				boolean ok = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
				event.getHook().editOriginal(ok ? ("Executed: /" + cmd) : ("Failed to execute: /" + cmd)).queue();
			});
			return;
		}

		if (name.equalsIgnoreCase("kickminecraft")) {
			String reason = event.getOption("reason") == null ? "Kicked by Discord staff" : event.getOption("reason").getAsString();
			reason = reason.replace("\n", " ").replace("\r", " ").trim();
			event.deferReply(true).queue();
			String cmd = "kick " + nick + " " + reason;
			Bukkit.getScheduler().runTask(plugin, () -> {
				boolean ok = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
				event.getHook().editOriginal(ok ? ("Executed: /" + cmd) : ("Failed to execute: /" + cmd)).queue();
			});
			return;
		}

        if (name.equalsIgnoreCase("invseeminecraft")) {
            event.deferReply(true).queue();
            Bukkit.getScheduler().runTask(plugin, () -> {
                Player target = Bukkit.getPlayerExact(nick);
                if (target == null) {
                    event.getHook().editOriginal("Player not found online: " + nick).queue();
                    return;
                }
                UUID id = target.getUniqueId();
                File out = new File(plugin.getDataFolder(), "invsee-" + id + ".png");
                try {
                    InventoryImageUtil.writeInventoryImage(target, out);
                    event.getHook().sendFiles(FileUpload.fromData(out)).queue();
                    event.getHook().editOriginal("Inventory for " + target.getName() + ":").queue();
                } catch (Exception e) {
                    event.getHook().editOriginal("Failed to render inventory: " + e.getMessage()).queue();
                }
            });
        }
    }
}
