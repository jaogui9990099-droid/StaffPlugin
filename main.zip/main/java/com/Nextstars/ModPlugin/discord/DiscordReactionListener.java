package com.Nextstars.ModPlugin.discord;

import com.Nextstars.ModPlugin.ModPlugin;
import net.dv8tion.jda.api.events.message.react.MessageReactionAddEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.jetbrains.annotations.NotNull;

import java.util.Map;

public class DiscordReactionListener extends ListenerAdapter {

    private final DiscordBotManager botManager;
    private final ModPlugin plugin;

    public DiscordReactionListener(DiscordBotManager botManager, ModPlugin plugin) {
        this.botManager = botManager;
        this.plugin = plugin;
    }

    @Override
    public void onMessageReactionAdd(@NotNull MessageReactionAddEvent event) {

        if (event.getUser() != null && event.getUser().isBot()) return;

        String emoji = event.getEmoji().asUnicode().getName();
        if (!emoji.equals("👍")) return;

        long messageId = event.getMessageIdLong();
        long channelId = event.getChannel().getIdLong();

        for (Map.Entry<String, Long> entry : botManager.getRecordingChannels().entrySet()) {
            String recordingId = entry.getKey();
            Long chanId = entry.getValue();
            Long msgId  = botManager.getRecordingMessages().get(recordingId);

            if (chanId != null && chanId == channelId
                    && msgId != null && msgId == messageId) {
                plugin.getLogger().info("[DiscordBot] Staff reacted 👍 on recording: " + recordingId);
                botManager.handleDoneReaction(recordingId);
                return;
            }
        }
    }
}
