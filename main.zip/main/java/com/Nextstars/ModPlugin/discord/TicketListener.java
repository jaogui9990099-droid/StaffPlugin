package com.Nextstars.ModPlugin.discord;

import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.util.NickUtil;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.Role;
import net.dv8tion.jda.api.entities.channel.concrete.Category;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.events.interaction.ModalInteractionEvent;
import net.dv8tion.jda.api.events.interaction.component.ButtonInteractionEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.components.ActionRow;
import net.dv8tion.jda.api.interactions.components.buttons.Button;
import net.dv8tion.jda.api.interactions.components.text.TextInput;
import net.dv8tion.jda.api.interactions.components.text.TextInputStyle;
import net.dv8tion.jda.api.interactions.modals.Modal;

public class TicketListener extends ListenerAdapter {

    private final DiscordBotManager manager;
    private final ModPlugin plugin;

    public TicketListener(DiscordBotManager manager, ModPlugin plugin) {
        this.manager = manager;
        this.plugin = plugin;
    }

    @Override
    public void onButtonInteraction(ButtonInteractionEvent event) {
        if (!event.getComponentId().equals("ticket_open")
                && !event.getComponentId().equals("ticket_close")
                && !event.getComponentId().equals("ticket_claim")) return;

        if (event.getComponentId().equals("ticket_open")) {
            TextInput banId = TextInput.create("ban_id", "Ban ID:", TextInputStyle.SHORT)
                    .setRequired(true)
                    .setMaxLength(32)
                    .build();

            TextInput reason = TextInput.create("appeal_reason", "Ban appealing reason:", TextInputStyle.PARAGRAPH)
                    .setRequired(true)
                    .setMaxLength(800)
                    .build();

            TextInput nick = TextInput.create("nick", "Nick:", TextInputStyle.SHORT)
                    .setRequired(true)
                    .setMaxLength(32)
                    .build();

            Modal modal = Modal.create("ticket_modal", "Ban Appeal")
                    .addComponents(ActionRow.of(banId), ActionRow.of(reason), ActionRow.of(nick))
                    .build();

            event.replyModal(modal).queue();
            return;
        }

        TextChannel ch = event.getChannel().asTextChannel();
        String ticketCategoryId = plugin.getConfig().getString("discord-bot.ticket.category-id", "");
        if (ticketCategoryId == null || ticketCategoryId.isBlank()) {
            event.reply(plugin.getMessageManager().getDiscord("ticket.errors.category-not-configured")).setEphemeral(true).queue();
            return;
        }
        if (ch.getParentCategoryId() == null || !ch.getParentCategoryId().equals(ticketCategoryId)) {
            event.reply(plugin.getMessageManager().getDiscord("ticket.errors.not-a-ticket-channel")).setEphemeral(true).queue();
            return;
        }

        if (event.getComponentId().equals("ticket_claim")) {
            event.deferEdit().queue();
            String tag = event.getUser().getAsMention();
            event.getMessage().editMessage(event.getMessage().getContentRaw() + "\n\nClaimed by: " + tag)
                    .setActionRow(Button.danger("ticket_close", "❌Close"), Button.secondary("ticket_claim", "🙋Claim").asDisabled())
                    .queue();
            return;
        }

        if (event.getComponentId().equals("ticket_close")) {
            event.deferReply(true).queue(hook -> {
                hook.sendMessage(plugin.getMessageManager().getDiscord("ticket.close.reply"))
                        .queue(
                                ok -> ch.delete().reason("Ticket closed").queue(),
                                err -> ch.delete().reason("Ticket closed").queue()
                        );
            }, err -> ch.delete().reason("Ticket closed").queue());
        }
    }

    @Override
    public void onModalInteraction(ModalInteractionEvent event) {
        if (!event.getModalId().equals("ticket_modal")) return;

        String banId = val(event, "ban_id");
        String appealReason = val(event, "appeal_reason");
        String nick = val(event, "nick");

        if (banId.isBlank() || nick.isBlank() || appealReason.isBlank()) {
            event.reply(plugin.getMessageManager().getDiscord("ticket.errors.missing-fields")).setEphemeral(true).queue();
            return;
        }

        if (!NickUtil.isValidNick(nick)) {
            event.reply(plugin.getMessageManager().getDiscord("ticket.errors.invalid-nick", "%nick%", nick)).setEphemeral(true).queue();
            return;
        }

        var am = plugin.getAppealManager();
        if (am == null || am.load(banId).isEmpty()) {
            event.reply(plugin.getMessageManager().getDiscord("ticket.errors.invalid-ban-id", "%ban_id%", banId)).setEphemeral(true).queue();
            return;
        }

        var rec = am.load(banId).get();
        long now = System.currentTimeMillis();
        long maxAppealAgeMs = 7L * 24L * 60L * 60L * 1000L;
        if (rec.getCreatedAtMs() > 0 && (now - rec.getCreatedAtMs()) > maxAppealAgeMs) {
            event.reply(plugin.getMessageManager().getDiscord("ticket.errors.appeal-expired", "%ban_id%", banId)).setEphemeral(true).queue();
            return;
        }

        String guildId = plugin.getConfig().getString("discord-bot.guild-id", "");
        String categoryId = plugin.getConfig().getString("discord-bot.ticket.category-id", "");
        String staffRoleId = plugin.getConfig().getString("discord-bot.ticket.staff-role-id", "");

        Guild guild = event.getJDA().getGuildById(guildId);
        if (guild == null) {
            event.reply(plugin.getMessageManager().getDiscord("ticket.errors.guild-not-found")).setEphemeral(true).queue();
            return;
        }

        Category category = guild.getCategoryById(categoryId);
        if (category == null) {
            event.reply(plugin.getMessageManager().getDiscord("ticket.errors.category-not-found")).setEphemeral(true).queue();
            return;
        }

        String channelName = "appeal-" + banId.toLowerCase().replaceAll("[^a-z0-9-]", "");
        if (channelName.length() < 6) channelName = "appeal-" + System.currentTimeMillis();
        if (channelName.length() > 90) channelName = channelName.substring(0, 90);

        var r = rec;
        String storedBanReason = r.getCheckName() + (r.getVerbose() == null || r.getVerbose().isBlank() ? "" : (" - " + r.getVerbose()));

        Role staffRole = staffRoleId == null || staffRoleId.isBlank() ? null : guild.getRoleById(staffRoleId);
        String staffMention = staffRole != null ? staffRole.getAsMention() : "@staff";

        String msg = plugin.getMessageManager().getDiscord("ticket.created.message",
                "%staff_mention%", staffMention,
                "%banreason%", storedBanReason,
                "%ban_id%", banId,
                "%nick%", nick,
                "%appeal_reason%", appealReason
        );

        var publicRole = guild.getPublicRole();
        var member = event.getMember();

        var allowStaff = java.util.EnumSet.of(Permission.VIEW_CHANNEL, Permission.MESSAGE_SEND, Permission.MESSAGE_HISTORY, Permission.MESSAGE_SEND_IN_THREADS, Permission.MESSAGE_EMBED_LINKS, Permission.MESSAGE_ATTACH_FILES);
        var denyEveryone = java.util.EnumSet.of(Permission.VIEW_CHANNEL);

        var builder = category.createTextChannel(channelName)
                .addPermissionOverride(publicRole, null, denyEveryone);

        if (staffRole != null) {
            builder = builder.addPermissionOverride(staffRole, allowStaff, null);
        }
        if (member != null) {
            builder = builder.addPermissionOverride(member, allowStaff, null);
        }

        builder.queue(created -> {
            created.sendMessage(msg)
                    .setActionRow(
                            Button.danger("ticket_close", plugin.getMessageManager().getDiscord("ticket.buttons.close")),
                            Button.secondary("ticket_claim", plugin.getMessageManager().getDiscord("ticket.buttons.claim"))
                    )
                    .queue(
                            ok -> {},
                            err -> plugin.getLogger().warning("[Ticket] Failed to send initial message: " + err.getMessage())
                    );
            event.reply(plugin.getMessageManager().getDiscord("ticket.created.reply", "%channel%", "#" + created.getName())).setEphemeral(true).queue();
        }, err -> {
            plugin.getLogger().warning("[Ticket] Failed to create ticket channel: " + err.getMessage());
            event.reply(plugin.getMessageManager().getDiscord("ticket.errors.failed-to-create", "%error%", err.getMessage())).setEphemeral(true).queue();
        });
    }

    private String val(ModalInteractionEvent e, String id) {
        var v = e.getValue(id);
        return v == null ? "" : v.getAsString().trim();
    }
}
