package com.Nextstars.ModPlugin.discord;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;

import java.io.File;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class RecordingManager {

    private final ModPlugin plugin;
    private final Set<UUID> activeRecordings = ConcurrentHashMap.newKeySet();

    public RecordingManager(ModPlugin plugin) {
        this.plugin = plugin;
    }

    public void startRecordingForPlayer(UUID playerUuid, String playerName, int totalFlags) {
        int durationSeconds = plugin.getConfig().getInt("discord-bot.recording-duration-seconds", 900);
        startRecordingForPlayer(playerUuid, playerName, totalFlags, durationSeconds);
    }

    public void startRecordingForPlayer(UUID playerUuid, String playerName, int totalFlags, int durationSeconds) {
        if (activeRecordings.contains(playerUuid)) return;
        if (!com.Nextstars.ModPlugin.util.ReplayBridge.isAvailable()) return;

        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss"));
        String recordingId = playerName.toLowerCase() + "-" + timestamp;

        try {
            activeRecordings.add(playerUuid);
            org.bukkit.entity.Player p = Bukkit.getPlayer(playerUuid);
            if (p != null) {
                com.Nextstars.ModPlugin.util.ReplayBridge.record(recordingId, Bukkit.getConsoleSender(), p);
            }
            plugin.getLogger().info("[RecordingManager] Started recording '" + recordingId + "' for " + playerName);

            int safeDuration = Math.max(1, durationSeconds);
            long tickDelay = (long) (safeDuration + 5) * 20L;

            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                com.Nextstars.ModPlugin.util.ReplayBridge.stop(recordingId, true);
                plugin.getLogger().info("[RecordingManager] Stopped recording '" + recordingId + "'");
                activeRecordings.remove(playerUuid);

                Bukkit.getScheduler().runTaskLaterAsynchronously(
                        plugin,
                        () -> onRecordingFinished(playerUuid, playerName, totalFlags, recordingId),
                        40L
                );
            }, tickDelay);
        } catch (Exception e) {
            activeRecordings.remove(playerUuid);
            plugin.getLogger().severe("[RecordingManager] Failed to start recording: " + e.getMessage());
        }
    }

    private void onRecordingFinished(UUID playerUuid, String playerName, int totalFlags, String recordingId) {
        DiscordBotManager bot = plugin.getDiscordBotManager();
        if (bot == null || !bot.isReady()) return;

        String configured = plugin.getConfig().getString("discord-bot.replays-folder", "plugins/Flashback/replays");
        File replayFile = findReplayFile(configured, recordingId);
        if (replayFile == null) replayFile = findReplayFile("plugins/Flashback/replays", recordingId);
        if (replayFile == null) replayFile = findReplayFile("plugins/AdvancedReplay/replays", recordingId);

        int currentTotal = plugin.getFlagTracker() != null
                ? plugin.getFlagTracker().getTotalFlags(playerUuid)
                : totalFlags;

        bot.sendRecordingAlert(playerUuid, playerName, currentTotal, recordingId, replayFile);
    }

    private File findReplayFile(String folderPath, String recordingId) {
        File folder = new File(folderPath);
        if (!folder.exists() || !folder.isDirectory()) return null;

        String needle = recordingId == null ? "" : recordingId.toLowerCase();
        if (needle.isEmpty()) return null;

        File exact = new File(folder, recordingId + ".replay");
        if (exact.exists()) return exact;

        return findReplayFileRecursive(folder, needle, 0, 3);
    }

    private File findReplayFileRecursive(File dir, String needle, int depth, int maxDepth) {
        if (dir == null || !dir.isDirectory() || depth > maxDepth) return null;
        File[] files = dir.listFiles();
        if (files == null) return null;

        for (File f : files) {
            if (f == null) continue;
            if (f.isDirectory()) {
                File found = findReplayFileRecursive(f, needle, depth + 1, maxDepth);
                if (found != null) return found;
                continue;
            }

            String name = f.getName() == null ? "" : f.getName().toLowerCase();
            if (name.startsWith(needle) && name.endsWith(".replay")) {
                return f;
            }
        }

        return null;
    }

    public boolean isRecording(UUID playerUuid) {
        return activeRecordings.contains(playerUuid);
    }
}
