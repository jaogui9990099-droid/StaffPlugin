package com.Nextstars.ModPlugin.discord;

import com.Nextstars.ModPlugin.ModPlugin;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.entities.*;
import net.dv8tion.jda.api.entities.channel.concrete.Category;
import net.dv8tion.jda.api.entities.channel.concrete.TextChannel;
import net.dv8tion.jda.api.events.session.ReadyEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.interactions.commands.DefaultMemberPermissions;
import net.dv8tion.jda.api.requests.GatewayIntent;
import net.dv8tion.jda.api.utils.FileUpload;
import org.bukkit.Bukkit;

import java.io.File;
import com.Nextstars.ModPlugin.appeal.AppealRecord;
import java.util.EnumSet;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class DiscordBotManager {

    private final ModPlugin plugin;
    private JDA jda;

    private final Map<String, Long> recordingChannels = new ConcurrentHashMap<>();

    private final Map<String, Long> recordingMessages = new ConcurrentHashMap<>();

    private final Map<String, String> recordingFiles = new ConcurrentHashMap<>();

    public DiscordBotManager(ModPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        String token = plugin.getConfig().getString("discord-bot.token", "");
        if (token.isEmpty() || token.equals("YOUR_BOT_TOKEN_HERE")) {
            plugin.getLogger().warning("[DiscordBot] Bot token not configured — bot disabled.");
            return;
        }
        try {
            jda = JDABuilder.createDefault(token,
                            EnumSet.of(
                                    GatewayIntent.GUILD_MESSAGES,
                                    GatewayIntent.GUILD_MESSAGE_REACTIONS,
                                    GatewayIntent.MESSAGE_CONTENT,
                                    GatewayIntent.GUILD_MEMBERS
                            ))
                    .addEventListeners(new DiscordReactionListener(this, plugin))
                    .addEventListeners(new TicketListener(this, plugin))
                    .addEventListeners(new DiscordSlashCommandListener(plugin))
                    .addEventListeners(new ListenerAdapter() {
                        @Override
                        public void onReady(ReadyEvent event) {
                            try {
                                String guildId = plugin.getConfig().getString("discord-bot.guild-id", "");
                                if (guildId != null && !guildId.isBlank()) {
                                    var guild = event.getJDA().getGuildById(guildId);
                                    if (guild != null) {
														guild.updateCommands()
															.addCommands(
																	net.dv8tion.jda.api.interactions.commands.build.Commands.slash("banminecraft", "Run /ban <nick> <duration> <reason> on the server")
																			.addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "nick", "Player nick", true)
																			.addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "duration", "Duration like -1, 14d, 7d, 1h", true)
																			.addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "reason", "Reason", true)
																			.setDefaultPermissions(DefaultMemberPermissions.enabledFor(net.dv8tion.jda.api.Permission.ADMINISTRATOR)),
																	net.dv8tion.jda.api.interactions.commands.build.Commands.slash("warnminecraft", "Run /warn <nick> <reason> on the server")
																			.addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "nick", "Player nick", true)
																			.addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "reason", "Reason", true)
																			.setDefaultPermissions(DefaultMemberPermissions.enabledFor(net.dv8tion.jda.api.Permission.ADMINISTRATOR)),
																	net.dv8tion.jda.api.interactions.commands.build.Commands.slash("kickminecraft", "Run /kick <nick> <reason> on the server")
																			.addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "nick", "Player nick", true)
																			.addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "reason", "Reason", true)
																			.setDefaultPermissions(DefaultMemberPermissions.enabledFor(net.dv8tion.jda.api.Permission.ADMINISTRATOR)),
                                                        net.dv8tion.jda.api.interactions.commands.build.Commands.slash("invseeminecraft", "See a player's inventory as an image")
                                                                .addOption(net.dv8tion.jda.api.interactions.commands.OptionType.STRING, "nick", "Player nick", true)
                                                                .setDefaultPermissions(DefaultMemberPermissions.enabledFor(net.dv8tion.jda.api.Permission.ADMINISTRATOR))
                                                ).queue();
                                    }
                                }
                            } catch (Exception e) {
                                plugin.getLogger().warning("[DiscordBot] Failed to register slash commands: " + e.getMessage());
                            }
                            refreshTicketPanelMessageIfSent();
                            sendTicketPanelIfNeeded();
                        }
                    })
                    .build();
            jda.awaitReady();
            plugin.getLogger().info("[DiscordBot] Bot connected: " + jda.getSelfUser().getAsTag());
        } catch (Exception e) {
            plugin.getLogger().severe("[DiscordBot] Failed to start: " + e.getMessage());
        }
    }

    public void shutdown() {
        if (jda != null) {
            try {
                jda.shutdownNow();
                try {
                    jda.awaitShutdown(java.time.Duration.ofSeconds(10));
                } catch (Throwable ignored) {
                }
            } finally {
                jda = null;
            }
        }
    }

    public boolean isReady() {
        return jda != null && jda.getStatus() == JDA.Status.CONNECTED;
    }

    public void sendAlert(String playerName, int totalFlags, Map<String, Integer> byCheck, double cheatChance) {
        if (!isReady()) return;
        String channelId = plugin.getConfig().getString("discord-bot.alerts-channel-id", "");
        if (channelId.isEmpty()) return;

        TextChannel channel = jda.getTextChannelById(channelId);
        if (channel == null) return;

        StringBuilder flagsDisplay = new StringBuilder();
        byCheck.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(6)
                .forEach(e -> {
                    if (flagsDisplay.length() > 0) flagsDisplay.append(", ");
                    flagsDisplay.append(capitalize(e.getKey()));
                });

        String dateStr = java.time.Instant.now()
                .atZone(java.time.ZoneId.systemDefault())
                .format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));

        String msg = plugin.getMessageManager().getDiscord("alerts.message",
                "%player%", playerName,
                "%flags_detected%", flagsDisplay.toString(),
                "%total_flags%", String.valueOf(totalFlags),
                "%cheat_probability%", String.format("%.0f%%", cheatChance),
                "%datetime%", dateStr
        );
        channel.sendMessage(msg).queue();
    }

    public void sendRecordingAlert(UUID playerUuid, String playerName, int totalFlags, String recordingId, File replayFile) {
        if (!isReady()) return;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                Guild guild = jda.getGuildById(plugin.getConfig().getString("discord-bot.guild-id", "1454247939047293234"));
                if (guild == null) {
                    plugin.getLogger().warning("[DiscordBot] Guild not found!");
                    return;
                }

                String categoryId = plugin.getConfig().getString("discord-bot.recordings-category-id", "");
                Category category = categoryId.isEmpty() ? null : guild.getCategoryById(categoryId);

                String channelName = "rec-" + playerName.toLowerCase().replace("_", "-");

                var channelAction = category != null
                        ? category.createTextChannel(channelName)
                        : guild.createTextChannel(channelName);

                channelAction = channelAction.addPermissionOverride(
                        guild.getPublicRole(),
                        0L,
                        net.dv8tion.jda.api.Permission.VIEW_CHANNEL.getRawValue()
                );

                List<String> pickerRoles = plugin.getConfig().getStringList("discord-bot.recording-access.picker-roles");
                if (pickerRoles.isEmpty()) {
                    pickerRoles = plugin.getConfig().getStringList("discord-bot.staff-roles"); 
                }

                List<String> allowedRoleIdsOrNames = plugin.getConfig().getStringList("discord-bot.recording-access.allowed-roles");
                List<String> allowedUserIds = plugin.getConfig().getStringList("discord-bot.recording-access.allowed-users");

                Member chosenReviewer = pickOneReviewer(guild, pickerRoles);

                if (chosenReviewer != null) {
                    channelAction = channelAction.addPermissionOverride(
                            chosenReviewer,
                            net.dv8tion.jda.api.Permission.VIEW_CHANNEL.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_SEND.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_HISTORY.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_ATTACH_FILES.getRawValue(),
                            0L
                    );
                }

                for (String roleToken : allowedRoleIdsOrNames) {
                    Role role = resolveRole(guild, roleToken);
                    if (role == null) continue;
                    channelAction = channelAction.addPermissionOverride(
                            role,
                            net.dv8tion.jda.api.Permission.VIEW_CHANNEL.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_SEND.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_HISTORY.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_ATTACH_FILES.getRawValue(),
                            0L
                    );
                }

                for (String userId : allowedUserIds) {
                    if (userId == null || userId.isBlank()) continue;
                    Member member = guild.getMemberById(userId.trim());
                    if (member == null) continue;
                    channelAction = channelAction.addPermissionOverride(
                            member,
                            net.dv8tion.jda.api.Permission.VIEW_CHANNEL.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_SEND.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_HISTORY.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_ATTACH_FILES.getRawValue(),
                            0L
                    );
                }

                TextChannel channel = channelAction.complete();

                String headUrl = "https://minotar.net/helm/" + playerName + "/64.png";
                String msg = "🎬 Recording Alert\n\n"
                        + "Player: " + playerName + " got more than " + totalFlags + " flags.\n\n"
                        + "Use the command: /flashback play " + recordingId + "\n\n"
                        + "Player head: " + headUrl + "\n\n"
                        + "React with 👍 when you are done checking — this channel and the recording will be automatically deleted."; 

                var messageAction = channel.sendMessage(msg);
                if (replayFile != null && replayFile.exists()) {
                    messageAction = messageAction.addFiles(FileUpload.fromData(replayFile, replayFile.getName()));
                }

                Message sentMessage = messageAction.complete();
                sentMessage.addReaction(net.dv8tion.jda.api.entities.emoji.Emoji.fromUnicode("👍")).queue();

                recordingChannels.put(recordingId, channel.getIdLong());
                recordingMessages.put(recordingId, sentMessage.getIdLong());
                if (replayFile != null) recordingFiles.put(recordingId, replayFile.getAbsolutePath());

                plugin.getLogger().info("[DiscordBot] Recording channel created: #" + channelName + " for " + playerName);

            } catch (Exception e) {
                plugin.getLogger().severe("[DiscordBot] Failed to send recording alert: " + e.getMessage());
            }
        });
    }

    public void handleDoneReaction(String recordingId) {
        Long channelId = recordingChannels.remove(recordingId);
        recordingMessages.remove(recordingId);
        recordingFiles.remove(recordingId);

        if (channelId == null) return;

        TextChannel channel = jda.getTextChannelById(channelId);
        if (channel == null) return;

        channel.delete().reason("Staff finished review").queue(
                success -> plugin.getLogger().info("[DiscordBot] Deleted recording channel for " + recordingId),
                err -> plugin.getLogger().warning("[DiscordBot] Could not delete channel: " + err.getMessage())
        );
    }

    public void sendAutoBanAlert(AppealRecord record, File replayFile) {
        if (!isReady() || record == null) return;

        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                Guild guild = jda.getGuildById(plugin.getConfig().getString("discord-bot.guild-id", ""));
                if (guild == null) return;

                String categoryId = plugin.getConfig().getString("discord-bot.recordings-category-id", "");
                Category category = categoryId.isEmpty() ? null : guild.getCategoryById(categoryId);

                String channelName = ("ban-" + record.getPlayerName() + "-" + record.getId()).toLowerCase().replace("_", "-");
                if (channelName.length() > 90) channelName = channelName.substring(0, 90);

                var channelAction = category != null
                        ? category.createTextChannel(channelName)
                        : guild.createTextChannel(channelName);

                channelAction = channelAction.addPermissionOverride(
                        guild.getPublicRole(),
                        0L,
                        net.dv8tion.jda.api.Permission.VIEW_CHANNEL.getRawValue()
                );

                List<String> allowedRoleIdsOrNames = plugin.getConfig().getStringList("discord-bot.recording-access.allowed-roles");
                List<String> allowedUserIds = plugin.getConfig().getStringList("discord-bot.recording-access.allowed-users");

                List<String> pickerRoles = plugin.getConfig().getStringList("discord-bot.recording-access.picker-roles");
                if (pickerRoles.isEmpty()) {
                    pickerRoles = plugin.getConfig().getStringList("discord-bot.staff-roles");
                }

                Member chosenReviewer = pickOneReviewer(guild, pickerRoles);
                if (chosenReviewer != null) {
                    channelAction = channelAction.addPermissionOverride(
                            chosenReviewer,
                            net.dv8tion.jda.api.Permission.VIEW_CHANNEL.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_SEND.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_HISTORY.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_ATTACH_FILES.getRawValue(),
                            0L
                    );
                }

                for (String roleToken : allowedRoleIdsOrNames) {
                    Role role = resolveRole(guild, roleToken);
                    if (role == null) continue;
                    channelAction = channelAction.addPermissionOverride(
                            role,
                            net.dv8tion.jda.api.Permission.VIEW_CHANNEL.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_SEND.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_HISTORY.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_ATTACH_FILES.getRawValue(),
                            0L
                    );
                }

                for (String userId : allowedUserIds) {
                    if (userId == null || userId.isBlank()) continue;
                    Member member = guild.getMemberById(userId.trim());
                    if (member == null) continue;
                    channelAction = channelAction.addPermissionOverride(
                            member,
                            net.dv8tion.jda.api.Permission.VIEW_CHANNEL.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_SEND.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_HISTORY.getRawValue()
                                    | net.dv8tion.jda.api.Permission.MESSAGE_ATTACH_FILES.getRawValue(),
                            0L
                    );
                }

                TextChannel channel = channelAction.complete();

                String dateStr = java.time.Instant.ofEpochMilli(record.getCreatedAtMs())
                        .atZone(java.time.ZoneId.systemDefault())
                        .format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));

                String msg = "⛔ Auto-ban\n\n"
                        + "Player: " + record.getPlayerName() + "\n"
                        + "Appeal ID: " + record.getId() + "\n"
                        + "Flags: " + record.getTotalFlags() + "\n"
                        + "Check: " + record.getCheckName() + "\n"
                        + (record.getVerbose() == null || record.getVerbose().isBlank() ? "" : ("Verbose: " + record.getVerbose() + "\n"))
                        + "World: " + record.getWorld() + "\n"
                        + "Location: " + String.format("%.2f %.2f %.2f", record.getX(), record.getY(), record.getZ()) + "\n"
                        + (record.getLastCommand() == null || record.getLastCommand().isBlank() ? "" : ("Last command: " + record.getLastCommand() + "\n"))
                        + "Time: " + dateStr + "\n\n"
                        + "Replay: /flashback play " + (record.getRecordingId() == null ? "" : record.getRecordingId());

                var messageAction = channel.sendMessage(msg);
                if (replayFile != null && replayFile.exists()) {
                    messageAction = messageAction.addFiles(FileUpload.fromData(replayFile, replayFile.getName()));
                }
                Message sentMessage = messageAction.complete();
                sentMessage.addReaction(net.dv8tion.jda.api.entities.emoji.Emoji.fromUnicode("👍")).queue();

                String key = "appeal-" + record.getId();
                recordingChannels.put(key, channel.getIdLong());
                recordingMessages.put(key, sentMessage.getIdLong());
                if (replayFile != null) recordingFiles.put(key, replayFile.getAbsolutePath());
            } catch (Exception e) {
                plugin.getLogger().warning("[DiscordBot] Auto-ban alert failed: " + e.getMessage());
            }
        });
    }

    public void sendGraph(String text) {
        if (!isReady()) return;
        String channelId = plugin.getConfig().getString("discord-bot.graphs-channel-id", "");
        if (channelId.isEmpty()) return;
        TextChannel channel = jda.getTextChannelById(channelId);
        if (channel == null) return;
        channel.sendMessage(text).queue();
    }

    public void sendAutoBanEvidence(AppealRecord record, File replayFile) {
        if (!isReady() || record == null) return;
        String channelId = plugin.getConfig().getString("discord-bot.autoban-evidence-channel-id", "");
        if (channelId.isEmpty()) return;
        TextChannel channel = jda.getTextChannelById(channelId);
        if (channel == null) return;

        String banTime = java.time.Instant.ofEpochMilli(record.getCreatedAtMs())
                .atZone(java.time.ZoneId.systemDefault())
                .format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));
        String banReason = buildDisplayReason(record.getCheckName(), record.getVerbose(), record.getTotalFlags());
        String banLocation = record.getWorld() + " " + String.format("%.2f %.2f %.2f", record.getX(), record.getY(), record.getZ());

        String msg = plugin.getMessageManager().getDiscord("autoban.evidence.message",
                "%player%", record.getPlayerName(),
                "%ban_id%", record.getId(),
                "%reason%", banReason,
                "%flags%", String.valueOf(record.getTotalFlags()),
                "%ban_time%", banTime,
                "%ban_location%", banLocation
        );

        var action = channel.sendMessage(msg);
        if (replayFile != null && replayFile.exists()) {
            action = action.addFiles(FileUpload.fromData(replayFile, replayFile.getName()));
        }
        action.queue();
    }

    public void sendAntiCheatBanMessage(String playerName, String reason, String duration, String appealId) {
        if (!isReady()) return;
        String channelId = plugin.getConfig().getString("discord-bot.autoban-log-channel-id", "");
        if (channelId.isEmpty()) return;
        TextChannel channel = jda.getTextChannelById(channelId);
        if (channel == null) return;
        channel.sendMessage(plugin.getMessageManager().getDiscord("autoban.log.message",
                "%player%", playerName,
                "%reason%", reason,
                "%duration%", duration,
                "%appeal_id%", appealId == null ? "" : appealId
        )).queue();
    }

    public void sendTicketPanelIfNeeded() {
        if (!isReady()) return;
        int sent = plugin.getConfig().getInt("discord-bot.ticket.has-sent-ticket-message", 0);
        if (sent == 1) return;
        String channelId = plugin.getConfig().getString("discord-bot.ticket.panel-channel-id", "");
        if (channelId.isEmpty()) return;
        TextChannel channel = jda.getTextChannelById(channelId);
        if (channel == null) return;

        channel.sendMessage(plugin.getMessageManager().getDiscord("ticket.panel.message"))
                .setActionRow(net.dv8tion.jda.api.interactions.components.buttons.Button.primary(
                        "ticket_open",
                        plugin.getMessageManager().getDiscord("ticket.panel.button")
                ))
                .queue(s -> {
                    plugin.getConfig().set("discord-bot.ticket.has-sent-ticket-message", 1);
                    plugin.getConfig().set("discord-bot.ticket.panel-message-id", s.getIdLong());
                    plugin.saveConfig();
                });
    }

    private String buildDisplayReason(String checkName, String verbose, int totalFlags) {
        String c = checkName == null ? "" : checkName;
        String v = verbose == null ? "" : verbose;
        String base = plugin.getConfig().getString("auto-ban.reason-prefix", "Cheating");
        String extra = c.isBlank() ? "" : (" (" + c + ")");
        String vv = v.isBlank() ? "" : (" - " + v);
        return base + extra + vv + " | Flags: " + totalFlags;
    }

    public void refreshTicketPanelMessageIfSent() {
        if (!isReady()) return;
        int sent = plugin.getConfig().getInt("discord-bot.ticket.has-sent-ticket-message", 0);
        if (sent != 1) return;

        String channelId = plugin.getConfig().getString("discord-bot.ticket.panel-channel-id", "");
        if (channelId == null || channelId.isBlank()) return;

        long msgId = plugin.getConfig().getLong("discord-bot.ticket.panel-message-id", 0L);
        if (msgId <= 0L) return;

        TextChannel channel = jda.getTextChannelById(channelId);
        if (channel == null) return;

        channel.editMessageById(msgId, plugin.getMessageManager().getDiscord("ticket.panel.message"))
                .setActionRow(net.dv8tion.jda.api.interactions.components.buttons.Button.primary(
                        "ticket_open",
                        plugin.getMessageManager().getDiscord("ticket.panel.button")
                ))
                .queue(null, err -> {
                    plugin.getLogger().warning("[DiscordBot] Ticket panel message missing, will resend on next start.");
                    plugin.getConfig().set("discord-bot.ticket.has-sent-ticket-message", 0);
                    plugin.getConfig().set("discord-bot.ticket.panel-message-id", 0L);
                    plugin.saveConfig();
                });
    }

    public Map<String, Long> getRecordingChannels()  { return recordingChannels; }
    public Map<String, Long> getRecordingMessages()  { return recordingMessages; }

    private Member pickOneReviewer(Guild guild, List<String> roleTokens) {
        if (guild == null || roleTokens == null || roleTokens.isEmpty()) return null;

        java.util.LinkedHashSet<Member> candidates = new java.util.LinkedHashSet<>();
        for (String token : roleTokens) {
            Role role = resolveRole(guild, token);
            if (role == null) continue;
            for (Member m : guild.getMembersWithRoles(role)) {
                if (m == null) continue;
                if (m.getUser() != null && m.getUser().isBot()) continue;
                candidates.add(m);
            }
        }

        if (candidates.isEmpty()) return null;

        int size = candidates.size();
        int index = (int) (System.currentTimeMillis() % size);
        int i = 0;
        for (Member m : candidates) {
            if (i++ == index) return m;
        }
        return candidates.iterator().next();
    }

    private Role resolveRole(Guild guild, String token) {
        if (guild == null || token == null) return null;
        String t = token.trim();
        if (t.isEmpty()) return null;

        if (t.matches("^\\d{15,25}$")) {
            return guild.getRoleById(t);
        }

        for (Role role : guild.getRoles()) {
            if (role.getName().equalsIgnoreCase(t)) return role;
        }
        return null;
    }

private String capitalize(String s) {
        if (s == null || s.isEmpty()) return s;
        String[] parts = s.split("[_\\s]");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (sb.length() > 0) sb.append(" ");
            sb.append(Character.toUpperCase(p.charAt(0)));
            if (p.length() > 1) sb.append(p.substring(1).toLowerCase());
        }
        return sb.toString();
    }

    private String esc(String s) {
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n");
    }
}
