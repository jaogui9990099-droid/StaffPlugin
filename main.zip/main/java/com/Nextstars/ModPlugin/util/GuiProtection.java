package com.Nextstars.ModPlugin.util;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
public final class GuiProtection {
    private GuiProtection() {}
    public static void cancelAll(InventoryClickEvent event) {
        event.setCancelled(true);
        ClickType type     = event.getClick();
        InventoryAction act = event.getAction();
        if (type == ClickType.SHIFT_LEFT || type == ClickType.SHIFT_RIGHT) return;
        if (type == ClickType.NUMBER_KEY) return;
        if (type == ClickType.SWAP_OFFHAND) return;
        if (type == ClickType.DOUBLE_CLICK) return;
        if (type == ClickType.DROP || type == ClickType.CONTROL_DROP) return;
        if (act == InventoryAction.MOVE_TO_OTHER_INVENTORY) return;
        if (act == InventoryAction.COLLECT_TO_CURSOR) return;
        if (act == InventoryAction.HOTBAR_SWAP) return;
        if (act == InventoryAction.HOTBAR_MOVE_AND_READD) return;
    }
    public static boolean isPlayerInventoryClick(InventoryClickEvent event) {
        return event.getClickedInventory() != null
                && event.getClickedInventory().getType() == InventoryType.PLAYER;
    }
}
