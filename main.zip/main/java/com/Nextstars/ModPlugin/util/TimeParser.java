package com.Nextstars.ModPlugin.util;
public class TimeParser {
    public static long parse(String input) {
        if (input == null) return -1;
        String lower = input.toLowerCase().trim();
        if (lower.equals("permanent") || lower.equals("perm") || lower.equals("-1")) return -1;
        long total = 0;
        StringBuilder num = new StringBuilder();
        for (char c : lower.toCharArray()) {
            if (Character.isDigit(c)) {
                num.append(c);
            } else {
                if (num.length() == 0) continue;
                long value = Long.parseLong(num.toString());
                num.setLength(0);
                total += switch (c) {
                    case 's' -> value * 1000L;
                    case 'm' -> value * 60_000L;
                    case 'h' -> value * 3_600_000L;
                    case 'd' -> value * 86_400_000L;
                    case 'w' -> value * 604_800_000L;
                    default -> 0L;
                };
            }
        }
        return total == 0 ? -1 : total;
    }
    public static String format(long remainingMs) {
        if (remainingMs < 0) return "Permanent";
        if (remainingMs == 0) return "Expired";
        long seconds = remainingMs / 1000;
        long minutes = seconds / 60;
        long hours = minutes / 60;
        long days = hours / 24;
        if (days > 0) return days + "d " + (hours % 24) + "h";
        if (hours > 0) return hours + "h " + (minutes % 60) + "m";
        if (minutes > 0) return minutes + "m " + (seconds % 60) + "s";
        return seconds + "s";
    }
    public static String formatDuration(long durationMs) {
        if (durationMs < 0) return "Permanent";
        return format(durationMs);
    }
}
