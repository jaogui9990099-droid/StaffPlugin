package com.Nextstars.ModPlugin.util;
import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
public final class StaffInventoryHolder implements InventoryHolder {
    private final String id;
    public StaffInventoryHolder(String id) {
        this.id = id;
    }
    public String getId() {
        return id;
    }
    @Override
    public Inventory getInventory() {
        return Bukkit.createInventory(this, 9);
    }
}
