package com.Nextstars.ModPlugin.util;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

import java.util.Locale;
import java.util.regex.Pattern;

public final class NickUtil {

    private static final Pattern VALID = Pattern.compile("^[A-Za-z0-9_]{3,16}$");

    private NickUtil() {}

    public static boolean isValidNick(String nick) {
        if (nick == null) return false;
        nick = nick.trim();
        if (!VALID.matcher(nick).matches()) return false;

        Player online = Bukkit.getPlayerExact(nick);
        if (online != null) return true;

        try {
            OfflinePlayer off = Bukkit.getOfflinePlayer(nick);
            return off != null && off.hasPlayedBefore();
        } catch (Throwable ignored) {
            return true;
        }
    }
}
