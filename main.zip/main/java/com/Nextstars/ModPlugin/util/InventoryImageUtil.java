package com.Nextstars.ModPlugin.util;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;

public final class InventoryImageUtil {

    private InventoryImageUtil() {}

    public static void writeInventoryImage(Player target, File outFile) throws Exception {
        int cols = 9;
        int rows = 4;
        int cell = 90;
        int pad = 20;
        int header = 70;
        int width = pad * 2 + cols * cell;
        int height = pad * 2 + header + rows * cell;

        BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        g.setColor(new Color(18, 18, 22));
        g.fillRect(0, 0, width, height);

        g.setColor(new Color(34, 34, 42));
        g.fillRoundRect(pad, pad, width - pad * 2, height - pad * 2, 18, 18);

        g.setColor(new Color(245, 245, 255));
        g.setFont(new Font("SansSerif", Font.BOLD, 24));
        g.drawString("InvSee - " + target.getName(), pad + 18, pad + 40);

        g.setFont(new Font("SansSerif", Font.PLAIN, 14));
        g.setColor(new Color(190, 190, 205));
        g.drawString("Main Inventory", pad + 18, pad + 62);

        int startY = pad + header;
        ItemStack[] contents = target.getInventory().getContents();
        for (int slot = 0; slot < 36; slot++) {
            int r = slot / cols;
            int c = slot % cols;
            int x = pad + c * cell;
            int y = startY + r * cell;

            g.setColor(new Color(52, 52, 62));
            g.fillRoundRect(x + 6, y + 6, cell - 12, cell - 12, 14, 14);

            g.setColor(new Color(62, 62, 74));
            g.drawRoundRect(x + 6, y + 6, cell - 12, cell - 12, 14, 14);

            ItemStack it = slot < contents.length ? contents[slot] : null;
            if (it == null || it.getType() == Material.AIR) continue;
            String name = formatMaterialName(it.getType());
            int amount = it.getAmount();

            Icon ic = iconFor(it.getType());
            g.setColor(ic.color);
            g.fillRoundRect(x + 12, y + 14, 22, 22, 10, 10);
            g.setColor(new Color(18, 18, 22));
            g.setFont(new Font("SansSerif", Font.BOLD, 14));
            g.drawString(ic.letter, x + 19, y + 30);

            g.setColor(new Color(235, 235, 245));
            g.setFont(new Font("SansSerif", Font.PLAIN, 13));

            String line1 = name.length() > 18 ? name.substring(0, 18) : name;
            String line2 = name.length() > 18 ? name.substring(18, Math.min(name.length(), 36)) : "";
            g.drawString(line1, x + 12, y + 50);
            if (!line2.isEmpty()) g.drawString(line2, x + 12, y + 64);

            g.setFont(new Font("SansSerif", Font.BOLD, 16));
            g.setColor(new Color(120, 220, 170));
            g.drawString("x" + amount, x + 12, y + 82);
        }
        g.dispose();
        ImageIO.write(img, "png", outFile);
    }

    private static String formatMaterialName(Material mat) {
        String raw = mat.name().toLowerCase(java.util.Locale.ROOT).replace('_', ' ');
        String[] parts = raw.split(" ");
        StringBuilder sb = new StringBuilder();
        for (String p : parts) {
            if (p.isEmpty()) continue;
            sb.append(Character.toUpperCase(p.charAt(0))).append(p.substring(1)).append(' ');
        }
        return sb.toString().trim();
    }

    private static Icon iconFor(Material m) {
        String n = m.name();
        if (n.endsWith("_SWORD") || n.endsWith("_AXE")) return new Icon("W", new Color(255, 118, 118));
        if (n.endsWith("_PICKAXE") || n.endsWith("_SHOVEL") || n.endsWith("_HOE")) return new Icon("T", new Color(255, 214, 102));
        if (n.endsWith("_HELMET") || n.endsWith("_CHESTPLATE") || n.endsWith("_LEGGINGS") || n.endsWith("_BOOTS")) return new Icon("A", new Color(120, 180, 255));
        if (n.contains("POTION") || n.contains("SPLASH") || n.contains("LINGERING")) return new Icon("P", new Color(170, 140, 255));
        if (n.contains("BOW") || n.contains("CROSSBOW") || n.contains("ARROW")) return new Icon("R", new Color(255, 170, 90));
        if (n.contains("BOOK") || n.contains("ENCHANT")) return new Icon("B", new Color(120, 220, 170));
        if (n.contains("SHULKER") || n.contains("CHEST") || n.contains("BARREL")) return new Icon("C", new Color(190, 190, 205));
        if (n.contains("DIAMOND") || n.contains("EMERALD") || n.contains("GOLD") || n.contains("NETHERITE")) return new Icon("G", new Color(120, 220, 170));
        if (n.contains("BREAD") || n.contains("APPLE") || n.contains("MEAT") || n.contains("COOKED") || n.contains("CARROT") || n.contains("POTATO")) return new Icon("F", new Color(255, 170, 170));
        if (m.isBlock()) return new Icon("K", new Color(160, 160, 175));
        return new Icon("I", new Color(235, 235, 245));
    }

    private record Icon(String letter, Color color) {}
}
