package com.Nextstars.ModPlugin.util;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;

public final class ReplayBridge {

    private static final String[] API_CLASS_NAMES = new String[] {
            "com.Nextstars.Flashback.replay.api.ReplayAPI",
            "me.jumper251.replay.api.ReplayAPI"
    };

    private static volatile boolean checked;
    private static volatile boolean available;
    private static volatile Class<?> apiClass;
    private static volatile Object apiInstance;

    private ReplayBridge() {
    }

    public static boolean isAvailable() {
        ensureLoaded();
        return available;
    }

    public static void record(String id, CommandSender sender, Player player) {
        ensureLoaded();
        if (!available) return;
        try {
            Method m = apiClass.getMethod("recordReplay", String.class, CommandSender.class, Player[].class);
            m.invoke(apiInstance, id, sender, new Player[] { player });
        } catch (Throwable ignored) {
        }
    }

    public static void stop(String id, boolean save) {
        ensureLoaded();
        if (!available) return;
        try {
            Method m = apiClass.getMethod("stopReplay", String.class, boolean.class);
            m.invoke(apiInstance, id, save);
        } catch (Throwable ignored) {
        }
    }

    private static void ensureLoaded() {
        if (checked) return;
        synchronized (ReplayBridge.class) {
            if (checked) return;
            checked = true;
            for (String name : API_CLASS_NAMES) {
                try {
                    Class<?> clazz = Class.forName(name);
                    Method getInstance = clazz.getMethod("getInstance");
                    Object instance = getInstance.invoke(null);
                    if (instance != null) {
                        apiClass = clazz;
                        apiInstance = instance;
                        available = true;
                        return;
                    }
                } catch (Throwable ignored) {
                }
            }
            available = false;
        }
    }
}
