package com.Nextstars.ModPlugin.command;
import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.menu.StaffMenu;
import com.Nextstars.ModPlugin.util.TimeParser;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
public class StaffCommand implements CommandExecutor, TabCompleter {
    private final ModPlugin plugin;
    private static final List<String> SUBCOMMANDS = Arrays.asList(
            "reload", "appeal", "ticketmessage"
    );
    public StaffCommand(ModPlugin plugin) {
        this.plugin = plugin;
    }
    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage("Only players can open the menu.");
                return true;
            }
            new StaffMenu(plugin).open(player);
            player.sendMessage(plugin.getMessageManager().getStaff("opened-staff-menu"));
            return true;
        }
        String sub = args[0].toLowerCase();
        if (sub.equals("reload")) {
            if (!sender.hasPermission("modplugin.admin")) {
                sender.sendMessage(plugin.getMessageManager().getStaff("no-permission"));
                return true;
            }
            plugin.reload();
            sender.sendMessage(plugin.getMessageManager().getStaff("reloaded"));
            return true;
        }
        if (!(sender instanceof Player staff)) {
            sender.sendMessage("Only players can use this subcommand.");
            return true;
        }
        switch (sub) {
            case "freeze" -> {
                if (!staff.hasPermission("modplugin.freeze")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                if (args.length < 2) { staff.sendMessage("Usage: /staff freeze <player>"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found")); return true; }
                if (plugin.getFreezeManager().isFrozen(target)) {
                    plugin.getFreezeManager().unfreeze(target);
                    plugin.getMessageManager().sendActionBar(target, "player-unfrozen");
                    staff.sendMessage(plugin.getMessageManager().getStaff("unfroze-player", "%player%", target.getName()));
                } else {
                    plugin.getFreezeManager().freeze(target);
                    plugin.getMessageManager().sendActionBar(target, "player-now-frozen");
                    staff.sendMessage(plugin.getMessageManager().getStaff("froze-player", "%player%", target.getName()));
                }
                plugin.getConfigManager().playSound(staff, "freeze");
            }
            case "kick" -> {
                if (!staff.hasPermission("modplugin.kick")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                if (args.length < 2) { staff.sendMessage("Usage: /staff kick <player> <reason>"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found")); return true; }
                if (args.length < 3) {
                    plugin.getChatInputManager().requestReason(staff, reason -> executeKick(staff, target, reason));
                    return true;
                }
                String reasonInput = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
                executeKick(staff, target, reasonInput);
            }
            case "mute" -> {
                if (!staff.hasPermission("modplugin.mute")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                if (args.length < 2) { staff.sendMessage("Usage: /staff mute <player> <time> <reason>"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found")); return true; }
                if (args.length == 2) {
                    plugin.getChatInputManager().requestTimedReason(staff, input -> executeMute(staff, target, input));
                    return true;
                }
                if (args.length == 3) {
                    String timeArg = args[2];
                    plugin.getChatInputManager().requestReason(staff, reason -> executeMute(staff, target, timeArg + " " + reason));
                    return true;
                }
                String reasonInput = String.join(" ", Arrays.copyOfRange(args, 3, args.length));
                executeMute(staff, target, args[2] + " " + reasonInput);
            }
            case "unmute" -> {
                if (!staff.hasPermission("modplugin.mute")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                if (args.length < 2) { staff.sendMessage("Usage: /staff unmute <player>"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found")); return true; }
                plugin.getMuteManager().unmute(target.getUniqueId());
                plugin.getMessageManager().sendActionBar(target, "player-unmuted");
                staff.sendMessage(plugin.getMessageManager().getStaff("unmuted-player", "%player%", target.getName()));
                plugin.getConfigManager().playSound(staff, "mute");
            }
            case "ban" -> {
                if (!staff.hasPermission("modplugin.ban")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                if (args.length < 2) { staff.sendMessage("Usage: /staff ban <player> <duration> <reason>"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found")); return true; }
                if (args.length == 2) {
                    plugin.getChatInputManager().requestTimedReason(staff, input -> executeBan(staff, target, input));
                    return true;
                }
                if (args.length == 3) {
                    String timeArg = args[2];
                    plugin.getChatInputManager().requestReason(staff, reason -> executeBan(staff, target, timeArg + " " + reason));
                    return true;
                }
                String reasonInput = String.join(" ", Arrays.copyOfRange(args, 3, args.length));
                executeBan(staff, target, args[2] + " " + reasonInput);
            }
            case "appeal" -> {
                if (!staff.hasPermission("modplugin.admin")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                if (args.length < 2) { staff.sendMessage("Usage: /staff appeal <appealId>"); return true; }
                String id = args[1].trim();
                var am = plugin.getAppealManager();
                if (am == null) { staff.sendMessage("Appeals are unavailable."); return true; }
                var opt = am.load(id);
                if (opt.isEmpty()) { staff.sendMessage("Appeal not found: " + id); return true; }
                var r = opt.get();

                String when = java.time.Instant.ofEpochMilli(r.getCreatedAtMs())
                        .atZone(java.time.ZoneId.systemDefault())
                        .format(java.time.format.DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss"));

                staff.sendMessage("§bAppeal ID: §f" + r.getId());
                staff.sendMessage("§bPlayer: §f" + r.getPlayerName() + " §7(" + r.getPlayerUuid() + ")");
                staff.sendMessage("§bTime: §f" + when);
                staff.sendMessage("§bFlags: §f" + r.getTotalFlags());
                staff.sendMessage("§bCheck: §f" + r.getCheckName());
                if (r.getVerbose() != null && !r.getVerbose().isBlank()) staff.sendMessage("§bVerbose: §f" + r.getVerbose());
                staff.sendMessage("§bLocation: §f" + r.getWorld() + " " + String.format("%.2f %.2f %.2f", r.getX(), r.getY(), r.getZ()));
                if (r.getLastCommand() != null && !r.getLastCommand().isBlank()) staff.sendMessage("§bLast command: §f" + r.getLastCommand());
                if (r.getRecordingId() != null && !r.getRecordingId().isBlank()) staff.sendMessage("§bReplay: §f/flashback play " + r.getRecordingId());
                if (r.getStoredReplayPath() != null && !r.getStoredReplayPath().isBlank()) staff.sendMessage("§bStored replay: §f" + r.getStoredReplayPath());
            }
            case "ticketmessage" -> {
                if (!staff.hasPermission("modplugin.admin")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                if (args.length < 2) { staff.sendMessage("Usage: /staff ticketmessage <0|1|send>"); return true; }
                String v = args[1].trim().toLowerCase();
                if (v.equals("0") || v.equals("1")) {
                    plugin.getConfig().set("discord-bot.ticket.has-sent-ticket-message", Integer.parseInt(v));
                    plugin.saveConfig();
                    staff.sendMessage("Ticket panel flag set to: " + v);
                    return true;
                }
                if (v.equals("send")) {
                    plugin.getConfig().set("discord-bot.ticket.has-sent-ticket-message", 0);
                    plugin.saveConfig();
                    if (plugin.getDiscordBotManager() != null) {
                        plugin.getDiscordBotManager().sendTicketPanelIfNeeded();
                    }
                    staff.sendMessage("Ticket panel message sent.");
                    return true;
                }
                staff.sendMessage("Usage: /staff ticketmessage <0|1|send>");
            }
            case "unban" -> {
                if (!staff.hasPermission("modplugin.ban")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                if (args.length < 2) { staff.sendMessage("Usage: /staff unban <player>"); return true; }
                Player target = Bukkit.getPlayer(args[1]);
                org.bukkit.OfflinePlayer offline = Bukkit.getOfflinePlayer(args[1]);
                plugin.getBanManager().unban(offline.getUniqueId());
                staff.sendMessage(plugin.getMessageManager().getStaff("unbanned-player", "%player%", args[1]));
            }
            case "warn" -> {
                if (!staff.hasPermission("modplugin.warn")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                if (args.length < 2) { staff.sendMessage("Usage: /staff warn <player> <reason>"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found")); return true; }
                if (args.length < 3) {
                    plugin.getChatInputManager().requestReason(staff, reason -> executeWarn(staff, target, reason));
                    return true;
                }
                String reasonInput = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
                executeWarn(staff, target, reasonInput);
            }
            case "teleport", "tp" -> {
                if (!staff.hasPermission("modplugin.teleport")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                if (args.length < 2) { staff.sendMessage("Usage: /staff teleport <player>"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found")); return true; }
                staff.teleport(target.getLocation());
                staff.sendMessage(plugin.getMessageManager().getStaff("teleported-to-player", "%player%", target.getName()));
                plugin.getConfigManager().playSound(staff, "teleport");
            }
            case "vanish" -> {
                if (!staff.hasPermission("modplugin.vanish")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                if (plugin.getVanishManager().isVanished(staff)) {
                    plugin.getVanishManager().unvanish(staff);
                    staff.sendMessage(plugin.getMessageManager().getStaff("vanish-off"));
                } else {
                    plugin.getVanishManager().vanish(staff);
                    staff.sendMessage(plugin.getMessageManager().getStaff("vanish-on"));
                }
                plugin.getConfigManager().playSound(staff, "vanish");
            }
            case "clear" -> {
                if (!staff.hasPermission("modplugin.clear")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                if (args.length < 2) { staff.sendMessage("Usage: /staff clear <player>"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found")); return true; }
                target.getInventory().clear();
                plugin.getMessageManager().sendActionBar(target, "player-inventory-cleared");
                staff.sendMessage(plugin.getMessageManager().getStaff("cleared-inventory", "%player%", target.getName()));
                plugin.getConfigManager().playSound(staff, "clear");
            }
            case "fly" -> {
                if (!staff.hasPermission("modplugin.fly")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                boolean enabled = plugin.getFlyManager().toggle(staff);
                staff.sendMessage(plugin.getMessageManager().getStaff(enabled ? "fly-on" : "fly-off"));
                plugin.getConfigManager().playSound(staff, "fly");
            }
            case "invsee" -> {
                if (!staff.hasPermission("modplugin.invsee")) { staff.sendMessage(plugin.getMessageManager().getStaff("no-permission")); return true; }
                if (args.length < 2) { staff.sendMessage("Usage: /staff invsee <player>"); return true; }
                Player target = Bukkit.getPlayerExact(args[1]);
                if (target == null) { staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found")); return true; }
                boolean allowEdit = plugin.getConfigManager().getBoolean("invsee.allow-edit", false);
                String rawTitle = plugin.getConfigManager().getString("invsee.gui.title", "&8InvSee: &b%player%");
                String title = org.bukkit.ChatColor.translateAlternateColorCodes('&', rawTitle.replace("%player%", target.getName()));
                var holder = new com.Nextstars.ModPlugin.util.StaffInventoryHolder("invsee");
                org.bukkit.inventory.Inventory inv = Bukkit.createInventory(holder, 54, title);
                String fillerMatName = plugin.getConfigManager().getString("invsee.gui.filler.material", "BLACK_STAINED_GLASS_PANE");
                org.bukkit.Material fillerMat = org.bukkit.Material.matchMaterial(fillerMatName);
                if (fillerMat == null) fillerMat = org.bukkit.Material.BLACK_STAINED_GLASS_PANE;
                String fillerName = plugin.getConfigManager().getString("invsee.gui.filler.name", " ");
                org.bukkit.inventory.ItemStack filler = new org.bukkit.inventory.ItemStack(fillerMat);
                org.bukkit.inventory.meta.ItemMeta fillerMeta = filler.getItemMeta();
                if (fillerMeta != null) {
                    fillerMeta.setDisplayName(org.bukkit.ChatColor.translateAlternateColorCodes('&', fillerName));
                    filler.setItemMeta(fillerMeta);
                }
                for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);
                org.bukkit.inventory.ItemStack[] contents = target.getInventory().getContents();
                for (int i = 0; i < 36 && i < contents.length; i++) inv.setItem(i, contents[i]);
                int helmetSlot = plugin.getConfigManager().getInt("invsee.gui.slots.helmet", 47);
                int chestSlot  = plugin.getConfigManager().getInt("invsee.gui.slots.chestplate", 48);
                int legsSlot   = plugin.getConfigManager().getInt("invsee.gui.slots.leggings", 49);
                int bootsSlot  = plugin.getConfigManager().getInt("invsee.gui.slots.boots", 50);
                int offhandSlot= plugin.getConfigManager().getInt("invsee.gui.slots.offhand", 52);
                inv.setItem(helmetSlot, target.getInventory().getHelmet());
                inv.setItem(chestSlot,  target.getInventory().getChestplate());
                inv.setItem(legsSlot,   target.getInventory().getLeggings());
                inv.setItem(bootsSlot,  target.getInventory().getBoots());
                inv.setItem(offhandSlot, target.getInventory().getItemInOffHand());
                plugin.getInvseeManager().start(staff, target, allowEdit, inv);
                staff.openInventory(inv);
                staff.sendMessage(plugin.getMessageManager().getStaff("invsee-open", "%player%", target.getName()));
                plugin.getConfigManager().playSound(staff, "invsee");
            }
            default -> staff.sendMessage("Unknown subcommand. Use /staff for the menu.");
        }
        return true;
    }
    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        List<String> onlinePlayers = Bukkit.getOnlinePlayers().stream()
                .map(Player::getName).collect(Collectors.toList());
        if (args.length == 1) {
            return SUBCOMMANDS.stream()
                    .filter(s -> s.startsWith(args[0].toLowerCase()))
                    .collect(Collectors.toList());
        }
        String sub = args[0].toLowerCase();
        if (args.length == 2 && List.of("freeze","kick","mute","unmute","ban","warn","teleport","tp","clear").contains(sub)) {
            return onlinePlayers.stream().filter(p -> p.toLowerCase().startsWith(args[1].toLowerCase())).collect(Collectors.toList());
        }
        if (args.length == 2 && sub.equals("unban")) {
            return List.of("<player>");
        }
        if (args.length == 3 && sub.equals("mute")) {
            List<String> suggestions = new ArrayList<>(List.of("1m","30m","1h","6h","24h","7d","permanent"));
            suggestions.addAll(plugin.getMuteReasonManager().getTabSuggestions().stream()
                    .map(s -> s.split(" ")[0]).collect(Collectors.toList()));
            return suggestions;
        }
        if (args.length >= 4 && sub.equals("mute")) {
            return plugin.getMuteReasonManager().getTabSuggestions().stream()
                    .filter(s -> s.startsWith(args[2] + " "))
                    .map(s -> String.join(" ", Arrays.copyOfRange(s.split(" "), 1, s.split(" ").length)))
                    .collect(Collectors.toList());
        }
        if (args.length == 3 && sub.equals("ban")) {
            return List.of("1h","24h","7d","30d","permanent");
        }
        if (args.length == 2 && sub.equals("ticketmessage")) {
            return List.of("0", "1", "send");
        }
        return result;
    }

    private void executeKick(Player staff, Player target, String reasonInput) {
        String reason = plugin.getReasonManager().resolveReason(com.Nextstars.ModPlugin.manager.ReasonManager.Type.KICK, reasonInput);
        String screen = plugin.getMessageManager().getRaw("kick-screen", "%reason%", reason);
        target.kickPlayer(screen);
        staff.sendMessage(plugin.getMessageManager().getStaff("kicked-player", "%player%", target.getName(), "%reason%", reason));
        plugin.getConfigManager().playSound(staff, "kick");
    }

    private void executeMute(Player staff, Player target, String input) {
        String[] parts = input.split(" ", 2);
        long duration = TimeParser.parse(parts[0]);
        String reasonInput = parts.length > 1 ? parts[1] : "No reason";
        if (duration == 0) {
            reasonInput = input;
            duration = -1;
        }
        String reason = plugin.getReasonManager().resolveReason(com.Nextstars.ModPlugin.manager.ReasonManager.Type.MUTE, reasonInput);
        plugin.getMuteManager().mute(target, reason, duration);
        plugin.getMessageManager().sendActionBar(target, "player-muted", "%reason%", reason);
        staff.sendMessage(plugin.getMessageManager().getStaff("muted-player",
                "%player%", target.getName(),
                "%duration%", TimeParser.formatDuration(duration),
                "%reason%", reason));
        plugin.getConfigManager().playSound(staff, "mute");
    }

    private void executeBan(Player staff, Player target, String input) {
        String[] parts = input.split(" ", 2);
        long duration = TimeParser.parse(parts[0]);
        String reasonInput = parts.length > 1 ? parts[1] : "No reason";
        if (duration == 0) {
            reasonInput = input;
            duration = -1;
        }
        String reason = plugin.getReasonManager().resolveReason(com.Nextstars.ModPlugin.manager.ReasonManager.Type.BAN, reasonInput);
        String banId = plugin.getBanManager().ban(target.getUniqueId(), target.getName(), reason, duration, staff.getName());
        String durationText = TimeParser.formatDuration(duration);
        String screen = plugin.getMessageManager().getRaw("ban-screen",
                "%reason%", reason,
                "%duration%", durationText,
                "%time_left%", durationText,
                "%ban_id%", banId,
                "%appeal_window%", "7 days",
                "%evidence_window%", "30 days");
        target.kickPlayer(screen);
        staff.sendMessage(plugin.getMessageManager().getStaff("banned-player",
                "%player%", target.getName(),
                "%duration%", durationText,
                "%reason%", reason,
                "%ban_id%", banId));
        plugin.getConfigManager().playSound(staff, "ban");
    }

    private void executeWarn(Player staff, Player target, String reasonInput) {
        String reason = plugin.getReasonManager().resolveReason(com.Nextstars.ModPlugin.manager.ReasonManager.Type.WARN, reasonInput);
        plugin.getWarnManager().addWarn(target.getUniqueId(), reason);
        int warns = plugin.getWarnManager().getWarnCount(target.getUniqueId());
        int max = plugin.getConfigManager().getMaxWarns();
        staff.sendMessage(plugin.getMessageManager().getStaff("warned-player",
                "%player%", target.getName(), "%warns%", String.valueOf(warns), "%max%", String.valueOf(max)));
        plugin.getConfigManager().playSound(staff, "warn");
        if (plugin.getConfigManager().isKickOnWarn()) {
            String screen = plugin.getMessageManager().getRaw("warn-kick-screen",
                    "%reason%", reason,
                    "%warns%", String.valueOf(warns),
                    "%warnings%", String.valueOf(warns),
                    "%max%", String.valueOf(max),
                    "%Number%", String.valueOf(max));
            target.kickPlayer(screen);
        }
    }
}
