package com.Nextstars.ModPlugin.command;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.command.TabCompleter;
import java.util.*;

public class FreezeCommand implements CommandExecutor, TabCompleter {

    private final ModPlugin plugin;

    public FreezeCommand(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player staff)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!staff.hasPermission("modplugin.freeze")) {
            staff.sendMessage(plugin.getMessageManager().getStaff("no-permission"));
            return true;
        }
        if (args.length < 1) {
            staff.sendMessage("Usage: /freeze <player>");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found"));
            return true;
        }
        if (plugin.getFreezeManager().isFrozen(target)) {
            plugin.getFreezeManager().unfreeze(target);
            plugin.getMessageManager().sendActionBar(target, "player-unfrozen");
            staff.sendMessage(plugin.getMessageManager().getStaff("unfroze-player", "%player%", target.getName()));
        } else {
            plugin.getFreezeManager().freeze(target);
            plugin.getMessageManager().sendActionBar(target, "player-now-frozen");
            staff.sendMessage(plugin.getMessageManager().getStaff("froze-player", "%player%", target.getName()));
        }
        plugin.getConfigManager().playSound(staff, "freeze");
        return true;
    }

@Override
    public java.util.List<String> onTabComplete(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) {
            java.util.List<String> out = new java.util.ArrayList<>();
            for (org.bukkit.entity.Player p : org.bukkit.Bukkit.getOnlinePlayers()) out.add(p.getName());
            java.util.Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
            return out;
        }
        return java.util.Collections.emptyList();
    }
}
