package com.Nextstars.ModPlugin.command;

import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.util.StaffInventoryHolder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.command.TabCompleter;
import java.util.*;

public class InvseeCommand implements CommandExecutor, TabCompleter {

    private final ModPlugin plugin;

    public InvseeCommand(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player staff)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!staff.hasPermission("modplugin.invsee")) {
            staff.sendMessage(plugin.getMessageManager().getStaff("no-permission"));
            return true;
        }
        if (args.length < 1) {
            staff.sendMessage("Usage: /invsee <player>");
            return true;
        }

        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found"));
            return true;
        }

        boolean allowEdit = plugin.getConfigManager().getBoolean("invsee.allow-edit", false)
                && staff.hasPermission("modplugin.invsee.edit");

        String rawTitle = plugin.getConfigManager().getString("invsee.gui.title", "&8InvSee: &b%player%");
        String title = org.bukkit.ChatColor.translateAlternateColorCodes('&', rawTitle.replace("%player%", target.getName()));
        Inventory inv = Bukkit.createInventory(new StaffInventoryHolder("invsee"), 54, title);

        String fillerMatName = plugin.getConfigManager().getString("invsee.gui.filler.material", "BLACK_STAINED_GLASS_PANE");
        Material fillerMat = Material.matchMaterial(fillerMatName);
        if (fillerMat == null) fillerMat = Material.BLACK_STAINED_GLASS_PANE;
        String fillerName = plugin.getConfigManager().getString("invsee.gui.filler.name", " ");
        ItemStack filler = new ItemStack(fillerMat);
        ItemMeta meta = filler.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(org.bukkit.ChatColor.translateAlternateColorCodes('&', fillerName));
            filler.setItemMeta(meta);
        }
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);

        ItemStack[] contents = target.getInventory().getContents();
        for (int i = 0; i < 36 && i < contents.length; i++) inv.setItem(i, contents[i] != null ? contents[i].clone() : null);

        int helmetSlot = plugin.getConfigManager().getInt("invsee.gui.slots.helmet", 47);
        int chestSlot = plugin.getConfigManager().getInt("invsee.gui.slots.chestplate", 48);
        int legsSlot = plugin.getConfigManager().getInt("invsee.gui.slots.leggings", 49);
        int bootsSlot = plugin.getConfigManager().getInt("invsee.gui.slots.boots", 50);
        int offhandSlot = plugin.getConfigManager().getInt("invsee.gui.slots.offhand", 52);

        inv.setItem(helmetSlot, target.getInventory().getHelmet() != null ? target.getInventory().getHelmet().clone() : null);
        inv.setItem(chestSlot, target.getInventory().getChestplate() != null ? target.getInventory().getChestplate().clone() : null);
        inv.setItem(legsSlot, target.getInventory().getLeggings() != null ? target.getInventory().getLeggings().clone() : null);
        inv.setItem(bootsSlot, target.getInventory().getBoots() != null ? target.getInventory().getBoots().clone() : null);
        inv.setItem(offhandSlot, target.getInventory().getItemInOffHand() != null ? target.getInventory().getItemInOffHand().clone() : null);

        plugin.getInvseeManager().start(staff, target, allowEdit, inv);
        staff.openInventory(inv);
        staff.sendMessage(plugin.getMessageManager().getStaff("invsee-open", "%player%", target.getName()));
        plugin.getConfigManager().playSound(staff, "invsee");
        return true;
    }

@Override
    public java.util.List<String> onTabComplete(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) {
            java.util.List<String> out = new java.util.ArrayList<>();
            for (org.bukkit.entity.Player p : org.bukkit.Bukkit.getOnlinePlayers()) out.add(p.getName());
            java.util.Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
            return out;
        }
        return java.util.Collections.emptyList();
    }
}
