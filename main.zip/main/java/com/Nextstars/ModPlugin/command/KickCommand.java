package com.Nextstars.ModPlugin.command;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;
import org.bukkit.command.TabCompleter;
import java.util.*;

public class KickCommand implements CommandExecutor, TabCompleter {

    private final ModPlugin plugin;

    public KickCommand(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player staff = (sender instanceof Player p) ? p : null;
        if (staff != null && !staff.hasPermission("modplugin.kick")) {
            staff.sendMessage(plugin.getMessageManager().getStaff("no-permission"));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage("Usage: /kick <player> <reason>");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getMessageManager().getStaff("player-not-found"));
            return true;
        }
        if (target.hasPermission("modplugin.bypass.kick")) {
            sender.sendMessage(plugin.getMessageManager().getStaff("target-bypasses"));
            return true;
        }
        if (args.length < 2) {
            if (staff == null) {
                sender.sendMessage("Usage: /kick <player> <reason>");
                return true;
            }
            plugin.getChatInputManager().requestReason(staff, reason -> executeKick(sender, staff, target, reason));
            return true;
        }
        String reasonInput = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        String reason = plugin.getReasonManager().resolveReason(com.Nextstars.ModPlugin.manager.ReasonManager.Type.KICK, reasonInput);
        executeKick(sender, staff, target, reason);
        return true;
    }

    private void executeKick(CommandSender sender, Player staff, Player target, String reason) {
        String resolved = plugin.getReasonManager().resolveReason(com.Nextstars.ModPlugin.manager.ReasonManager.Type.KICK, reason);
        String screen = plugin.getMessageManager().getRaw("kick-screen", "%reason%", resolved);
        target.kickPlayer(screen);
        sender.sendMessage(plugin.getMessageManager().getStaff("kicked-player", "%player%", target.getName(), "%reason%", resolved));
        if (staff != null) plugin.getConfigManager().playSound(staff, "kick");
    }

@Override
    public java.util.List<String> onTabComplete(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) {
            java.util.List<String> out = new java.util.ArrayList<>();
            for (org.bukkit.entity.Player p : org.bukkit.Bukkit.getOnlinePlayers()) out.add(p.getName());
            java.util.Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
            return out;
        }
        if (args.length == 2) {
            java.util.List<String> keys = plugin.getReasonManager().getKeys(com.Nextstars.ModPlugin.manager.ReasonManager.Type.KICK);
            if (!keys.isEmpty()) return keys;
            return java.util.Collections.singletonList("<reason>");
        }
        return java.util.Collections.emptyList();
    }
}
