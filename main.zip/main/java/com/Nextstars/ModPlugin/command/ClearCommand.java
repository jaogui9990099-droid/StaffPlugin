package com.Nextstars.ModPlugin.command;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.command.TabCompleter;
import java.util.*;

public class ClearCommand implements CommandExecutor, TabCompleter {

    private final ModPlugin plugin;

    public ClearCommand(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player staff)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!staff.hasPermission("modplugin.clear")) {
            staff.sendMessage(plugin.getMessageManager().getStaff("no-permission"));
            return true;
        }
        if (args.length < 1) {
            staff.sendMessage("Usage: /clear <player>");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found"));
            return true;
        }
        target.getInventory().clear();
        plugin.getMessageManager().sendActionBar(target, "player-inventory-cleared");
        staff.sendMessage(plugin.getMessageManager().getStaff("cleared-inventory", "%player%", target.getName()));
        plugin.getConfigManager().playSound(staff, "clear");
        return true;
    }

@Override
    public java.util.List<String> onTabComplete(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) {
            java.util.List<String> out = new java.util.ArrayList<>();
            for (org.bukkit.entity.Player p : org.bukkit.Bukkit.getOnlinePlayers()) out.add(p.getName());
            java.util.Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
            return out;
        }
        return java.util.Collections.emptyList();
    }
}
