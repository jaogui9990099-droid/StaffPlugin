package com.Nextstars.ModPlugin.command;

import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.util.TimeParser;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;
import org.bukkit.command.TabCompleter;
import java.util.*;

public class MuteCommand implements CommandExecutor, TabCompleter {

    private final ModPlugin plugin;

    public MuteCommand(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player staff = (sender instanceof Player p) ? p : null;
        if (staff != null && !staff.hasPermission("modplugin.mute")) {
            staff.sendMessage(plugin.getMessageManager().getStaff("no-permission"));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage("Usage: /mute <player> <time> <reason>");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getMessageManager().getStaff("player-not-found"));
            return true;
        }
        if (target.hasPermission("modplugin.bypass.mute")) {
            sender.sendMessage(plugin.getMessageManager().getStaff("target-bypasses"));
            return true;
        }
        if (args.length == 1) {
            if (staff == null) {
                sender.sendMessage("Usage: /mute <player> <time> <reason>");
                return true;
            }
            plugin.getChatInputManager().requestTimedReason(staff, input -> executeMute(sender, staff, target, input));
            return true;
        }
        if (args.length == 2) {
            if (staff == null) {
                sender.sendMessage("Usage: /mute <player> <time> <reason>");
                return true;
            }
            String timeArg = args[1];
            plugin.getChatInputManager().requestReason(staff, reason -> executeMute(sender, staff, target, timeArg + " " + reason));
            return true;
        }
        long duration = TimeParser.parse(args[1]);
        String reasonInput = String.join(" ", Arrays.copyOfRange(args, 2, args.length));
        String reason = plugin.getReasonManager().resolveReason(com.Nextstars.ModPlugin.manager.ReasonManager.Type.MUTE, reasonInput);
        executeMute(sender, staff, target, args[1] + " " + reason);
        return true;
    }

    private void executeMute(CommandSender sender, Player staff, Player target, String input) {
        String[] parts = input.split(" ", 2);
        long duration = TimeParser.parse(parts[0]);
        String reasonText = parts.length > 1 ? parts[1] : "No reason";
        if (duration == 0) {
            reasonText = input;
            duration = -1;
        }
        String resolved = plugin.getReasonManager().resolveReason(com.Nextstars.ModPlugin.manager.ReasonManager.Type.MUTE, reasonText);
        plugin.getMuteManager().mute(target, resolved, duration);
        plugin.getMessageManager().sendActionBar(target, "player-muted", "%reason%", resolved);
        sender.sendMessage(plugin.getMessageManager().getStaff("muted-player",
                "%player%", target.getName(),
                "%duration%", TimeParser.formatDuration(duration),
                "%reason%", resolved));
        if (staff != null) plugin.getConfigManager().playSound(staff, "mute");
    }

@Override
    public java.util.List<String> onTabComplete(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) {
            java.util.List<String> out = new java.util.ArrayList<>();
            for (org.bukkit.entity.Player p : org.bukkit.Bukkit.getOnlinePlayers()) out.add(p.getName());
            java.util.Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
            return out;
        }
        if (args.length == 2) {
            return java.util.Arrays.asList("-1", "5m", "10m", "30m", "1h", "6h", "12h", "1d", "3d", "7d", "14d", "30d");
        }
        if (args.length == 3) {
            java.util.List<String> keys = plugin.getReasonManager().getKeys(com.Nextstars.ModPlugin.manager.ReasonManager.Type.MUTE);
            if (!keys.isEmpty()) return keys;
            return java.util.Collections.singletonList("<reason>");
        }
        return java.util.Collections.emptyList();
    }
}
