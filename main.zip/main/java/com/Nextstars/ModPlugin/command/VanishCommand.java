package com.Nextstars.ModPlugin.command;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class VanishCommand implements CommandExecutor {

    private final ModPlugin plugin;

    public VanishCommand(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player staff)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!staff.hasPermission("modplugin.vanish")) {
            staff.sendMessage(plugin.getMessageManager().getStaff("no-permission"));
            return true;
        }
        if (plugin.getVanishManager().isVanished(staff)) {
            plugin.getVanishManager().unvanish(staff);
            staff.sendMessage(plugin.getMessageManager().getStaff("vanish-off"));
        } else {
            plugin.getVanishManager().vanish(staff);
            staff.sendMessage(plugin.getMessageManager().getStaff("vanish-on"));
        }
        plugin.getConfigManager().playSound(staff, "vanish");
        return true;
    }
}
