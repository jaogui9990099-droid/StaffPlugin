package com.Nextstars.ModPlugin.command;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class FlyCommand implements CommandExecutor {

    private final ModPlugin plugin;

    public FlyCommand(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player staff)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!staff.hasPermission("modplugin.fly")) {
            staff.sendMessage(plugin.getMessageManager().getStaff("no-permission"));
            return true;
        }
        boolean enabled = plugin.getFlyManager().toggle(staff);
        staff.sendMessage(plugin.getMessageManager().getStaff(enabled ? "fly-on" : "fly-off"));
        plugin.getConfigManager().playSound(staff, "fly");
        return true;
    }
}
