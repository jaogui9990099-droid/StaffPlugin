package com.Nextstars.ModPlugin.command;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Arrays;
import org.bukkit.command.TabCompleter;
import java.util.*;

public class WarnCommand implements CommandExecutor, TabCompleter {

    private final ModPlugin plugin;

    public WarnCommand(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Player staff = (sender instanceof Player p) ? p : null;
        if (staff != null && !staff.hasPermission("modplugin.warn")) {
            staff.sendMessage(plugin.getMessageManager().getStaff("no-permission"));
            return true;
        }
        if (args.length < 1) {
            sender.sendMessage("Usage: /warn <player> <reason>");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            sender.sendMessage(plugin.getMessageManager().getStaff("player-not-found"));
            return true;
        }
        if (target.hasPermission("modplugin.bypass.warn")) {
            sender.sendMessage(plugin.getMessageManager().getStaff("target-bypasses"));
            return true;
        }
        if (args.length < 2) {
            if (staff == null) {
                sender.sendMessage("Usage: /warn <player> <reason>");
                return true;
            }
            plugin.getChatInputManager().requestReason(staff, reason -> executeWarn(sender, staff, target, reason));
            return true;
        }
        String reasonInput = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        String reason = plugin.getReasonManager().resolveReason(com.Nextstars.ModPlugin.manager.ReasonManager.Type.WARN, reasonInput);
        executeWarn(sender, staff, target, reason);
        return true;
    }

    private void executeWarn(CommandSender sender, Player staff, Player target, String reason) {
        String resolved = plugin.getReasonManager().resolveReason(com.Nextstars.ModPlugin.manager.ReasonManager.Type.WARN, reason);
        plugin.getWarnManager().addWarn(target.getUniqueId(), resolved);
        int warns = plugin.getWarnManager().getWarnCount(target.getUniqueId());
        int max = plugin.getConfigManager().getMaxWarns();
        sender.sendMessage(plugin.getMessageManager().getStaff("warned-player",
                "%player%", target.getName(),
                "%warns%", String.valueOf(warns),
                "%max%", String.valueOf(max)));
        if (staff != null) plugin.getConfigManager().playSound(staff, "warn");
        if (plugin.getConfigManager().isKickOnWarn()) {
            String screen = plugin.getMessageManager().getRaw("warn-kick-screen",
                    "%reason%", resolved,
                    "%warns%", String.valueOf(warns),
                    "%warnings%", String.valueOf(warns),
                    "%max%", String.valueOf(max),
                    "%Number%", String.valueOf(max));
            target.kickPlayer(screen);
        }
    }

@Override
    public java.util.List<String> onTabComplete(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) {
            java.util.List<String> out = new java.util.ArrayList<>();
            for (org.bukkit.entity.Player p : org.bukkit.Bukkit.getOnlinePlayers()) out.add(p.getName());
            java.util.Collections.sort(out, String.CASE_INSENSITIVE_ORDER);
            return out;
        }
        if (args.length == 2) {
            java.util.List<String> keys = plugin.getReasonManager().getKeys(com.Nextstars.ModPlugin.manager.ReasonManager.Type.WARN);
            if (!keys.isEmpty()) return keys;
            return java.util.Collections.singletonList("<reason>");
        }
        return java.util.Collections.emptyList();
    }
}
