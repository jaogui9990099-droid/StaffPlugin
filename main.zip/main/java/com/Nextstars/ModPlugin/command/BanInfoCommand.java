package com.Nextstars.ModPlugin.command;

import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.util.TimeParser;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import java.util.*;

public class BanInfoCommand implements CommandExecutor, TabCompleter {

    private final ModPlugin plugin;

    public BanInfoCommand(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("modplugin.baninfo") && !sender.hasPermission("modplugin.ban")) {
            sender.sendMessage(ChatColor.RED + "No permission.");
            return true;
        }

        if (args.length < 1) {
            sender.sendMessage(ChatColor.RED + "Usage: /baninfo <id>");
            return true;
        }

        String id = args[0].trim();
        var entry = plugin.getBanManager().getByBanId(id);
        if (entry == null) {
            sender.sendMessage(ChatColor.RED + "Ban ID not found: " + id);
            return true;
        }

        String timeLeft;
        if (entry.getExpires() == -1) {
            timeLeft = "Permanent";
        } else {
            long remaining = entry.getExpires() - System.currentTimeMillis();
            timeLeft = remaining <= 0 ? "Expired" : TimeParser.format(remaining);
        }

        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&8&m--------------------------------"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&cBan Info"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&7Ban ID: &f" + entry.getBanId()));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&7Player: &f" + entry.getName() + " &8(" + entry.getUuid() + ")"));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&7Reason: &f" + entry.getReason()));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&7Banned by: &f" + entry.getBannedBy()));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&7Time left: &f" + timeLeft));
        sender.sendMessage(ChatColor.translateAlternateColorCodes('&',
                "&8&m--------------------------------"));
        return true;
    }

@Override
    public java.util.List<String> onTabComplete(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) return java.util.Collections.singletonList("<ban_id>");
        return java.util.Collections.emptyList();
    }
}
