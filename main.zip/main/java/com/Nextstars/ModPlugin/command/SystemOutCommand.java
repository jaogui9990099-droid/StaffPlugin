package com.Nextstars.ModPlugin.command;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import java.util.*;

public class SystemOutCommand implements CommandExecutor, TabCompleter {

    private final ModPlugin plugin;

    public SystemOutCommand(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("modplugin.admin")) {
            sender.sendMessage(plugin.getMessageManager().getStaff("no-permission"));
            return true;
        }
        if (args.length == 0) {
            sender.sendMessage("Usage: /systemout <message>");
            return true;
        }
        String msg = String.join(" ", args);
        System.out.println("[SystemOut] " + msg);
        sender.sendMessage("§aPrinted to console.");
        return true;
    }

@Override
    public java.util.List<String> onTabComplete(org.bukkit.command.CommandSender sender, org.bukkit.command.Command command, String alias, String[] args) {
        if (args.length == 1) return java.util.Collections.singletonList("<message>");
        return java.util.Collections.emptyList();
    }
}
