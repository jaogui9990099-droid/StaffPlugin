package com.Nextstars.ModPlugin.command;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.TreeSet;

public class TeleportCommand implements CommandExecutor, TabCompleter {
    private static final String USAGE = "Usage: /tp <player> | /tp <x> <y> <z> | /tp <player> <player> | /tp <player> <x> <y> <z>";
    private static final String PLAYER_PLACEHOLDER = "<player>";
    private static final String PLAYER_CAP_PLACEHOLDER = "<Player>";
    private static final String COORDINATES_PLACEHOLDER = "<Coordinates>";

    private final ModPlugin plugin;

    public TeleportCommand(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player staff)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!staff.hasPermission("modplugin.teleport")) {
            staff.sendMessage(plugin.getMessageManager().getStaff("no-permission"));
            return true;
        }
        if (args.length < 1) {
            staff.sendMessage(USAGE);
            return true;
        }

        if (args.length == 1) {
            Location destination = getPlayerLocation(args[0]);
            if (destination == null) {
                staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found"));
                return true;
            }

            String targetName = readablePlayerName(args[0]);
            staff.teleport(destination);
            staff.sendMessage(plugin.getMessageManager().getStaff("teleport-self-player", "%player%", targetName));
            plugin.getConfigManager().playSound(staff, "teleport");
            return true;
        }

        if (args.length == 2) {
            Player mover = Bukkit.getPlayerExact(args[0]);
            if (mover == null) {
                staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found"));
                return true;
            }

            Location destination = getPlayerLocation(args[1]);
            if (destination == null) {
                staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found"));
                return true;
            }

            String targetName = readablePlayerName(args[1]);
            mover.teleport(destination);
            staff.sendMessage(plugin.getMessageManager().getStaff(
                    "teleport-player-to-player",
                    "%player%", mover.getName(),
                    "%target%", targetName
            ));
            plugin.getConfigManager().playSound(staff, "teleport");
            return true;
        }

        if (args.length == 3) {
            Location destination = parseCoordinates(staff, args, 0);
            if (destination == null) {
                staff.sendMessage(USAGE);
                return true;
            }

            String coordinates = formatCoordinates(destination);
            staff.teleport(destination);
            staff.sendMessage(plugin.getMessageManager().getStaff("teleport-self-coordinates", "%coordinates%", coordinates));
            plugin.getConfigManager().playSound(staff, "teleport");
            return true;
        }

        if (args.length == 4) {
            Player mover = Bukkit.getPlayerExact(args[0]);
            if (mover == null) {
                staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found"));
                return true;
            }

            Location destination = parseCoordinates(mover, args, 1);
            if (destination == null) {
                staff.sendMessage(USAGE);
                return true;
            }

            String coordinates = formatCoordinates(destination);
            mover.teleport(destination);
            staff.sendMessage(plugin.getMessageManager().getStaff(
                    "teleport-player-to-coordinates",
                    "%player%", mover.getName(),
                    "%coordinates%", coordinates
            ));
            plugin.getConfigManager().playSound(staff, "teleport");
            return true;
        }

        staff.sendMessage(USAGE);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            List<String> suggestions = new ArrayList<>(matchTemplate(args[0], PLAYER_PLACEHOLDER, COORDINATES_PLACEHOLDER));
            suggestions.addAll(matchPlayers(args[0]));
            return unique(suggestions);
        }
        if (args.length == 2) {
            if (looksLikeCoordinate(args[0])) {
                return matchTemplate(args[1], COORDINATES_PLACEHOLDER);
            }

            List<String> suggestions = new ArrayList<>(matchTemplate(args[1], PLAYER_CAP_PLACEHOLDER, COORDINATES_PLACEHOLDER));
            suggestions.addAll(matchPlayers(args[1]));
            return unique(suggestions);
        }
        if (args.length == 3) {
            return matchTemplate(args[2], COORDINATES_PLACEHOLDER);
        }
        if (args.length == 4) {
            return matchTemplate(args[3], COORDINATES_PLACEHOLDER);
        }
        return Collections.emptyList();
    }

    private List<String> matchPlayers(String input) {
        Set<String> names = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        String query = input.toLowerCase(Locale.ROOT);

        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.getName().toLowerCase(Locale.ROOT).startsWith(query)) {
                names.add(player.getName());
            }
        }

        for (OfflinePlayer player : Bukkit.getOfflinePlayers()) {
            String name = player.getName();
            if (name != null && !name.isBlank() && name.toLowerCase(Locale.ROOT).startsWith(query)) {
                names.add(name);
            }
        }

        return new ArrayList<>(names);
    }

    private List<String> matchTemplate(String input, String... values) {
        List<String> suggestions = new ArrayList<>();
        String query = input.toLowerCase(Locale.ROOT);
        for (String value : values) {
            if (value.toLowerCase(Locale.ROOT).startsWith(query)) {
                suggestions.add(value);
            }
        }
        return suggestions;
    }

    private List<String> unique(List<String> values) {
        TreeSet<String> uniqueValues = new TreeSet<>(String.CASE_INSENSITIVE_ORDER);
        uniqueValues.addAll(values);
        return new ArrayList<>(uniqueValues);
    }

    private Location parseCoordinates(Player reference, String[] args, int startIndex) {
        try {
            double x = Double.parseDouble(args[startIndex]);
            double y = Double.parseDouble(args[startIndex + 1]);
            double z = Double.parseDouble(args[startIndex + 2]);
            Location current = reference.getLocation();
            return new Location(reference.getWorld(), x, y, z, current.getYaw(), current.getPitch());
        } catch (NumberFormatException ex) {
            return null;
        }
    }

    private Location getPlayerLocation(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            return online.getLocation();
        }

        OfflinePlayer offline = Bukkit.getOfflinePlayer(name);
        if (!offline.hasPlayedBefore() && !offline.isOnline()) {
            return null;
        }
        return offline.getLocation();
    }

    private String readablePlayerName(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) {
            return online.getName();
        }

        OfflinePlayer offline = Bukkit.getOfflinePlayer(name);
        return offline.getName() != null ? offline.getName() : name;
    }

    private boolean looksLikeCoordinate(String value) {
        if (value == null || value.isBlank()) {
            return false;
        }
        if (COORDINATES_PLACEHOLDER.equalsIgnoreCase(value)) {
            return true;
        }
        try {
            Double.parseDouble(value);
            return true;
        } catch (NumberFormatException ex) {
            return false;
        }
    }

    private String formatCoordinates(Location location) {
        return String.format(Locale.US, "%.2f %.2f %.2f", location.getX(), location.getY(), location.getZ());
    }
}
