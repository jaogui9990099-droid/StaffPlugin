package com.Nextstars.ModPlugin.listener;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import java.util.UUID;
public class BanListener implements Listener {
    private final ModPlugin plugin;
    public BanListener(ModPlugin plugin) {
        this.plugin = plugin;
    }
    @EventHandler
    public void onPreLogin(AsyncPlayerPreLoginEvent event) {
        UUID uuid = event.getUniqueId();
        if (!plugin.getBanManager().isBanned(uuid)) return;
        String reason = plugin.getBanManager().getReason(uuid);
        String duration = plugin.getBanManager().getDuration(uuid);
        String banId = plugin.getBanManager().getBanId(uuid);
        String screen = plugin.getMessageManager().getRaw("ban-screen",
                "%reason%", reason,
                "%duration%", duration,
                "%time_left%", duration,
                "%ban_id%", banId,
                "%appeal_window%", "7 days",
                "%evidence_window%", "30 days"
        );
        event.setLoginResult(AsyncPlayerPreLoginEvent.Result.KICK_BANNED);
        event.setKickMessage(screen);
    }
}
