package com.Nextstars.ModPlugin.listener;

import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.manager.InvseeManager;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class InvseeListener implements Listener {

    private final ModPlugin plugin;

    public InvseeListener(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onClickBlock(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player viewer)) return;
        InvseeManager.Session session = plugin.getInvseeManager().get(viewer);
        if (session == null) return;

        Inventory top = event.getView().getTopInventory();
        if (top == null || session.inventory() == null || !top.equals(session.inventory())) return;

        int raw = event.getRawSlot();
        boolean topClick = raw >= 0 && raw < top.getSize();
        ClickType click = event.getClick();
        InventoryAction action = event.getAction();

        if (click == ClickType.NUMBER_KEY
                || click == ClickType.SWAP_OFFHAND
                || click == ClickType.DOUBLE_CLICK
                || click == ClickType.DROP
                || click == ClickType.CONTROL_DROP
                || action == InventoryAction.COLLECT_TO_CURSOR
                || action == InventoryAction.HOTBAR_SWAP
                || action == InventoryAction.HOTBAR_MOVE_AND_READD
                || action == InventoryAction.DROP_ALL_SLOT
                || action == InventoryAction.DROP_ONE_SLOT) {
            event.setCancelled(true);
            return;
        }

        if (!topClick) {
            if (action == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
                event.setCancelled(true);
            }
            return;
        }

        if (!session.allowEdit()) {
            event.setCancelled(true);
            return;
        }

        Set<Integer> allowed = getAllowedSlots();
        if (!allowed.contains(raw)) {
            event.setCancelled(true);
            return;
        }

        if (action == InventoryAction.MOVE_TO_OTHER_INVENTORY) {
            event.setCancelled(true);
            return;
        }

        plugin.getInvseeManager().markEditing(viewer.getUniqueId());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onClickSync(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player viewer)) return;
        InvseeManager.Session session = plugin.getInvseeManager().get(viewer);
        if (session == null || !session.allowEdit()) return;

        Inventory top = event.getView().getTopInventory();
        if (top == null || session.inventory() == null || !top.equals(session.inventory())) return;

        int raw = event.getRawSlot();
        if (raw < 0 || raw >= top.getSize()) return;

        Player target = Bukkit.getPlayer(session.target());
        if (target == null || !target.isOnline()) return;

        plugin.getInvseeManager().markEditing(viewer.getUniqueId());

        Bukkit.getScheduler().runTask(plugin, () -> {
            plugin.getInvseeManager().syncGuiToTarget(session, target);
            plugin.getInvseeManager().scheduleTargetToGui(viewer.getUniqueId(), session, target);
        });
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player viewer)) return;
        InvseeManager.Session session = plugin.getInvseeManager().get(viewer);
        if (session == null) return;

        Inventory top = event.getView().getTopInventory();
        if (top == null || session.inventory() == null || !top.equals(session.inventory())) return;

        if (!session.allowEdit()) {
            event.setCancelled(true);
            return;
        }

        Set<Integer> allowed = getAllowedSlots();
        for (int raw : event.getRawSlots()) {
            if (raw < top.getSize() && !allowed.contains(raw)) {
                event.setCancelled(true);
                return;
            }
        }

        Player target = Bukkit.getPlayer(session.target());
        if (target == null || !target.isOnline()) return;

        plugin.getInvseeManager().markEditing(viewer.getUniqueId());

        Bukkit.getScheduler().runTask(plugin, () -> {
            plugin.getInvseeManager().syncGuiToTarget(session, target);
            plugin.getInvseeManager().scheduleTargetToGui(viewer.getUniqueId(), session, target);
        });
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onClose(InventoryCloseEvent event) {
        if (!(event.getPlayer() instanceof Player viewer)) return;
        InvseeManager.Session session = plugin.getInvseeManager().get(viewer);
        if (session == null) return;

        if (!event.getInventory().equals(session.inventory())) return;

        Player target = Bukkit.getPlayer(session.target());
        if (target != null && target.isOnline() && session.allowEdit()) {
            plugin.getInvseeManager().syncGuiToTarget(session, target);
        }

        plugin.getInvseeManager().end(viewer);
    }

    @EventHandler
    public void onTargetQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        if (plugin.getInvseeManager().isBeingViewed(id)) {
            plugin.getInvseeManager().endByTarget(id);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onTargetHeld(PlayerItemHeldEvent event) {
        Player target = event.getPlayer();
        if (!plugin.getInvseeManager().isBeingViewed(target.getUniqueId())) return;
        InvseeManager.Session session = plugin.getInvseeManager().getByTarget(target.getUniqueId());
        if (session == null) return;
        Bukkit.getScheduler().runTask(plugin, () ->
                plugin.getInvseeManager().syncTargetToGui(session, target));
    }

    private Set<Integer> getAllowedSlots() {
        Set<Integer> allowed = new HashSet<>();
        for (int i = 0; i < 36; i++) allowed.add(i);
        allowed.add(plugin.getConfigManager().getInt("invsee.gui.slots.helmet",     47));
        allowed.add(plugin.getConfigManager().getInt("invsee.gui.slots.chestplate", 48));
        allowed.add(plugin.getConfigManager().getInt("invsee.gui.slots.leggings",   49));
        allowed.add(plugin.getConfigManager().getInt("invsee.gui.slots.boots",      50));
        allowed.add(plugin.getConfigManager().getInt("invsee.gui.slots.offhand",    52));
        return allowed;
    }
}
