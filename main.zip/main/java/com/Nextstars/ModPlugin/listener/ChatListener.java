package com.Nextstars.ModPlugin.listener;
import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.util.TimeParser;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.scheduler.BukkitRunnable;
import java.util.List;

public class ChatListener implements Listener {
    private final ModPlugin plugin;

    public ChatListener(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.LOWEST)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        String message = event.getMessage();
        if (plugin.getVanishManager().isVanished(player)) {
            event.setCancelled(true);
            player.sendMessage(plugin.getMessageManager().getStaff("vanish-no-chat"));
            return;
        }
        if (plugin.getMuteManager().isMuted(player)) {
            event.setCancelled(true);
            plugin.getConfigManager().playSound(player, "muted-try-chat");
            plugin.getMessageManager().sendActionBar(player, "actionbar-muted",
                    "%time_left%", plugin.getMuteManager().getTimeLeft(player.getUniqueId()),
                    "%reason%", plugin.getMuteManager().getReason(player.getUniqueId()));
            return;
        }
        if (plugin.getConfigManager().isProfanityEnabled()) {
            if (containsProfanity(message)) {
                event.setCancelled(true);
                if (plugin.getConfigManager().isProfanityAutoBan()
                        && !player.isOp()
                        && !player.hasPermission("staffplugin.bypass.autoban")) {
                    String duration = plugin.getConfigManager().getProfanityBanDuration();
                    String reason = plugin.getConfigManager().getProfanityBanReason();
                    long durationMs = TimeParser.parse(duration);
                    new BukkitRunnable() {
                        @Override public void run() {
                            plugin.getBanManager().ban(player.getUniqueId(), player.getName(), reason, durationMs, "AutoMod");
                            String screen = plugin.getMessageManager().getRaw("ban-screen",
                                    "%reason%", reason,
                                    "%duration%", TimeParser.formatDuration(durationMs),
                                    "%time_left%", TimeParser.formatDuration(durationMs));
                            player.kickPlayer(screen);
                        }
                    }.runTask(plugin);
                }
                return;
            }
        }
        if (plugin.getConfigManager().isSpamEnabled()
                && !player.hasPermission("staffplugin.bypass.antispam")
                && !player.isOp()) {
            int count = plugin.getSpamManager().registerMessage(player.getUniqueId(), message);
            int max = plugin.getConfigManager().getSpamMaxRepeats();
            if (count > 0 && count < max) {
                event.setCancelled(true);
                plugin.getConfigManager().playSound(player, "spam-warning");
                plugin.getMessageManager().sendActionBar(player, "actionbar-spam",
                        "%count%", String.valueOf(count));
                return;
            }
            if (count >= max) {
                event.setCancelled(true);
                plugin.getSpamManager().reset(player.getUniqueId());
                if (!player.hasPermission("staffplugin.bypass.automute")) {
                    String duration = plugin.getConfigManager().getSpamAutoMuteDuration();
                    String reason = plugin.getConfigManager().getSpamAutoMuteReason();
                    long durationMs = TimeParser.parse(duration);
                    new BukkitRunnable() {
                        @Override public void run() {
                            plugin.getMuteManager().mute(player, reason, durationMs);
                            plugin.getMessageManager().sendActionBar(player, "player-auto-muted");
                        }
                    }.runTask(plugin);
                }
            }
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getSpamManager().reset(event.getPlayer().getUniqueId());
        plugin.getChatInputManager().cancel(event.getPlayer().getUniqueId());
    }

    private boolean containsProfanity(String message) {
        String lower = message.toLowerCase();
        List<String> words = plugin.getBadWordManager().getBadWords();
        for (String word : words) {
            if (lower.contains(word.toLowerCase())) return true;
        }
        return false;
    }
}
