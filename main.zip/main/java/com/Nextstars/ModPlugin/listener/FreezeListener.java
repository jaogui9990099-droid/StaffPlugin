package com.Nextstars.ModPlugin.listener;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.scheduler.BukkitRunnable;
public class FreezeListener implements Listener {
    private final ModPlugin plugin;
    public FreezeListener(ModPlugin plugin) {
        this.plugin = plugin;
        startHotbarTask();
    }
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!plugin.getFreezeManager().isFrozen(player)) return;
        if (event.getFrom().getBlockX() != event.getTo().getBlockX()
                || event.getFrom().getBlockY() != event.getTo().getBlockY()
                || event.getFrom().getBlockZ() != event.getTo().getBlockZ()) {
            event.setTo(event.getFrom());
        }
    }
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (plugin.getFreezeManager().isFrozen(player)) {
            plugin.getMessageManager().sendActionBar(player, "player-now-frozen");
        }
    }
    private void startHotbarTask() {
        new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (plugin.getFreezeManager().isFrozen(player)) {
                        plugin.getMessageManager().sendActionBar(player, "actionbar-frozen");
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 20L);
    }
}
