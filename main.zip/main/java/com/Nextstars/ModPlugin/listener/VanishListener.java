package com.Nextstars.ModPlugin.listener;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.event.player.PlayerJoinEvent;
public class VanishListener implements Listener {
    private final ModPlugin plugin;
    public VanishListener(ModPlugin plugin) {
        this.plugin = plugin;
    }
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.getVanishManager().applyToNewJoiner(player);
    }
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        if (plugin.getVanishManager().isVanished(player)) {
            event.setCancelled(true);
            player.sendMessage(plugin.getMessageManager().getStaff("vanish-no-chat"));
        }
    }
}
