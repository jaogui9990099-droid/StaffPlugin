package com.Nextstars.ModPlugin.appeal;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.BanList;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.io.File;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class AutoBanManager {

    private final ModPlugin plugin;
    private final AppealManager appealManager;
    private final LastCommandTracker lastCommandTracker;

    private final Map<UUID, String> activeRecordingId = new ConcurrentHashMap<>();
    private final Map<UUID, Boolean> alreadyBanned = new ConcurrentHashMap<>();
    private final Map<UUID, LastFlagInfo> lastFlagInfo = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> pendingBanTask = new ConcurrentHashMap<>();

    public AutoBanManager(ModPlugin plugin, AppealManager appealManager, LastCommandTracker lastCommandTracker) {
        this.plugin = plugin;
        this.appealManager = appealManager;
        this.lastCommandTracker = lastCommandTracker;
    }

    public void handleFlag(Player player, String checkName, String verbose, int totalFlags) {
        if (player == null) return;
        if (!plugin.getConfig().getBoolean("auto-ban.enabled", false)) return;
        if (player.isOp()) return;
        if (player.hasPermission("modplugin.bypass.ban")) return;
        if (player.hasPermission("staffplugin.bypass.autoban")) return;
        UUID uuid = player.getUniqueId();

        lastFlagInfo.put(uuid, new LastFlagInfo(checkName, verbose, totalFlags));

        if (plugin.getBanManager() != null && !plugin.getBanManager().isBanned(uuid)) {
            alreadyBanned.remove(uuid);
        }

        int startRecAt = plugin.getConfig().getInt("auto-ban.start-recording-at-flags", 1);
        if (totalFlags >= startRecAt) {
            ensureRecordingStarted(player);
        }

        int banAt = plugin.getConfig().getInt("auto-ban.ban-at-flags", 800);
        if (totalFlags < banAt) return;
        if (alreadyBanned.putIfAbsent(uuid, true) != null) return;

        int old = pendingBanTask.getOrDefault(uuid, -1);
        if (old != -1) {
            Bukkit.getScheduler().cancelTask(old);
        }
        int taskId = Bukkit.getScheduler().runTaskLater(plugin, () -> {
            pendingBanTask.remove(uuid);
            LastFlagInfo info = lastFlagInfo.getOrDefault(uuid, new LastFlagInfo(checkName, verbose, totalFlags));
            banNow(player, info.checkName, info.verbose, info.totalFlags);
        }, 8L).getTaskId();
        pendingBanTask.put(uuid, taskId);
    }

    public void resetPlayer(UUID uuid) {
        alreadyBanned.remove(uuid);
        activeRecordingId.remove(uuid);
        lastFlagInfo.remove(uuid);
        Integer task = pendingBanTask.remove(uuid);
        if (task != null) Bukkit.getScheduler().cancelTask(task);
    }

    private void ensureRecordingStarted(Player player) {
        if (plugin.getRecordingManager() == null) return;
        UUID uuid = player.getUniqueId();
        if (activeRecordingId.containsKey(uuid)) return;
        if (!com.Nextstars.ModPlugin.util.ReplayBridge.isAvailable()) return;

        String timestamp = DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")
                .withZone(ZoneId.systemDefault())
                .format(Instant.now());
        String recordingId = player.getName().toLowerCase() + "-autoban-" + timestamp;
        int maxSeconds = plugin.getConfig().getInt("auto-ban.max-recording-seconds", 1800);
        int safeSeconds = Math.max(60, maxSeconds);
        try {
            activeRecordingId.put(uuid, recordingId);
            com.Nextstars.ModPlugin.util.ReplayBridge.record(recordingId, Bukkit.getConsoleSender(), player);
            long tickDelay = (long) (safeSeconds + 5) * 20L;
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                try {
                    if (!activeRecordingId.containsKey(uuid)) return;
                    com.Nextstars.ModPlugin.util.ReplayBridge.stop(recordingId, true);
                } catch (Exception ignored) {
                }
            }, tickDelay);
        } catch (Exception e) {
            activeRecordingId.remove(uuid);
        }
    }

    private void banNow(Player player, String checkName, String verbose, int totalFlags) {
        UUID uuid = player.getUniqueId();
        String recordingId = activeRecordingId.remove(uuid);
        stopRecording(recordingId);

        String banId = generateAppealId(player, totalFlags);
        long now = System.currentTimeMillis();
        long expires = now + 30L * 24L * 60L * 60L * 1000L;

        File replayFile = findReplayFile(recordingId);
        String storedReplayPath = appealManager.copyReplayToAppeals(replayFile, banId);

        Location loc = player.getLocation();
        String lastCmd = lastCommandTracker != null ? lastCommandTracker.getLastCommand(uuid) : "";

        AppealRecord record = new AppealRecord(
                banId,
                uuid,
                player.getName(),
                now,
                expires,
                checkName,
                verbose,
                totalFlags,
                lastCmd,
                loc,
                recordingId,
                storedReplayPath
        );
        appealManager.save(record);

        long durationMs = plugin.getConfig().getLong("auto-ban.ban-duration-ms", 0L);
        String displayReason = buildReason(checkName, verbose, totalFlags);
        String reason = displayReason;

        if (plugin.getBanManager() != null) {
            plugin.getBanManager().banWithId(player.getUniqueId(), player.getName(), reason, durationMs, "AntiCheat", banId, false);
        } else {
            Bukkit.getBanList(BanList.Type.NAME).addBan(player.getName(), reason, null, "AntiCheat");
        }

        String durationStr = com.Nextstars.ModPlugin.util.TimeParser.formatDuration(durationMs);
        String screen = plugin.getMessageManager().getRaw("ban-screen",
                "%reason%", reason,
                "%duration%", durationStr,
                "%time_left%", durationStr,
                "%ban_id%", banId,
                "%appeal_window%", "7 days",
                "%evidence_window%", "30 days"
        );
        player.kickPlayer(screen);

        if (plugin.getDiscordBotManager() != null && plugin.getDiscordBotManager().isReady()) {
            File replay = storedReplayPath.isBlank() ? null : new File(storedReplayPath);
            plugin.getDiscordBotManager().sendAntiCheatBanMessage(player.getName(), displayReason, durationStr, banId);
            plugin.getDiscordBotManager().sendAutoBanEvidence(record, replay);
        }
    }

    private record LastFlagInfo(String checkName, String verbose, int totalFlags) {}

    private void stopRecording(String recordingId) {
        if (recordingId == null || recordingId.isBlank()) return;
        try {
            com.Nextstars.ModPlugin.util.ReplayBridge.stop(recordingId, true);
        } catch (Exception ignored) {
        }
    }

    private File findReplayFile(String recordingId) {
        if (recordingId == null || recordingId.isBlank()) return null;
        List<String> folders = new ArrayList<>();
        folders.add(plugin.getConfig().getString("discord-bot.replays-folder", "plugins/Flashback/replays"));
        folders.add("plugins/Flashback/replays");
        folders.add("plugins/AdvancedReplay/replays");

        for (String folderPath : folders) {
            if (folderPath == null || folderPath.isBlank()) continue;
            File folder = new File(folderPath);
            if (!folder.exists() || !folder.isDirectory()) continue;
            File exact = new File(folder, recordingId + ".replay");
            if (exact.exists()) return exact;
            File[] files = folder.listFiles((dir, name) -> name != null && name.toLowerCase().startsWith(recordingId.toLowerCase()) && name.toLowerCase().endsWith(".replay"));
            if (files != null && files.length > 0) return files[0];
        }
        return null;
    }

    private String buildReason(String checkName, String verbose, int totalFlags) {
        String c = checkName == null ? "" : checkName;
        String v = verbose == null ? "" : verbose;
        String base = plugin.getConfig().getString("auto-ban.reason-prefix", "Cheating");
        String extra = c.isBlank() ? "" : (" (" + c + ")");
        String vv = v.isBlank() ? "" : (" - " + v);
        return base + extra + vv + " | Flags: " + totalFlags;
    }

    private String generateAppealId(Player p, int totalFlags) {
        String seed = p.getUniqueId().toString().replace("-", "") + "-" + System.currentTimeMillis() + "-" + totalFlags;
        return java.util.UUID.nameUUIDFromBytes(seed.getBytes(java.nio.charset.StandardCharsets.UTF_8))
                .toString()
                .replace("-", "")
                .substring(0, 12)
                .toUpperCase();
    }
}
