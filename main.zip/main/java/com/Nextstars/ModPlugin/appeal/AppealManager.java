package com.Nextstars.ModPlugin.appeal;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Locale;
import java.util.Optional;

public class AppealManager {

    private final ModPlugin plugin;
    private final File appealsDir;
    private final File recordsDir;
    private final File replaysDir;

    public AppealManager(ModPlugin plugin) {
        this.plugin = plugin;
        this.appealsDir = new File(plugin.getDataFolder(), "appeals");
        this.recordsDir = new File(appealsDir, "records");
        this.replaysDir = new File(appealsDir, "replays");
        if (!recordsDir.exists()) recordsDir.mkdirs();
        if (!replaysDir.exists()) replaysDir.mkdirs();
    }

    public File getReplaysDir() {
        return replaysDir;
    }

    public File getRecordFile(String id) {
        return new File(recordsDir, sanitizeId(id) + ".yml");
    }

    public void save(AppealRecord r) {
        File f = getRecordFile(r.getId());
        YamlConfiguration y = new YamlConfiguration();
        y.set("id", r.getId());
        y.set("player.uuid", r.getPlayerUuid().toString());
        y.set("player.name", r.getPlayerName());
        y.set("created_at_ms", r.getCreatedAtMs());
        y.set("expires_at_ms", r.getExpiresAtMs());
        y.set("reason.check", r.getCheckName());
        y.set("reason.verbose", r.getVerbose());
        y.set("flags.total", r.getTotalFlags());
        y.set("context.last_command", r.getLastCommand());
        y.set("location.world", r.getWorld());
        y.set("location.x", r.getX());
        y.set("location.y", r.getY());
        y.set("location.z", r.getZ());
        y.set("location.yaw", r.getYaw());
        y.set("location.pitch", r.getPitch());
        y.set("replay.recording_id", r.getRecordingId());
        y.set("replay.stored_path", r.getStoredReplayPath());
        try {
            y.save(f);
        } catch (IOException e) {
            plugin.getLogger().warning("[Appeal] Failed to save record: " + e.getMessage());
        }
    }

    public Optional<AppealRecord> load(String id) {
        File f = getRecordFile(id);
        if (!f.exists()) return Optional.empty();
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        try {
            String rid = y.getString("id", sanitizeId(id));
            java.util.UUID uuid = java.util.UUID.fromString(y.getString("player.uuid", "00000000-0000-0000-0000-000000000000"));
            String name = y.getString("player.name", "Unknown");
            long created = y.getLong("created_at_ms", 0L);
            long expires = y.getLong("expires_at_ms", 0L);
            String check = y.getString("reason.check", "");
            String verbose = y.getString("reason.verbose", "");
            int flags = y.getInt("flags.total", 0);
            String lastCmd = y.getString("context.last_command", "");
            String world = y.getString("location.world", "");
            double x = y.getDouble("location.x", 0.0);
            double yy = y.getDouble("location.y", 0.0);
            double z = y.getDouble("location.z", 0.0);
            float yaw = (float) y.getDouble("location.yaw", 0.0);
            float pitch = (float) y.getDouble("location.pitch", 0.0);
            String recId = y.getString("replay.recording_id", "");
            String stored = y.getString("replay.stored_path", "");

            org.bukkit.World w = world.isEmpty() ? null : plugin.getServer().getWorld(world);
            org.bukkit.Location loc = w != null ? new org.bukkit.Location(w, x, yy, z, yaw, pitch) : null;

            return Optional.of(new AppealRecord(rid, uuid, name, created, expires, check, verbose, flags, lastCmd, loc, recId, stored));
        } catch (Exception e) {
            return Optional.empty();
        }
    }

    public void cleanupExpired() {
        long now = System.currentTimeMillis();
        long weekMs = 7L * 24L * 60L * 60L * 1000L;

        File[] files = recordsDir.listFiles((dir, name) -> name.toLowerCase(Locale.ROOT).endsWith(".yml"));
        if (files == null) return;

        for (File f : files) {
            try {
                YamlConfiguration y = YamlConfiguration.loadConfiguration(f);

                String banId = y.getString("id", "");
                String uuidStr = y.getString("player.uuid", "");
                long created = y.getLong("created_at_ms", 0L);
                long expires = y.getLong("expires_at_ms", 0L);

                boolean purgeWeek = created > 0 && (created + weekMs) <= now;
                boolean purgeExpire = expires > 0 && expires <= now;

                if (purgeWeek || purgeExpire) {
                    String stored = y.getString("replay.stored_path", "");
                    if (stored != null && !stored.isBlank()) {
                        File rf = new File(stored);
                        if (!rf.isAbsolute()) rf = new File(plugin.getDataFolder(), stored);
                        if (rf.exists()) rf.delete();
                    }

                    if (purgeWeek && !uuidStr.isBlank() && !banId.isBlank() && plugin.getBanManager() != null) {
                        try {
                            java.util.UUID u = java.util.UUID.fromString(uuidStr);
                            plugin.getBanManager().invalidateBanIdIfMatch(u, banId);
                        } catch (Exception ignored) {
                        }
                    }

                    f.delete();
                }
            } catch (Exception ignored) {
            }
        }
    }

    public String copyReplayToAppeals(File originalReplay, String appealId) {
        if (originalReplay == null || !originalReplay.exists()) return "";
        File target = new File(replaysDir, sanitizeId(appealId) + ".replay");
        try {
            Files.copy(originalReplay.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING);
            return target.getAbsolutePath();
        } catch (Exception e) {
            plugin.getLogger().warning("[Appeal] Failed to copy replay: " + e.getMessage());
            return "";
        }
    }

    private String sanitizeId(String id) {
        if (id == null) return "";
        return id.trim().replaceAll("[^A-Za-z0-9_-]", "");
    }
}
