package com.Nextstars.ModPlugin.appeal;

import org.bukkit.Location;

import java.util.UUID;

public class AppealRecord {

    private final String id;
    private final UUID playerUuid;
    private final String playerName;
    private final long createdAtMs;
    private final long expiresAtMs;
    private final String checkName;
    private final String verbose;
    private final int totalFlags;
    private final String lastCommand;
    private final String world;
    private final double x;
    private final double y;
    private final double z;
    private final float yaw;
    private final float pitch;
    private final String recordingId;
    private final String storedReplayPath;

    public AppealRecord(
            String id,
            UUID playerUuid,
            String playerName,
            long createdAtMs,
            long expiresAtMs,
            String checkName,
            String verbose,
            int totalFlags,
            String lastCommand,
            Location loc,
            String recordingId,
            String storedReplayPath
    ) {
        this.id = id;
        this.playerUuid = playerUuid;
        this.playerName = playerName;
        this.createdAtMs = createdAtMs;
        this.expiresAtMs = expiresAtMs;
        this.checkName = checkName;
        this.verbose = verbose;
        this.totalFlags = totalFlags;
        this.lastCommand = lastCommand;
        this.world = loc != null && loc.getWorld() != null ? loc.getWorld().getName() : "";
        this.x = loc != null ? loc.getX() : 0.0;
        this.y = loc != null ? loc.getY() : 0.0;
        this.z = loc != null ? loc.getZ() : 0.0;
        this.yaw = loc != null ? loc.getYaw() : 0.0f;
        this.pitch = loc != null ? loc.getPitch() : 0.0f;
        this.recordingId = recordingId;
        this.storedReplayPath = storedReplayPath;
    }

    public String getId() { return id; }
    public UUID getPlayerUuid() { return playerUuid; }
    public String getPlayerName() { return playerName; }
    public long getCreatedAtMs() { return createdAtMs; }
    public long getExpiresAtMs() { return expiresAtMs; }
    public String getCheckName() { return checkName; }
    public String getVerbose() { return verbose; }
    public int getTotalFlags() { return totalFlags; }
    public String getLastCommand() { return lastCommand; }
    public String getWorld() { return world; }
    public double getX() { return x; }
    public double getY() { return y; }
    public double getZ() { return z; }
    public float getYaw() { return yaw; }
    public float getPitch() { return pitch; }
    public String getRecordingId() { return recordingId; }
    public String getStoredReplayPath() { return storedReplayPath; }
}
