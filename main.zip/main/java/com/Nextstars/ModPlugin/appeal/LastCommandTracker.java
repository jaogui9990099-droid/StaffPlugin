package com.Nextstars.ModPlugin.appeal;

import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public class LastCommandTracker implements Listener {

    private final Map<UUID, String> lastCommand = new ConcurrentHashMap<>();

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = false)
    public void onCmd(PlayerCommandPreprocessEvent event) {
        String msg = event.getMessage();
        if (msg == null) return;
        lastCommand.put(event.getPlayer().getUniqueId(), msg);
    }

    public String getLastCommand(UUID uuid) {
        return lastCommand.getOrDefault(uuid, "");
    }

    public void clear(UUID uuid) {
        lastCommand.remove(uuid);
    }
}
