package com.Nextstars.ModPlugin.grim;

import com.Nextstars.ModPlugin.api.FlagDetailsAPI;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.jetbrains.annotations.NotNull;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class KillFarmDetector implements Listener {

    private final FlagDetailsAPI flagApi;
    private final int killThreshold;
    private final long timeWindowMs;
    private final Map<UUID, List<KillRecord>> recentKills = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> killFarmFlags = new ConcurrentHashMap<>();

    public KillFarmDetector(@NotNull FlagDetailsAPI flagApi, int killThreshold, long timeWindowMs) {
        this.flagApi = flagApi;
        this.killThreshold = killThreshold;
        this.timeWindowMs = timeWindowMs;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player killer = event.getEntity().getKiller();
        if (killer == null) return;
        UUID killerId = killer.getUniqueId();
        UUID victimId = event.getEntity().getUniqueId();
        long now = System.currentTimeMillis();
        recentKills.computeIfAbsent(killerId, k -> new ArrayList<>()).add(new KillRecord(victimId, now));
        cleanOldKills(killerId, now);
        checkKillFarming(killerId, victimId);
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        UUID id = event.getPlayer().getUniqueId();
        recentKills.remove(id);
        killFarmFlags.remove(id);
    }

    private void cleanOldKills(UUID killerId, long now) {
        List<KillRecord> kills = recentKills.get(killerId);
        if (kills != null) kills.removeIf(k -> (now - k.timestamp) > timeWindowMs);
    }

    private void checkKillFarming(UUID killerId, UUID victimId) {
        List<KillRecord> kills = recentKills.get(killerId);
        if (kills == null) return;
        long count = kills.stream().filter(k -> k.victimId.equals(victimId)).count();
        if (count >= killThreshold) {
            killFarmFlags.merge(killerId, 1, Integer::sum);
        }
    }

    public int getKillFarmFlags(UUID playerId) {
        return killFarmFlags.getOrDefault(playerId, 0);
    }

    private static class KillRecord {
        final UUID victimId;
        final long timestamp;
        KillRecord(UUID v, long t) { victimId = v; timestamp = t; }
    }
}
