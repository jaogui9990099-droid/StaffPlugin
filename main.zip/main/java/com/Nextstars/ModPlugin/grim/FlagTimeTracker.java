package com.Nextstars.ModPlugin.grim;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
public class FlagTimeTracker {
    private static final int HOURS = 24;
    private static final int MINUTES = 60;
    private static final DateTimeFormatter HOUR_FMT = DateTimeFormatter.ofPattern("HH:00");
    private static final DateTimeFormatter LABEL_FMT = DateTimeFormatter.ofPattern("dd/MM HH:mm");
    private final ModPlugin plugin;
    private final File dataFile;
    private final int[] hourlyBuckets = new int[HOURS];
    private final int[] minuteBuckets = new int[MINUTES];
    private final Map<String, Integer> violationTotals = new ConcurrentHashMap<>();
    private final Map<UUID, AtomicInteger> playerFlagCount = new ConcurrentHashMap<>();
    private int currentHour = -1;
    private int currentMinute = -1;
    public FlagTimeTracker(ModPlugin plugin) {
        this.plugin = plugin;
        this.dataFile = new File(plugin.getDataFolder(), "flag_history.yml");
        load();
        tickClock();
    }
    private void tickClock() {
        LocalDateTime now = LocalDateTime.now();
        currentHour = now.getHour();
        currentMinute = now.getMinute();
    }
    public void recordFlag(String violation, UUID playerUuid) {
        LocalDateTime now = LocalDateTime.now();
        int hour = now.getHour();
        int minute = now.getMinute();
        if (hour != currentHour) {
            currentHour = hour;
        }
        if (minute != currentMinute) {
            currentMinute = minute;
        }
        hourlyBuckets[hour]++;
        minuteBuckets[minute]++;
        violationTotals.merge(violation, 1, Integer::sum);
        playerFlagCount.computeIfAbsent(playerUuid, u -> new AtomicInteger(0)).incrementAndGet();
        if ((hourlyBuckets[hour] % 10) == 0) {
            save();
        }
    }
    public int[] getHourlyBuckets() {
        return hourlyBuckets.clone();
    }
    public int[] getMinuteBuckets() {
        return minuteBuckets.clone();
    }
    public Map<String, Integer> getViolationTotals() {
        return new LinkedHashMap<>(violationTotals);
    }
    public Map<UUID, Integer> getPlayerFlagCounts() {
        Map<UUID, Integer> result = new LinkedHashMap<>();
        playerFlagCount.forEach((uuid, count) -> result.put(uuid, count.get()));
        return result;
    }
    public int getTotalFlagsToday() {
        int total = 0;
        for (int v : hourlyBuckets) total += v;
        return total;
    }
    public int getPeakHour() {
        int peak = 0;
        int peakHour = 0;
        for (int i = 0; i < HOURS; i++) {
            if (hourlyBuckets[i] > peak) {
                peak = hourlyBuckets[i];
                peakHour = i;
            }
        }
        return peakHour;
    }
    public int getPeakHourValue() {
        int peak = 0;
        for (int v : hourlyBuckets) if (v > peak) peak = v;
        return peak;
    }
    public void resetDaily() {
        for (int i = 0; i < HOURS; i++) hourlyBuckets[i] = 0;
        violationTotals.clear();
        playerFlagCount.clear();
        save();
    }
    private void save() {
        FileConfiguration cfg = new YamlConfiguration();
        for (int i = 0; i < HOURS; i++) {
            cfg.set("hourly." + i, hourlyBuckets[i]);
        }
        for (int i = 0; i < MINUTES; i++) {
            cfg.set("minute." + i, minuteBuckets[i]);
        }
        violationTotals.forEach((k, v) -> cfg.set("violations." + k.replace(".", "_"), v));
        cfg.set("saved-at", LABEL_FMT.format(LocalDateTime.now()));
        try {
            cfg.save(dataFile);
        } catch (IOException e) {
            plugin.getLogger().warning("Could not save flag_history.yml: " + e.getMessage());
        }
    }
    private void load() {
        if (!dataFile.exists()) return;
        FileConfiguration cfg = YamlConfiguration.loadConfiguration(dataFile);
        for (int i = 0; i < HOURS; i++) {
            hourlyBuckets[i] = cfg.getInt("hourly." + i, 0);
        }
        for (int i = 0; i < MINUTES; i++) {
            minuteBuckets[i] = cfg.getInt("minute." + i, 0);
        }
        if (cfg.isConfigurationSection("violations")) {
            for (String key : cfg.getConfigurationSection("violations").getKeys(false)) {
                violationTotals.put(key.replace("_", "."), cfg.getInt("violations." + key, 0));
            }
        }
    }
}
