package com.Nextstars.ModPlugin.grim;
import com.Nextstars.ModPlugin.util.GuiProtection;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.jetbrains.annotations.NotNull;
import com.Nextstars.ModPlugin.util.StaffInventoryHolder;
public class SusGUIListener implements Listener {
    private final SusGUI susGUI;
    public SusGUIListener(@NotNull SusGUI susGUI) {
        this.susGUI = susGUI;
    }
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (event.getInventory().getHolder() instanceof StaffInventoryHolder h && h.getId().equals("sus-gui")) {
            event.setCancelled(true);
        }
    }
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player staff)) return;
        if (!(event.getInventory().getHolder() instanceof StaffInventoryHolder h && h.getId().equals("sus-gui"))) return;
        GuiProtection.cancelAll(event);
        if (GuiProtection.isPlayerInventoryClick(event)) return;
        ItemStack item = event.getCurrentItem();
        if (item == null || item.getType() != Material.PLAYER_HEAD) return;
        SkullMeta meta = (SkullMeta) item.getItemMeta();
        if (meta == null || meta.getOwningPlayer() == null) return;
        Player target = Bukkit.getPlayer(meta.getOwningPlayer().getUniqueId());
        if (target == null || !target.isOnline()) {
            staff.sendMessage("§cThat player is no longer online.");
            staff.closeInventory();
            return;
        }
        susGUI.handleHeadClick(staff, target);
    }
}
