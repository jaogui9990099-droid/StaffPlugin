package com.Nextstars.ModPlugin.grim;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class GrimFlagListener implements Listener {

    private final ModPlugin plugin;

    public GrimFlagListener(ModPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        if (plugin.getPlayerFlagMonitor() != null) {
            plugin.getPlayerFlagMonitor().resetPlayer(event.getPlayer().getUniqueId());
        }
    }
}
