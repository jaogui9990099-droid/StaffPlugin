package com.Nextstars.ModPlugin.grim;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class PlayerFlagMonitor {

    private static final long BURST_IDLE_MS     = 4000;
    private static final long ALERT_COOLDOWN_MS = 60_000;
    private static final int  REPORTABLE_THRESHOLD = 50;

    private final ModPlugin plugin;
    private final Map<UUID, Long>    lastFlagTime  = new ConcurrentHashMap<>();
    private final Map<UUID, Long>    lastAlertTime = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> lastAlertedTotal = new ConcurrentHashMap<>();
    private org.bukkit.scheduler.BukkitTask task;

    public PlayerFlagMonitor(ModPlugin plugin) {
        this.plugin = plugin;
        startBurstChecker();
    }

    public void onFlag(UUID playerId, String flagType) {
        lastFlagTime.put(playerId, System.currentTimeMillis());
    }

    private void startBurstChecker() {
        task = Bukkit.getScheduler().runTaskTimerAsynchronously(plugin, () -> {
            long now = System.currentTimeMillis();
            FlagTracker tracker = plugin.getFlagTracker();
            if (tracker == null) return;

            for (UUID playerId : new HashSet<>(lastFlagTime.keySet())) {
                long last = lastFlagTime.getOrDefault(playerId, 0L);
                if (now - last < BURST_IDLE_MS) continue;
                lastFlagTime.remove(playerId);

                int total = tracker.getTotalFlags(playerId);
                if (total < REPORTABLE_THRESHOLD) continue;

                long lastAlert = lastAlertTime.getOrDefault(playerId, 0L);
                if (now - lastAlert < ALERT_COOLDOWN_MS) continue;

                lastAlertTime.put(playerId, now);
                Map<String, Integer> byCheck = tracker.getAllViolations(playerId);
                sendAlert(playerId, total, byCheck);

                int recordingThreshold = plugin.getConfig().getInt("discord-bot.recording-flag-threshold", 250);
                if (total >= recordingThreshold && plugin.getRecordingManager() != null) {
                    Player recordTarget = Bukkit.getPlayer(playerId);
                    String name = recordTarget != null ? recordTarget.getName() : playerId.toString().substring(0, 8);
                    if (!plugin.getRecordingManager().isRecording(playerId)) {
                        plugin.getRecordingManager().startRecordingForPlayer(playerId, name, total);
                    }
                }
            }
        }, 40L, 40L);
    }

    private void sendAlert(UUID playerId, int totalFlags, Map<String, Integer> byCheck) {
        Player player = Bukkit.getPlayer(playerId);
        String nick = player != null ? player.getName() : playerId.toString().substring(0, 8);
        double chance = Math.min(Math.min(totalFlags / 1000.0 * 60.0, 60.0) + Math.min(byCheck.size() * 8.0, 40.0), 99.0);

        if (plugin.getDiscordBotManager() != null && plugin.getDiscordBotManager().isReady()) {
            plugin.getDiscordBotManager().sendAlert(nick, totalFlags, byCheck, chance);
        }
    }

    public void resetPlayer(UUID playerId) {
        lastFlagTime.remove(playerId);
        lastAlertTime.remove(playerId);
        lastAlertedTotal.remove(playerId);
    }

    public void shutdown() {
        if (task != null) task.cancel();
    }
}
