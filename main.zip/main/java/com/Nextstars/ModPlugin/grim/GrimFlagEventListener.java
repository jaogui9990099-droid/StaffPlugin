package com.Nextstars.ModPlugin.grim;

import com.github.retrooper.packetevents.event.PacketListenerAbstract;
import com.github.retrooper.packetevents.event.PacketListenerPriority;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.event.Listener;
import org.jetbrains.annotations.NotNull;

public class GrimFlagEventListener extends PacketListenerAbstract implements Listener {

    public GrimFlagEventListener(@NotNull ModPlugin plugin) {
        super(PacketListenerPriority.MONITOR);
    }
}
