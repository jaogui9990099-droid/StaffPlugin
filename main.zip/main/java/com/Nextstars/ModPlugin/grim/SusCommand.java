package com.Nextstars.ModPlugin.grim;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
public class SusCommand implements CommandExecutor {
    private final SusGUI susGUI;
    public SusCommand(@NotNull SusGUI susGUI) {
        this.susGUI = susGUI;
    }
    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command command,
                             @NotNull String label, @NotNull String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can use this command.").color(NamedTextColor.RED));
            return true;
        }
        if (!player.hasPermission("modplugin.sus")) {
            player.sendMessage(Component.text("No permission.").color(NamedTextColor.RED));
            return true;
        }
        susGUI.openGUI(player);
        return true;
    }
}
