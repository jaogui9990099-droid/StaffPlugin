package com.Nextstars.ModPlugin.grim;

import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.util.StaffInventoryHolder;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextDecoration;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.jetbrains.annotations.NotNull;

import java.util.*;

public class SusGUI {

    private static final int GUI_SIZE = 54;
    static final String GUI_TITLE = "Suspicious Players";

    private final FlagTracker flagTracker;
    private final int flagThreshold;

    public SusGUI(@NotNull FlagTracker flagTracker, int flagThreshold) {
        this.flagTracker = flagTracker;
        this.flagThreshold = flagThreshold;
    }

    public void openGUI(@NotNull Player staff) {
        Inventory gui = Bukkit.createInventory(new StaffInventoryHolder("sus-gui"), GUI_SIZE,
                Component.text(GUI_TITLE).color(NamedTextColor.DARK_RED));

        List<UUID> suspicious = flagTracker.getSuspiciousPlayers(flagThreshold);
        suspicious.sort((a, b) -> Integer.compare(flagTracker.getTotalFlags(b), flagTracker.getTotalFlags(a)));

        int slot = 0;
        for (UUID id : suspicious) {
            if (slot >= GUI_SIZE) break;
            Player target = Bukkit.getPlayer(id);
            if (target == null || !target.isOnline()) continue;
            gui.setItem(slot++, createPlayerHead(target, id));
        }

        if (slot == 0) {
            ItemStack empty = new ItemStack(Material.LIME_STAINED_GLASS_PANE);
            org.bukkit.inventory.meta.ItemMeta meta = empty.getItemMeta();
            if (meta != null) {
                meta.displayName(Component.text("No suspicious players online")
                        .color(NamedTextColor.GREEN).decoration(TextDecoration.ITALIC, false));
                meta.lore(List.of(Component.text("No players above " + flagThreshold + " flags")
                        .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
                empty.setItemMeta(meta);
            }
            gui.setItem(22, empty);
        }

        staff.openInventory(gui);
    }

    private ItemStack createPlayerHead(@NotNull Player target, @NotNull UUID playerId) {
        int total = flagTracker.getTotalFlags(playerId);
        Map<String, Integer> violations = flagTracker.getAllViolations(playerId);

        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        if (meta == null) return skull;

        meta.setOwningPlayer(target);
        meta.displayName(Component.text(target.getName())
                .color(NamedTextColor.GOLD).decoration(TextDecoration.ITALIC, false));

        List<Component> lore = new ArrayList<>();
        lore.add(Component.text("Total flags: " + total)
                .color(NamedTextColor.RED).decoration(TextDecoration.ITALIC, false));
        lore.add(Component.empty());
        lore.add(Component.text("Violations:").color(NamedTextColor.YELLOW)
                .decoration(TextDecoration.ITALIC, false));
        violations.entrySet().stream()
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                .limit(8)
                .forEach(e -> lore.add(Component.text("  " + e.getKey() + ": " + e.getValue())
                        .color(NamedTextColor.GRAY).decoration(TextDecoration.ITALIC, false)));
        lore.add(Component.empty());
        lore.add(Component.text("Click to spectate").color(NamedTextColor.GREEN)
                .decoration(TextDecoration.ITALIC, true));

        meta.lore(lore);
        skull.setItemMeta(meta);
        return skull;
    }

    public void handleHeadClick(@NotNull Player staff, @NotNull Player target) {
        staff.closeInventory();
        staff.teleport(target.getLocation());
        staff.setGameMode(GameMode.SPECTATOR);
        staff.sendMessage(Component.text("Now spectating " + target.getName()).color(NamedTextColor.GREEN));
    }

    public static boolean isSusGUI(@NotNull Inventory inv) {
        return inv.getHolder() instanceof StaffInventoryHolder h && h.getId().equals("sus-gui");
    }
}
