package com.Nextstars.ModPlugin.grim;

import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.SkullMeta;
import com.Nextstars.ModPlugin.util.StaffInventoryHolder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class GrimMenu {

    public static final String GRIM_MENU_KEY = "grim-menu";
    public static final int SIZE = 54;

    private static final int PLAYERS_START = 0;
    private static final int PLAYERS_END = 35;
    private static final int STATS_START = 36;

    private final ModPlugin plugin;

    public GrimMenu(ModPlugin plugin) {
        this.plugin = plugin;
    }

    public String getTitle() {
        return plugin.getConfigManager().getMenuTitle(GRIM_MENU_KEY);
    }

    public void open(Player staff) {
        FlagTracker tracker = plugin.getFlagTracker();
        FlagTimeTracker timeTracker = plugin.getFlagTimeTracker();
        Inventory inv = Bukkit.createInventory(new StaffInventoryHolder(GRIM_MENU_KEY), SIZE, getTitle());

        fillNavRow(inv, timeTracker);

        if (tracker == null) {
            inv.setItem(22, buildItem(Material.BARRIER, "&c&lGrimAC not found",
                    List.of("&7GrimAC is not installed.", "&7Flag monitoring is unavailable.")));
            staff.openInventory(inv);
            return;
        }

        buildStatsRow(inv, tracker, timeTracker);

        int threshold = plugin.getConfigManager().getGrimFlagThreshold();
        List<UUID> suspicious = tracker.getSuspiciousPlayers(threshold);
        int slot = PLAYERS_START;
        for (UUID uuid : suspicious) {
            if (slot > PLAYERS_END) break;
            Player target = Bukkit.getPlayer(uuid);
            if (target == null || !target.isOnline()) continue;
            inv.setItem(slot++, buildPlayerHead(target, tracker, timeTracker));
        }

        if (slot == PLAYERS_START) {
            inv.setItem(13, buildItem(Material.LIME_STAINED_GLASS_PANE, "&a&lNo suspicious players",
                    List.of("&7No players above the flag threshold.", "&7Threshold: &e" + threshold + " flags")));
        }

        staff.openInventory(inv);
        plugin.getConfigManager().playSound(staff, "menu-open");
    }

    private void buildStatsRow(Inventory inv, FlagTracker tracker, FlagTimeTracker timeTracker) {
        int threshold = plugin.getConfigManager().getGrimFlagThreshold();
        int suspiciousCount = tracker.getSuspiciousPlayers(threshold).size();
        int totalToday = timeTracker.getTotalFlagsToday();
        int peakHour = timeTracker.getPeakHour();
        int peakValue = timeTracker.getPeakHourValue();
        Map<String, Integer> violations = timeTracker.getViolationTotals();

        List<String> summaryLore = new ArrayList<>();
        summaryLore.add(c("&7Total flags today: &e" + totalToday));
        summaryLore.add(c("&7Peak hour: &e" + String.format("%02d:00", peakHour) + " &7(" + peakValue + " flags)"));
        summaryLore.add(c("&7Players online: &e" + Bukkit.getOnlinePlayers().size()));
        summaryLore.add(c("&7Suspicious players: &c" + suspiciousCount));
        summaryLore.add(c("&7Flag threshold: &e" + threshold));
        inv.setItem(36, buildItem(Material.BOOK, "&b&lSummary", summaryLore));

        List<String> violLore = new ArrayList<>();
        if (violations.isEmpty()) {
            violLore.add(c("&7No violations recorded yet."));
        } else {
            violations.entrySet().stream()
                    .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                    .limit(8)
                    .forEach(e -> violLore.add(c("&7" + e.getKey() + ": &c" + e.getValue())));
        }
        inv.setItem(37, buildItem(Material.PAPER, "&e&lTop Violations", violLore));

        List<String> hourlyLore = new ArrayList<>();
        int[] buckets = timeTracker.getHourlyBuckets();
        int maxBucket = 1;
        for (int v : buckets) if (v > maxBucket) maxBucket = v;

        for (int h = 0; h < 24; h++) {
            int val = buckets[h];
            if (val == 0) continue;
            int bars = Math.max(1, (int) ((val / (double) maxBucket) * 8));
            String bar = "&a" + "█".repeat(bars) + "&8" + "░".repeat(8 - bars);
            hourlyLore.add(c(String.format("&7%02dh &f%s &7%d", h, bar, val)));
        }
        if (hourlyLore.isEmpty()) hourlyLore.add(c("&7No data recorded yet."));
        inv.setItem(38, buildItem(Material.CLOCK, "&d&lHourly Activity", hourlyLore));

        List<String> playerLore = new ArrayList<>();
        timeTracker.getPlayerFlagCounts().entrySet().stream()
                .sorted(Map.Entry.<UUID, Integer>comparingByValue().reversed())
                .limit(8)
                .forEach(e -> {
                    Player p = Bukkit.getPlayer(e.getKey());
                    String name = p != null ? p.getName() : e.getKey().toString().substring(0, 8);
                    playerLore.add(c("&7" + name + ": &c" + e.getValue() + " flags"));
                });
        if (playerLore.isEmpty()) playerLore.add(c("&7No data yet."));
        inv.setItem(39, buildItem(Material.NETHER_STAR, "&c&lMost Flagged", playerLore));

        inv.setItem(40, buildItem(Material.FILLED_MAP, "&5&lSend Discord Report",
                List.of(c("&7Generates and sends the flag chart"), c("&7to your Discord webhook."),
                        c("&8» &eClick to send."))));

        inv.setItem(41, buildItem(Material.BUCKET, "&4&lReset Daily Data",
                List.of(c("&7Clears all flag counts for today."), c("&8» &cShift Left-Click to confirm."))));
    }

    private void fillNavRow(Inventory inv, FlagTimeTracker timeTracker) {
        Material border = plugin.getConfigManager().getBorderMaterial(GRIM_MENU_KEY);
        ItemStack pane = new ItemStack(border);
        ItemMeta m = pane.getItemMeta();
        m.setDisplayName(" ");
        pane.setItemMeta(m);
        for (int i = 45; i < 54; i++) inv.setItem(i, pane.clone());

        inv.setItem(45, buildItem(Material.ARROW, "&7&l« Back to Staff Menu", List.of(c("&7Click to return."))));
        inv.setItem(49, buildItem(Material.EMERALD, "&a&lRefresh", List.of(c("&7Reload the flag data."))));
        inv.setItem(53, buildItem(Material.COMPASS, "&b&lGrimAC Status", buildStatusLore(timeTracker)));
    }

    private List<String> buildStatusLore(FlagTimeTracker timeTracker) {
        List<String> lore = new ArrayList<>();
        boolean available = plugin.getFlagTracker() != null;
        lore.add(c("&7GrimAC: " + (available ? "&aConnected" : "&cNot found")));
        if (available) {
            lore.add(c("&7Flags today: &e" + timeTracker.getTotalFlagsToday()));
            lore.add(c("&7Threshold: &e" + plugin.getConfigManager().getGrimFlagThreshold()));
        }
        return lore;
    }

    private ItemStack buildPlayerHead(Player target, FlagTracker tracker, FlagTimeTracker timeTracker) {
        UUID uuid = target.getUniqueId();
        int totalFlags = tracker.getTotalFlags(uuid);
        String topViolation = tracker.getMostCommonViolation(uuid);
        int killFarmFlags = plugin.getKillFarmDetector() != null
                ? plugin.getKillFarmDetector().getKillFarmFlags(uuid) : 0;

        ItemStack skull = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) skull.getItemMeta();
        meta.setOwningPlayer(target);

        String flagColor = totalFlags >= 500 ? "&4&l" : totalFlags >= 350 ? "&c" : "&e";
        meta.setDisplayName(c("&f&l" + target.getName()));

        List<String> lore = new ArrayList<>();
        lore.add(c("&8&m                    "));
        lore.add(c("&7Grim Flags: " + flagColor + totalFlags));
        lore.add(c("&7Top Violation: &c" + topViolation));
        if (killFarmFlags > 0) lore.add(c("&7Kill Farm: &c" + killFarmFlags));
        lore.add(c("&7Ping: &e" + target.getPing() + "ms"));
        lore.add(c("&7Gamemode: &e" + target.getGameMode().name()));
        lore.add(c("&8&m                    "));

        Map<String, Integer> allViolations = tracker.getAllViolations(uuid);
        if (!allViolations.isEmpty()) {
            lore.add(c("&7All violations:"));
            allViolations.entrySet().stream()
                    .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
                    .limit(5)
                    .forEach(e -> lore.add(c("  &8- &7" + e.getKey() + ": &c" + e.getValue())));
        }

        lore.add(c("&8&m                    "));
        lore.add(c("&e&l[Left Click] &7Spectate"));
        lore.add(c("&c&l[Right Click] &7Warn player"));
        lore.add(c("&4&l[Shift Left Click] &7Ban player"));
        lore.add(c("&6&l[Shift Right Click] &7Clear flags"));
        meta.setLore(lore);
        skull.setItemMeta(meta);
        return skull;
    }

    private ItemStack buildItem(Material mat, String name, List<String> loreLines) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(c(name));
        List<String> lore = new ArrayList<>();
        for (String line : loreLines) lore.add(c(line));
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    public static void handleSpectate(Player staff, Player target) {
        staff.closeInventory();
        staff.teleport(target.getLocation());
        staff.setGameMode(GameMode.SPECTATOR);
    }

    private String c(String s) {
        return ChatColor.translateAlternateColorCodes('&', s);
    }
}
