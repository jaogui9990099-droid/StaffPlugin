package com.Nextstars.ModPlugin.grim;

import com.Nextstars.ModPlugin.api.FlagDetailsAPIImpl;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

public class FlagTracker {

    private final FlagDetailsAPIImpl api;

    public FlagTracker(FlagDetailsAPIImpl api) {
        this.api = api;
    }

    public int getTotalFlags(UUID playerId) {
        return api.getTotalFlags(playerId);
    }

    public String getMostCommonViolation(UUID playerId) {
        return api.getMostCommonViolation(playerId);
    }

    public Map<String, Integer> getAllViolations(UUID playerId) {
        return api.getFlagsByCheck(playerId);
    }

    public List<UUID> getSuspiciousPlayers(int threshold) {
        return api.getTrackedPlayers().stream()
                .filter(uuid -> api.getTotalFlags(uuid) >= threshold)
                .collect(Collectors.toList());
    }

    public void addManualFlag(UUID playerId, String flagType) {
    }

    public void removePlayer(UUID playerId) {
        api.removePlayer(playerId);
    }

    public void clear() {
        api.clear();
    }
}
