package com.Nextstars.ModPlugin.grim;
import com.Nextstars.ModPlugin.ModPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
public class DiscordWebhook {
    private static final String WEBHOOK_URL =
        "https://discordapp.com/api/webhooks/1473297726115680330/1A9gLG1y7cwbYMPz1fbCFtXNR5J-ZhRe2j4n5v-J0vFfXAimXxD32Kg52jMJC9XtgK5E";
    private static final DateTimeFormatter TIME_FMT = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private static final String BOUNDARY = "----ModPluginBoundary7MA4YWxkTrZu0gW";
    private final ModPlugin plugin;
    private long lastSentTime = 0;
    public DiscordWebhook(ModPlugin plugin) {
        this.plugin = plugin;
    }
    public void sendFlagReport(String requestedBy) {
        long cooldownMs = plugin.getConfigManager().getDiscordReportCooldownMs();
        long now = System.currentTimeMillis();
        if (now - lastSentTime < cooldownMs) {
            Player p = Bukkit.getPlayerExact(requestedBy);
            if (p != null) {
                long secsLeft = (cooldownMs - (now - lastSentTime)) / 1000;
                p.sendMessage(plugin.getMessageManager().getStaff("discord-cooldown",
                        "%seconds%", String.valueOf(secsLeft)));
            }
            return;
        }
        lastSentTime = now;
        Player sender = Bukkit.getPlayerExact(requestedBy);
        if (sender != null) sender.sendMessage(plugin.getMessageManager().getStaff("discord-report-generating"));
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                FlagTimeTracker tracker = plugin.getFlagTimeTracker();
                int[] hourly = tracker.getHourlyBuckets();
                Map<String, Integer> violations = tracker.getViolationTotals();
                Map<UUID, Integer> playerFlags = tracker.getPlayerFlagCounts();
                int total = tracker.getTotalFlagsToday();
                int peakHour = tracker.getPeakHour();
                int peakValue = tracker.getPeakHourValue();
                int online = Bukkit.getOnlinePlayers().size();
                byte[] imageBytes = buildChartImage(hourly, violations, total, peakHour, peakValue, online, requestedBy, playerFlags);
                String caption = buildCaption(requestedBy, total, peakHour, peakValue, online);
                sendMultipart(imageBytes, caption);
                Bukkit.getScheduler().runTask(plugin, () -> {
                    Player p = Bukkit.getPlayerExact(requestedBy);
                    if (p != null) p.sendMessage(plugin.getMessageManager().getStaff("discord-report-sent"));
                });
            } catch (Exception e) {
                plugin.getLogger().severe("[ModPlugin] Discord webhook error: " + e.getMessage());
                e.printStackTrace();
                Bukkit.getScheduler().runTask(plugin, () -> {
                    Player p = Bukkit.getPlayerExact(requestedBy);
                    if (p != null) p.sendMessage(plugin.getMessageManager().getStaff("discord-report-error"));
                });
            }
        });
    }
    private byte[] buildChartImage(int[] hourly, Map<String, Integer> violations,
                                    int total, int peakHour, int peakValue,
                                    int online, String requestedBy,
                                    Map<UUID, Integer> playerFlags) throws Exception {
        final int W      = 920;
        final int H      = 500;
        final int PAD_L  = 62;
        final int PAD_R  = 220;
        final int PAD_T  = 65;
        final int PAD_B  = 55;
        final int CW     = W - PAD_L - PAD_R;
        final int CH     = H - PAD_T - PAD_B;
        final int PANEL_X = W - PAD_R + 10;
        final int PANEL_W = PAD_R - 18;
        Color BG       = new Color(0x1a1a2e);
        Color SURFACE  = new Color(0x16213e);
        Color PANEL    = new Color(0x0f3460);
        Color GRID     = new Color(0x2a2a4a);
        Color ACCENT   = new Color(0x4f8ef7);
        Color PEAK_CLR = new Color(0xff6b6b);
        Color CUR_CLR  = new Color(0x50fa7b);
        Color TEXT_H   = new Color(0xf8f8f2);
        Color TEXT_DIM = new Color(0x8888aa);
        Color TEXT_MID = new Color(0xbbbbcc);
        BufferedImage img = new BufferedImage(W, H, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = img.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,      RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_RENDERING,         RenderingHints.VALUE_RENDER_QUALITY);
        g.setColor(BG);     g.fillRect(0, 0, W, H);
        g.setColor(SURFACE); g.fillRoundRect(8, 8, W - 16, H - 16, 18, 18);
        Font fTitle = new Font("SansSerif", Font.BOLD,  15);
        Font fSub   = new Font("SansSerif", Font.PLAIN, 10);
        Font fLabel = new Font("SansSerif", Font.PLAIN, 10);
        Font fSmall = new Font("SansSerif", Font.PLAIN,  9);
        Font fSect  = new Font("SansSerif", Font.BOLD,  10);
        g.setFont(fTitle); g.setColor(TEXT_H);
        g.drawString("GrimAC Flag Activity  \u2014  Last 24 Hours", PAD_L, 34);
        g.setFont(fSub);   g.setColor(TEXT_DIM);
        g.drawString("Requested by " + requestedBy + "   \u2022   " + TIME_FMT.format(LocalDateTime.now()), PAD_L, 50);
        int maxVal = 1;
        for (int v : hourly) if (v > maxVal) maxVal = v;
        final int barW = Math.max(1, CW / 24);
        int gridLines = 5;
        g.setFont(fLabel);
        FontMetrics fmLabel = g.getFontMetrics();
        for (int i = 0; i <= gridLines; i++) {
            int yg = PAD_T + CH - CH * i / gridLines;
            g.setColor(GRID);
            g.setStroke(new BasicStroke(1f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 0, new float[]{3, 3}, 0));
            g.drawLine(PAD_L, yg, PAD_L + CW, yg);
            int lv = maxVal * i / gridLines;
            g.setColor(TEXT_DIM);
            String ls = String.valueOf(lv);
            g.setStroke(new BasicStroke(1f));
            g.drawString(ls, PAD_L - 6 - fmLabel.stringWidth(ls), yg + 4);
        }
        g.setStroke(new BasicStroke(1f));
        g.setColor(GRID);
        g.drawRect(PAD_L, PAD_T, CW, CH);
        int curHour = LocalDateTime.now().getHour();
        for (int h = 0; h < 24; h++) {
            int bh = (int) ((double) hourly[h] / maxVal * CH);
            if (bh <= 0) continue;
            int bx = PAD_L + h * barW;
            int by = PAD_T + CH - bh;
            Color top = (h == peakHour && peakValue > 0) ? PEAK_CLR : (h == curHour) ? CUR_CLR : ACCENT;
            Color bot = new Color(top.getRed(), top.getGreen(), top.getBlue(), 40);
            g.setPaint(new GradientPaint(bx, by, top, bx, PAD_T + CH, bot));
            g.fillRect(bx + 1, by, Math.max(1, barW - 2), bh);
            g.setColor(top.darker());
            g.setStroke(new BasicStroke(1f));
            g.drawRect(bx + 1, by, Math.max(1, barW - 2), bh);
        }
        g.setFont(fLabel); g.setColor(TEXT_DIM);
        fmLabel = g.getFontMetrics();
        for (int h = 0; h < 24; h += 4) {
            String lbl = String.format("%02dh", h);
            int lx = PAD_L + h * barW + barW / 2 - fmLabel.stringWidth(lbl) / 2;
            g.drawString(lbl, lx, PAD_T + CH + 14);
        }
        g.setFont(fSub); g.setColor(TEXT_DIM);
        String xLabel = "Hour of day";
        g.drawString(xLabel, PAD_L + CW / 2 - g.getFontMetrics().stringWidth(xLabel) / 2, PAD_T + CH + 28);
        g.setColor(PANEL);
        g.fillRoundRect(PANEL_X - 4, PAD_T - 10, PANEL_W, CH + 20, 10, 10);
        int py = PAD_T;
        g.setFont(fSect); g.setColor(TEXT_H);
        g.drawString("SUMMARY", PANEL_X, py + 6); py += 12;
        g.setColor(ACCENT);
        g.drawLine(PANEL_X, py, PANEL_X + PANEL_W - 8, py); py += 13;
        g.setFont(fLabel);
        g.setColor(TEXT_MID); g.drawString("Total flags:   " + total, PANEL_X, py);                          py += 14;
        g.setColor(TEXT_MID); g.drawString("Peak hour:    " + String.format("%02d:00", peakHour) + " (" + peakValue + ")", PANEL_X, py); py += 14;
        g.setColor(TEXT_MID); g.drawString("Players online: " + online, PANEL_X, py);                        py += 22;
        g.setFont(fSect); g.setColor(TEXT_H);
        g.drawString("TOP VIOLATIONS", PANEL_X, py); py += 10;
        g.setColor(PEAK_CLR);
        g.drawLine(PANEL_X, py, PANEL_X + PANEL_W - 8, py); py += 13;
        List<Map.Entry<String, Integer>> sortedV = new ArrayList<>(violations.entrySet());
        sortedV.sort(Map.Entry.<String, Integer>comparingByValue().reversed());
        g.setFont(fSmall);
        FontMetrics fmSmall = g.getFontMetrics();
        int maxEntries = Math.min(sortedV.size(), 7);
        for (int vi = 0; vi < maxEntries; vi++) {
            Map.Entry<String, Integer> e = sortedV.get(vi);
            String vn = e.getKey();
            int maxNameW = PANEL_W - 30 - fmSmall.stringWidth((vi + 1) + ". ");
            while (vn.length() > 2 && fmSmall.stringWidth(vn) > maxNameW)
                vn = vn.substring(0, vn.length() - 1);
            if (!vn.equals(e.getKey())) vn += "\u2026";
            g.setColor(vi == 0 ? PEAK_CLR : TEXT_MID);
            g.drawString((vi + 1) + ". " + vn, PANEL_X, py);
            String cnt = String.valueOf(e.getValue());
            g.setColor(TEXT_DIM);
            g.drawString(cnt, PANEL_X + PANEL_W - 10 - fmSmall.stringWidth(cnt), py);
            py += 14;
        }
        py += 8;
        if (!playerFlags.isEmpty() && py + 50 < PAD_T + CH) {
            g.setFont(fSect); g.setColor(TEXT_H);
            g.drawString("MOST FLAGGED", PANEL_X, py); py += 10;
            g.setColor(CUR_CLR);
            g.drawLine(PANEL_X, py, PANEL_X + PANEL_W - 8, py); py += 13;
            List<Map.Entry<UUID, Integer>> sortedP = new ArrayList<>(playerFlags.entrySet());
            sortedP.sort(Map.Entry.<UUID, Integer>comparingByValue().reversed());
            g.setFont(fSmall); fmSmall = g.getFontMetrics();
            int maxP = Math.min(sortedP.size(), 5);
            for (int pi = 0; pi < maxP; pi++) {
                if (py + 14 > PAD_T + CH + 10) break;
                Map.Entry<UUID, Integer> e = sortedP.get(pi);
                Player pl = Bukkit.getPlayer(e.getKey());
                String nm = pl != null ? pl.getName()
                        : e.getKey().toString().substring(0, 8) + "\u2026";
                int maxNameW = PANEL_W - 30 - fmSmall.stringWidth((pi + 1) + ". ");
                while (nm.length() > 2 && fmSmall.stringWidth(nm) > maxNameW)
                    nm = nm.substring(0, nm.length() - 1);
                g.setColor(pi == 0 ? CUR_CLR : TEXT_MID);
                g.drawString((pi + 1) + ". " + nm, PANEL_X, py);
                String cnt = String.valueOf(e.getValue());
                g.setColor(TEXT_DIM);
                g.drawString(cnt, PANEL_X + PANEL_W - 10 - fmSmall.stringWidth(cnt), py);
                py += 14;
            }
        }
        g.setFont(fSub); g.setColor(TEXT_DIM);
        g.drawString("ModPlugin \u2022 GrimAC Integration", PAD_L, H - 12);
        g.dispose();
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        ImageIO.write(img, "png", baos);
        return baos.toByteArray();
    }
    private String buildCaption(String requestedBy, int total, int peakHour, int peakValue, int online) {
        return "\uD83D\uDCCA **GrimAC Flag Report**  \u2022  Requested by **" + requestedBy + "**\n"
             + "\uD83D\uDD10 `" + TIME_FMT.format(LocalDateTime.now()) + "`\n"
             + "\uD83D\uDEA9 Total flags today: **" + total + "**"
             + "  |  \uD83D\uDCC8 Peak: **" + String.format("%02d:00", peakHour) + "** (" + peakValue + " flags)"
             + "  |  \uD83D\uDC65 Online: **" + online + "**";
    }
    private void sendMultipart(byte[] imageBytes, String content) throws Exception {
        URL url = new URL(WEBHOOK_URL);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + BOUNDARY);
        conn.setRequestProperty("User-Agent", "ModPlugin/1.0");
        conn.setDoOutput(true);
        conn.setConnectTimeout(8000);
        conn.setReadTimeout(8000);
        try (OutputStream out = conn.getOutputStream()) {
            writePart(out, "content", content.getBytes(StandardCharsets.UTF_8), null, null);
            writePart(out, "file",    imageBytes, "grimac_flags.png", "image/png");
            out.write(("--" + BOUNDARY + "--\r\n").getBytes(StandardCharsets.UTF_8));
        }
        int code = conn.getResponseCode();
        conn.disconnect();
        if (code < 200 || code >= 300) throw new RuntimeException("Webhook returned HTTP " + code);
    }
    private void writePart(OutputStream out, String name, byte[] data,
                            String filename, String ct) throws Exception {
        StringBuilder hdr = new StringBuilder();
        hdr.append("--").append(BOUNDARY).append("\r\n");
        hdr.append("Content-Disposition: form-data; name=\"").append(name).append("\"");
        if (filename != null) hdr.append("; filename=\"").append(filename).append("\"");
        hdr.append("\r\n");
        if (ct != null) hdr.append("Content-Type: ").append(ct).append("\r\n");
        hdr.append("\r\n");
        out.write(hdr.toString().getBytes(StandardCharsets.UTF_8));
        out.write(data);
        out.write("\r\n".getBytes(StandardCharsets.UTF_8));
    }
}
