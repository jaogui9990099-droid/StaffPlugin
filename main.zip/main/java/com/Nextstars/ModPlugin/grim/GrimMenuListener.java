package com.Nextstars.ModPlugin.grim;

import com.Nextstars.ModPlugin.ModPlugin;
import com.Nextstars.ModPlugin.menu.StaffMenu;
import com.Nextstars.ModPlugin.util.GuiProtection;
import com.Nextstars.ModPlugin.util.StaffInventoryHolder;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

public class GrimMenuListener implements Listener {

    private final ModPlugin plugin;

    public GrimMenuListener(ModPlugin plugin) {
        this.plugin = plugin;
    }

    private boolean isGrimMenu(Object holder) {
        return holder instanceof StaffInventoryHolder h && h.getId().equals(GrimMenu.GRIM_MENU_KEY);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryDrag(InventoryDragEvent event) {
        if (!(event.getWhoClicked() instanceof Player)) return;
        if (!isGrimMenu(event.getInventory().getHolder())) return;
        event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onInventoryClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player staff)) return;
        if (!isGrimMenu(event.getInventory().getHolder())) return;

        GuiProtection.cancelAll(event);
        if (GuiProtection.isPlayerInventoryClick(event)) return;

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType() == Material.AIR) return;

        int slot = event.getSlot();
        ClickType click = event.getClick();

        if (slot == 45) {
            new StaffMenu(plugin).open(staff);
            return;
        }
        if (slot == 49) {
            new GrimMenu(plugin).open(staff);
            return;
        }
        if (slot == 53) return;

        if (slot == 40) {
            plugin.getDiscordWebhook().sendFlagReport(staff.getName());
            return;
        }
        if (slot == 41 && click == ClickType.SHIFT_LEFT) {
            plugin.getFlagTimeTracker().resetDaily();
            staff.sendMessage(plugin.getMessageManager().getStaff("grim-data-reset"));
            new GrimMenu(plugin).open(staff);
            return;
        }
        if (slot >= 36 && slot <= 44) return;
        if (slot >= 45) return;

        if (clicked.getType() != Material.PLAYER_HEAD) return;
        SkullMeta meta = (SkullMeta) clicked.getItemMeta();
        if (meta == null || meta.getOwningPlayer() == null) return;

        Player target = Bukkit.getPlayer(meta.getOwningPlayer().getUniqueId());
        if (target == null || !target.isOnline()) {
            staff.sendMessage(plugin.getMessageManager().getStaff("player-not-found"));
            new GrimMenu(plugin).open(staff);
            return;
        }

        if (click == ClickType.LEFT) {
            GrimMenu.handleSpectate(staff, target);
            staff.sendMessage(plugin.getMessageManager().getStaff("grim-spectating", "%player%", target.getName()));
            plugin.getConfigManager().playSound(staff, "teleport");
            return;
        }

        if (click == ClickType.RIGHT) {
            staff.closeInventory();
            plugin.getChatInputManager().requestReason(staff, reason -> {
                plugin.getWarnManager().addWarn(target.getUniqueId(), reason);
                int warns = plugin.getWarnManager().getWarnCount(target.getUniqueId());
                int max = plugin.getConfigManager().getMaxWarns();
                staff.sendMessage(plugin.getMessageManager().getStaff("warned-player",
                        "%player%", target.getName(),
                        "%warns%", String.valueOf(warns),
                        "%max%", String.valueOf(max)));
                plugin.getConfigManager().playSound(staff, "warn");
            });
            return;
        }

        if (click == ClickType.SHIFT_LEFT) {
            staff.closeInventory();
            plugin.getChatInputManager().requestTimedReason(staff, input -> {
                String[] parts = input.split(" ", 2);
                long durationMs = com.Nextstars.ModPlugin.util.TimeParser.parse(parts[0]);
                String reason = parts.length > 1 ? parts[1] : "No reason";
                if (durationMs == 0) {
                    reason = input;
                    durationMs = -1;
                }
                final long fd = durationMs;
                final String fr = reason;
                plugin.getBanManager().ban(target.getUniqueId(), target.getName(), fr, fd, staff.getName());
                String screen = plugin.getMessageManager().getRaw("ban-screen",
                        "%reason%", fr,
                        "%duration%", com.Nextstars.ModPlugin.util.TimeParser.formatDuration(fd));
                if (target.isOnline()) target.kickPlayer(screen);
                staff.sendMessage(plugin.getMessageManager().getStaff("banned-player",
                        "%player%", target.getName(),
                        "%duration%", com.Nextstars.ModPlugin.util.TimeParser.formatDuration(fd),
                        "%reason%", fr));
                plugin.getConfigManager().playSound(staff, "ban");
            });
            return;
        }

        if (click == ClickType.SHIFT_RIGHT) {
            if (plugin.getFlagTracker() != null) plugin.getFlagTracker().removePlayer(target.getUniqueId());
            if (plugin.getPlayerFlagMonitor() != null) plugin.getPlayerFlagMonitor().resetPlayer(target.getUniqueId());
            staff.sendMessage(plugin.getMessageManager().getStaff("grim-flags-cleared", "%player%", target.getName()));
            plugin.getConfigManager().playSound(staff, "clear");
            new GrimMenu(plugin).open(staff);
        }
    }
}
