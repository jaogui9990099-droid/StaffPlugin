package com.Nextstars.ModPlugin;

import com.github.retrooper.packetevents.PacketEvents;
import com.Nextstars.ModPlugin.api.FlagDetailsAPI;
import com.Nextstars.ModPlugin.discord.DiscordBotManager;
import com.Nextstars.ModPlugin.discord.RecordingManager;
import com.Nextstars.ModPlugin.api.FlagDetailsAPIImpl;
import com.Nextstars.ModPlugin.appeal.AppealManager;
import com.Nextstars.ModPlugin.appeal.AutoBanManager;
import com.Nextstars.ModPlugin.appeal.LastCommandTracker;
import com.Nextstars.ModPlugin.command.StaffCommand;
import com.Nextstars.ModPlugin.grim.*;
import com.Nextstars.ModPlugin.listener.BanListener;
import com.Nextstars.ModPlugin.listener.ChatListener;
import com.Nextstars.ModPlugin.listener.FreezeListener;
import com.Nextstars.ModPlugin.listener.InvseeListener;
import com.Nextstars.ModPlugin.listener.VanishListener;
import com.Nextstars.ModPlugin.manager.*;
import com.Nextstars.ModPlugin.menu.MenuListener;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.HandlerList;
import org.bukkit.plugin.ServicePriority;
import org.bukkit.plugin.java.JavaPlugin;

public class ModPlugin extends JavaPlugin {

    private static ModPlugin instance;

    private ConfigManager configManager;
    private MessageManager messageManager;
    private FreezeManager freezeManager;
    private MuteManager muteManager;
    private VanishManager vanishManager;
    private WarnManager warnManager;
    private BanManager banManager;
    private SpamManager spamManager;
    private BadWordManager badWordManager;
    private ChatInputManager chatInputManager;
    private MuteReasonManager muteReasonManager;
    private ReasonManager reasonManager;
    private FlyManager flyManager;
    private InvseeManager invseeManager;
    private FlagTimeTracker flagTimeTracker;
    private PlayerFlagMonitor playerFlagMonitor;
    private DiscordWebhook discordWebhook;

    private DiscordBotManager discordBotManager;
    private RecordingManager recordingManager;

    private AppealManager appealManager;
    private LastCommandTracker lastCommandTracker;
    private AutoBanManager autoBanManager;

    private FlagDetailsAPIImpl flagApi;
    private FlagTracker flagTracker;
    private KillFarmDetector killFarmDetector;
    private SusGUI susGUI;
    private GrimFlagEventListener grimFlagEventListener;

    private SusGUIListener susGUIListener;
    private GrimMenuListener grimMenuListener;

    @Override
    public void onEnable() {
        instance = this;

        configManager     = new ConfigManager(this);
        messageManager    = new MessageManager(this);
        freezeManager     = new FreezeManager(this);
        muteManager       = new MuteManager(this);
        vanishManager     = new VanishManager(this);
        warnManager       = new WarnManager(this);
        banManager        = new BanManager(this);
        spamManager       = new SpamManager();
        badWordManager    = new BadWordManager(this);
        chatInputManager  = new ChatInputManager(this);
        muteReasonManager = new MuteReasonManager(this);
        reasonManager     = new ReasonManager(this);
        flyManager        = new FlyManager();
        invseeManager     = new InvseeManager(this);
        flagTimeTracker   = new FlagTimeTracker(this);
        discordWebhook    = new DiscordWebhook(this);

        appealManager = new AppealManager(this);
        appealManager.cleanupExpired();
        Bukkit.getScheduler().runTaskTimerAsynchronously(this, appealManager::cleanupExpired, 20L * 60L, 20L * 60L * 60L);
        lastCommandTracker = new LastCommandTracker();
        autoBanManager = new AutoBanManager(this, appealManager, lastCommandTracker);

        discordBotManager = new DiscordBotManager(this);
        discordBotManager.start();

        boolean grimPresent = Bukkit.getPluginManager().isPluginEnabled("GrimAC");
        if (grimPresent) {
            recordingManager  = new RecordingManager(this);
            playerFlagMonitor = new PlayerFlagMonitor(this);
            flagApi           = new FlagDetailsAPIImpl(this);
            flagTracker       = new FlagTracker(flagApi);
            killFarmDetector  = new KillFarmDetector(flagApi,
                    configManager.getGrimKillFarmThreshold(),
                    configManager.getGrimKillFarmTimeWindowMs());
            susGUI = new SusGUI(flagTracker, configManager.getGrimFlagThreshold());

            getServer().getServicesManager().register(
                    FlagDetailsAPI.class, flagApi, this, ServicePriority.Normal);

            grimFlagEventListener = new GrimFlagEventListener(this);
            PacketEvents.getAPI().getEventManager().registerListener(grimFlagEventListener);
            getServer().getPluginManager().registerEvents(grimFlagEventListener, this);
            getServer().getPluginManager().registerEvents(flagApi, this);
            getServer().getPluginManager().registerEvents(killFarmDetector, this);
            susGUIListener = new SusGUIListener(susGUI);
            grimMenuListener = new GrimMenuListener(this);
            getServer().getPluginManager().registerEvents(susGUIListener, this);
            getServer().getPluginManager().registerEvents(grimMenuListener, this);

            PluginCommand susCmd = getCommand("sus");
            if (susCmd != null) susCmd.setExecutor(new SusCommand(susGUI));

            getLogger().info("[ModPlugin] GrimAC detected — flag monitoring enabled.");
        } else {
            getLogger().warning("[ModPlugin] GrimAC not found — flag monitoring disabled.");
        }

        StaffCommand staffCommand = new StaffCommand(this);
        PluginCommand cmd = getCommand("staff");
        cmd.setExecutor(staffCommand);
        cmd.setTabCompleter(staffCommand);

        registerCommand("ban", new com.Nextstars.ModPlugin.command.BanCommand(this));
        registerCommand("unban", new com.Nextstars.ModPlugin.command.UnbanCommand(this));
        registerCommand("baninfo", new com.Nextstars.ModPlugin.command.BanInfoCommand(this));
        registerCommand("warn", new com.Nextstars.ModPlugin.command.WarnCommand(this));
        registerCommand("kick", new com.Nextstars.ModPlugin.command.KickCommand(this));
        registerCommand("freeze", new com.Nextstars.ModPlugin.command.FreezeCommand(this));
        registerCommand("mute", new com.Nextstars.ModPlugin.command.MuteCommand(this));
        registerCommand("unmute", new com.Nextstars.ModPlugin.command.UnmuteCommand(this));
        registerCommand("tp", new com.Nextstars.ModPlugin.command.TeleportCommand(this));
        registerCommand("vanish", new com.Nextstars.ModPlugin.command.VanishCommand(this));
        registerCommand("clear", new com.Nextstars.ModPlugin.command.ClearCommand(this));
        registerCommand("fly", new com.Nextstars.ModPlugin.command.FlyCommand(this));
        registerCommand("invsee", new com.Nextstars.ModPlugin.command.InvseeCommand(this));
        registerCommand("systemout", new com.Nextstars.ModPlugin.command.SystemOutCommand(this));

        getServer().getPluginManager().registerEvents(new MenuListener(this), this);
        getServer().getPluginManager().registerEvents(new FreezeListener(this), this);
        getServer().getPluginManager().registerEvents(new ChatListener(this), this);
        getServer().getPluginManager().registerEvents(new VanishListener(this), this);
        getServer().getPluginManager().registerEvents(new BanListener(this), this);
        getServer().getPluginManager().registerEvents(new InvseeListener(this), this);
        getServer().getPluginManager().registerEvents(lastCommandTracker, this);
        getServer().getPluginManager().registerEvents(chatInputManager, this);
    }

    private void registerCommand(String name, org.bukkit.command.CommandExecutor executor) {
        PluginCommand c = getCommand(name);
        if (c != null) {
            c.setExecutor(executor);
            if (executor instanceof org.bukkit.command.TabCompleter t) c.setTabCompleter(t);
        }
    }

    @Override
    public void onDisable() {
        if (grimFlagEventListener != null)
            PacketEvents.getAPI().getEventManager().unregisterListener(grimFlagEventListener);
        if (killFarmDetector != null) HandlerList.unregisterAll(killFarmDetector);
        if (susGUIListener != null) HandlerList.unregisterAll(susGUIListener);
        if (grimMenuListener != null) HandlerList.unregisterAll(grimMenuListener);
        if (flagApi != null) {
            getServer().getServicesManager().unregister(FlagDetailsAPI.class, flagApi);
            flagApi.clear();
        }
        if (playerFlagMonitor != null) playerFlagMonitor.shutdown();
        if (discordBotManager != null) discordBotManager.shutdown();
        instance = null;
    }

    public void reload() {
        configManager.load();
        messageManager.reload();
        badWordManager.load();
        muteReasonManager.reload();
        reasonManager.reload();

        if (discordBotManager != null) {
            try {
                discordBotManager.shutdown();
            } catch (Exception ignored) {
            }
            discordBotManager = new DiscordBotManager(this);
            discordBotManager.start();
        }

        boolean grimPresent = Bukkit.getPluginManager().isPluginEnabled("GrimAC");
        if (grimPresent && flagApi != null && flagTracker != null) {
            if (killFarmDetector != null) HandlerList.unregisterAll(killFarmDetector);
            if (susGUIListener != null) HandlerList.unregisterAll(susGUIListener);

            killFarmDetector = new KillFarmDetector(flagApi,
                    configManager.getGrimKillFarmThreshold(),
                    configManager.getGrimKillFarmTimeWindowMs());
            susGUI = new SusGUI(flagTracker, configManager.getGrimFlagThreshold());
            susGUIListener = new SusGUIListener(susGUI);

            getServer().getPluginManager().registerEvents(killFarmDetector, this);
            getServer().getPluginManager().registerEvents(susGUIListener, this);
        }
    }

    public static ModPlugin getInstance()         { return instance; }
    public ConfigManager getConfigManager()         { return configManager; }
    public MessageManager getMessageManager()       { return messageManager; }
    public FreezeManager getFreezeManager()         { return freezeManager; }
    public MuteManager getMuteManager()             { return muteManager; }
    public VanishManager getVanishManager()         { return vanishManager; }
    public WarnManager getWarnManager()             { return warnManager; }
    public BanManager getBanManager()               { return banManager; }
    public SpamManager getSpamManager()             { return spamManager; }
    public BadWordManager getBadWordManager()       { return badWordManager; }
    public ChatInputManager getChatInputManager()   { return chatInputManager; }
    public MuteReasonManager getMuteReasonManager() { return muteReasonManager; }
    public ReasonManager getReasonManager() { return reasonManager; }
    public FlyManager getFlyManager()               { return flyManager; }
    public InvseeManager getInvseeManager()         { return invseeManager; }
    public FlagTracker getFlagTracker()             { return flagTracker; }
    public KillFarmDetector getKillFarmDetector()   { return killFarmDetector; }
    public SusGUI getSusGUI()                       { return susGUI; }
    public FlagTimeTracker getFlagTimeTracker()     { return flagTimeTracker; }
    public PlayerFlagMonitor getPlayerFlagMonitor() { return playerFlagMonitor; }
    public DiscordWebhook getDiscordWebhook()       { return discordWebhook; }
    public FlagDetailsAPIImpl getFlagApi()          { return flagApi; }
    public DiscordBotManager getDiscordBotManager()  { return discordBotManager; }
    public RecordingManager getRecordingManager()     { return recordingManager; }
    public AppealManager getAppealManager()           { return appealManager; }
    public LastCommandTracker getLastCommandTracker() { return lastCommandTracker; }
    public AutoBanManager getAutoBanManager()         { return autoBanManager; }
}
