package com.Nextstars.ModPlugin.action;
public enum StaffAction {
    FREEZE,
    KICK,
    MUTE,
    TELEPORT,
    BAN,
    CLEAR_INVENTORY,
    WARN,
    VANISH,
    INVSEE
}
